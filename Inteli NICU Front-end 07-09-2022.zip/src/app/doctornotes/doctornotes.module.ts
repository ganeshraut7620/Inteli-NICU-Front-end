import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { DoctornotesRoutingModule } from './doctornotes-routing.module';
import { DoctornotesComponent } from './doctornotes.component';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatTabsModule} from '@angular/material/tabs';
@NgModule({
  declarations: [DoctornotesComponent],
  imports: [
    MatTabsModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatExpansionModule,
    DoctornotesRoutingModule
  ]
})
export class DoctornotesModule { }
