import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import swal from 'sweetalert2';
import { MainserviceService } from '../mainservice.service';
import * as XLSX from 'xlsx';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { any } from '@amcharts/amcharts4/.internal/core/utils/Array';


@Component({
  selector: 'app-doctornotes',
  templateUrl: './doctornotes.component.html',
  styleUrls: ['./doctornotes.component.css']
})
export class DoctornotesComponent implements OnInit {
  date: string;
  registerForm: FormGroup;
  time: string;
  view = false;
  BabayList = [];
  categorys: any = [];
  drugs: any = [];
  whens: any = [];
  hows: any = [];
  frequencys: any = [];
  dosgaeunits: any;

  selectedBaby: string = "";
  viewFlag = false;
  NurseList: any[];
  selectedNurse: string = "";
  selectedDoctor: string = "";
  DiseaseList: any = ["Jaundice", "Metabolic", "Resp System", "CNS", "Infectious Diseases", "Cardiac", "Feeding", "Growth", "Renal", "Others"]
  fluidList = ["Prematurity", "Very Low birth weight", "Respiratory distress syndrome", "Early rescue surfactant", "Early onset sepsis", "Shock", "Hs PDA",
    "Persistent metabolic acidosis", "Inborn error of metabolism", "Pospadiasis", "Symptomatic hypoglycemia",
    "perinsulinemia", "Neonatal hyperbilirubinemia", "Retinopathy of prematurity", "Feed and Nutrition Establishment", "Probable Early Onset sepsis and Shock",
    " Probable Late Onset Sepsis and Shock", "Anemia Of Prematurity", "Intestinal obstruction ( jejunal volvulus and adhesion)",
    "Exploratory Laprotomy and Jejunal resection and anastomosis", "Late  Prematurity (36 weeks)", "Perinatal Asphyxia",
    "Septic Shock", "Respiratory support", "Fetal Hydrops", "Asymtpmatic Hypocalcemia", "Urinary tract malformation- posterior urethral valve", "hydronephrosis and hydroureter",
    "Cystoscopy and fulguration of PU valve", "Extreme Prematurity", "Low Apgar Score", "Hypermagnesemia", "Hyponatremia", "Intraventricular Hemmorrhage",
    "Cogenital adrenal hyperplasia"];

  drugid: any = null;
  categoryid: any = null;
  when: any = null;
  howL: any = null;
  frequency: any = null;
  dosage: any = null;
  dosageunit: any = null;

  frommdate;
  tomdate;
  drughistory = [];

  treatmentOrderList = [];

  diseaseName: string = "";
  ClinicalFindings;
  TreatmentOrders;
  panelOpenState = false;
  doctorNotesList = [];

  filterdiseaseName = "";
  filterDoctorid = "";
  range_1: any[];
  doctorList: any;
  how: any;
  visible = false;
  medicineList: any;
  isTreatmentForm = false;
  babyid: any;

  dateofnotes: any;
  dol: number;
  notesstatus: any;
  drugprescription: any;
  status: any = ['start', 'continue', 'finish']
  baby: any;
  doctornotesid: any;
  drughistorynotes: any[];
  treatment: any;
  filterbaby: any;
  filterDoctor: any;
  babyDob: any;
  babyName: any;
  filtermsg: string = '';
  treatmentSummary: any;
  pagedischarge: number = 1;
  pageadmit: number = 1;
  BabyList =[];
  tabReset: boolean =true;

  constructor(private mainserviceService: MainserviceService, private modalService: NgbModal) {
    this.range_1 = this.genrateIndexes(0, 90);
    this.date = moment().format('L');
    this.time = moment().format('LTS');

  }

  ngOnInit(): void {
    // this.getDoctorNotes()

    this.initmedicinemasterForm();
    this.getbabydetails(1, 'admitted');
    this.getNursemaster();
    this.getDutyDoctor();
    this.getcategory();
    this.changecatid();
    this.getwhenmasterdetails();
    this.gethowmasterdetails();
    this.getfreqdetails();
    this.getdosageunitdetails();
    this.getTreatmentSummary();
  }

  genrateIndexes = (start, end) => {
    try {
      let arr = [];
      for (let i = start; i <= end; i++) {
        arr.push(i);
      }

      return arr;

    } catch (err) {

    }
  }

  openLg(content1, doctornoteid) {
    this.doctornotesid = doctornoteid;
    console.log("doctornotesid => ", this.doctornotesid)
    this.initmedicinemasterForm();
    this.modalService.open(content1, { size: 'lg' });
  }

  openLg1(content2, row) {
    console.log("view Details ========================", row);
    this.getDrugHistoryNotes(row.babyid, row.doctornoteid)
    this.modalService.open(content2, { size: 'lg' });
  }

  openLg2(content3, row) {
    console.log("treatment order view Details ========================", row);
    this.treatment = row;
    this.modalService.open(content3, { size: 'lg' });
  }

  closeBtnClick() {
    this.modalService.dismissAll()
    this.ngOnInit();
  }

  filterByBaby() {
    console.log("baby details => ", this.filterbaby,this.filterbaby.length);
    if (this.filterbaby.length >= 1) {
      console.log("search ",)
      if (this.BabyList.length <= 0) {
        this.filtermsg = 'Doctor Notes Record does not found!';
      } else {
        this.filtermsg = '';
        this.BabyList = this.BabyList.filter(x => {
          return x.babyname === this.filterbaby;
        })
      }
    } else if (this.filterbaby.length <= 0) {
      this.getbabydetails(1, 'admitted');
      this.filtermsg = '';
    } else {
      this.getbabydetails(1, 'admitted');
      this.filtermsg = ''
    }
  }

  filterByDoctor() {
    console.log("Filter by doctor details => ", this.filterDoctorid);
    try {
      if (this.filterDoctorid.length >= 1) {
        this.BabayList = [];
        console.log("Filter Data===========", {
          disease: this.filterdiseaseName ? this.filterdiseaseName : null,
          babyid: this.filterbaby ? this.filterbaby : null,
          doctorid: this.filterDoctorid ? this.filterDoctorid : null
        })

        this.mainserviceService.getDiseaseFilter({
          disease: this.filterdiseaseName ? this.filterdiseaseName : null,
          babyname: this.filterbaby ? this.filterbaby : null,
          doctorid: this.filterDoctorid ? this.filterDoctorid : null
        }).subscribe((res) => {
          console.log("FilterRecord ===============", res);

          if (res && res.data) {
            if (res.data <= 0) {
              this.filtermsg = "Doctor Notes Record does not found!"
            } else {
              this.filtermsg = '';
              this.BabyList = res.data;
            }
          } else {
            this.filtermsg = "Server issue ,Contact To admin!"
          }
        });

      } else if (this.filterDoctorid.length <= 0) {
        this.getbabydetails(1, 'admitted');
        this.filtermsg = '';
      } else {
        this.getbabydetails(1, 'admitted');
        this.filtermsg = '';
      }
    } catch (err) {
      this.filtermsg = "Server issue ,Contact To admin!"
      console.log("disease filter ========", err);
    }
  }

  resetFilter() {
    try {
      this.filterdiseaseName = '';
      this.filterbaby = '';
      this.filterDoctorid = '';
      
      if(this.tabReset){
        this.getbabydetails(1, "admitted");
      }else {
        this.getbabydetails(1, "discharge");
      }
      


    } catch (errResetFilter) {
      console.log("reset Filter===================", errResetFilter);
    }
  }

  filterDisease() {
    try {
      if (this.filterdiseaseName.length >= 1) {
        this.BabyList = [];
        console.log("Filter Data===========", {
          disease: this.filterdiseaseName ? this.filterdiseaseName : null,
          babyid: this.filterbaby ? this.filterbaby : null,
          doctorid: this.filterDoctorid ? this.filterDoctorid : null
        })

        this.mainserviceService.getDiseaseFilter({
          disease: this.filterdiseaseName ? this.filterdiseaseName : null,
          babyname: this.filterbaby ? this.filterbaby : null,
          doctorid: this.filterDoctorid ? this.filterDoctorid : null
        }).subscribe((res) => {
          console.log("FilterRecord ===============", res);

          if (res && res.data) {
            if (res.data <= 0) {
              this.filtermsg = "Doctor Notes Record does not found!"
            } else {
              this.filtermsg = '';
              this.BabyList = res.data;
            }
          } else {
            this.filtermsg = "Server issue ,Contact To admin!"
          }
        });

      } else if (this.filterdiseaseName.length <= 0) {
        this.getbabydetails(1, 'admitted');
        this.filtermsg = '';
      } else {
        this.getbabydetails(1, 'admitted');
        this.filtermsg = '';
      }
    } catch (err) {
      this.filtermsg = "Server issue ,Contact To admin!"
      console.log("disease filter ========", err);
    }
  }

  createDoctorNotes() {
    try {
      console.log("input ==============",{
        doctorid: this.selectedDoctor ? this.selectedDoctor : null,
        dob: this.babyDob ? this.babyDob : null,
        babyname: this.babyName ? this.babyName : null,
        babyid: this.babyid ? this.babyid : null,
        disease: this.diseaseName ? this.diseaseName : null,
        clientid: JSON.parse(sessionStorage.getItem('userInfo1')).usermasterid,
        clinicalfindings: this.ClinicalFindings ? this.ClinicalFindings : null,
        treatmentorders: this.TreatmentOrders ? this.TreatmentOrders : null,
        date:  moment().format(),
        dol: this.dol,
        notesstatus: this.notesstatus ? this.notesstatus : null,
        drugprescription: "-"
      })

      if ((this.selectedDoctor != null && this.selectedDoctor != undefined) && (this.babyid != null && this.babyid != undefined)
        && (this.diseaseName != null && this.diseaseName != undefined) && (this.ClinicalFindings != null && this.ClinicalFindings != undefined)
        && (this.TreatmentOrders != null && this.TreatmentOrders != undefined) && (this.dateofnotes != null && this.dateofnotes != undefined)
        && (this.dol != null && this.dol != undefined) && (this.notesstatus != null && this.notesstatus != undefined) && (this.babyDob != null && this.babyDob != undefined)
        && (this.babyName != null && this.babyName != undefined)) {
        let obj = {
          doctorid: this.selectedDoctor ? this.selectedDoctor : null,
          dob: this.babyDob ? this.babyDob : null,
          babyname: this.babyName ? this.babyName : null,
          babyid: this.babyid ? this.babyid : null,
          disease: this.diseaseName ? this.diseaseName : null,
          clientid: JSON.parse(sessionStorage.getItem('userInfo1')).usermasterid,
          clinicalfindings: this.ClinicalFindings ? this.ClinicalFindings : null,
          treatmentorders: this.TreatmentOrders ? this.TreatmentOrders : null,
          date: moment().format(),
          dol: this.dol,
          notesstatus: this.notesstatus ? this.notesstatus : null,
          drugprescription: "-"
        }

        console.log(" doctor notes ================", obj);

        this.mainserviceService.createDoctorNotes(obj).subscribe((data) => {
          console.log("doctor notes response===============", data);
          if (data) {
            this.getDoctorNotes(this.babyid);
            this.resetDoctorForm();
          }
          if (data.status_code == "s_408") {
            swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: 'Record already exist!'
            });
          }

          if (data.status_code == "s_1015") {
            swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: 'Something wrong!'
            });
          }
        });
      } else {
        console.log("input problem ======",)
        swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Wring Input put,All Fields are Mandatory!'
        });
      }

    } catch (err) {
      console.log("error ====",err);
      swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Something wrong!'
      });
    }
  }

  resetDoctorForm() {
    try {
      this.selectedBaby = null;
      this.selectedDoctor = null;
      this.selectedNurse = null;
      this.diseaseName = null;
      this.TreatmentOrders = null;
      this.ClinicalFindings = null;

      // this.dateofnotes = null;
      this.notesstatus = null;
      this.drugprescription = null;

    } catch (err) {
      console.log(err);
    }
  }

  getDoctorNotes(babyid) {
    try {
      let dummy_data = {
        "babyid": babyid,
      }
      this.mainserviceService.getDoctorNotes(dummy_data).subscribe((res) => {
        console.log("Doctor notes details ============ =>", res.data);
        if (res) {
          this.doctorNotesList = res.data ? res.data : [];
        }
      }, (err) => {
        console.log(err.error);
      });
    } catch (errNotes) {
      console.log("errNotes ==========", errNotes);
    }

  }

  getData = (data) => {
    try {
      let returnData = data.map(x => {
        let obj = {
          doctornoteid: x.doctornoteid,
          babyid: x.babyid,
          clinicalfindings: x.clinicalfindings,
          createddate: x.createddate,
          date: x.date,
          desc: JSON.parse(x.description),
          disease: x.disease,
          nurseid: x.nurseid,
          time: x.time,
          treatmentorders: x.treatmentorders
        }
        return obj;
      })

      console.log("return data obj = ", returnData);

      return returnData;


    } catch (errData) {
      console.log("ErrData => ", errData)
    }
  }

  getbabydetails(pageinc, status) {
    try {
      this.mainserviceService.getbabyid({
        "babyno": null,
        "babyname": null,
        "machineid": null,
        "clientid": JSON.parse(sessionStorage.getItem('userInfo1')).clientid,
        "babystatus": status,
        "isactive": true,
        "page": pageinc,
        "pagesize": 5
      }).subscribe((res) => {
        console.log("Baby Details => ", res.data);
        this.BabyList = res.data;
      }, (err) => {
        console.log(err.error);

      });

    } catch (err) {
      console.log(err);
    }
  }

  getNursemaster() {
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    let dummy_data = {
      "usercategoryid": 9,
      "usersubcategoryid": null,
      "clientid": userData.clientid,
      "page": 1,
      "pagesize": 100000
    }

    this.mainserviceService.getUser(dummy_data).subscribe((res) => {
      console.log("Nurse Master Data => ", res.data);
      this.NurseList = res.data;
    }, (err) => {
      console.log(err.error);
    });
  }

  getDutyDoctor() {
    try {
      this.mainserviceService.getUser({
        "usercategoryid": 8,
        "usersubcategoryid": null,
        "clientid": JSON.parse(sessionStorage.getItem('userInfo1')).clientid,
        "page": 1,
        "pagesize": 100000
      }).subscribe((res) => {
        console.log("Duty Doctor Details => ", res.data);
        if (res && res.data) {
          this.doctorList = res.data;
        } else {
          this.doctorList = [];
        }
      }, (err) => {
        console.log(err.error);

      });
    } catch (errDutyDoctor) {
      console.log("err===============================",)
    }
  }

  getcategory() {
    let obj = {
      "medicinecategoryid": null
    }

    this.mainserviceService.getMedicinecategory(obj).subscribe((res) => {
      console.log("Categorys =>", res);
      if (res.status_code == "s_407") {
        this.categorys = res.data;
        // this.cat = res.data[0].medicinecategory;
        console.log("Category => ", this.categorys);
      }

    }, (err) => {
      console.log(err.error);

    });

  }
  changecatid() {

    console.log("Medicine cat id => ", this.categoryid)

    let changecategoryid = {
      "drugid": null,
      "medicinecategoryid": this.categoryid == null ? 1 : this.categoryid
    }

    this.mainserviceService.getdruglist(changecategoryid).subscribe((res) => {

      console.log("Getdruglist =>", res);

      if (res.status_code == "s_407") {
        this.drugs = res.data;
        //this.cat = res.data[0].medicinecategory;
        console.log("Druglist => ", this.drugs);
      }

    }, (err) => {
      console.log(err.error);

    });

  }

  getwhenmasterdetails() {

    let obj = {
      "whenmedicineid": null
    }

    this.mainserviceService.getwhenmaster(obj).subscribe((res) => {

      console.log("Get when data =>", res);

      if (res.status_code == "s_407") {
        this.whens = res.data;

      }

    }, (err) => {
      console.log(err.error);

    });

  }

  gethowmasterdetails() {

    let obj = {
      "howmedicineid": null
    }

    this.mainserviceService.gethowmaster(obj).subscribe((res) => {

      console.log("Get how data =>", res);

      if (res.status_code == "s_407") {
        this.hows = res.data;
      }
    }, (err) => {
      console.log(err.error);

    });

  }

  getfreqdetails() {

    let obj = {
      "frquencymedicineid": null
    }

    this.mainserviceService.getfrequency(obj).subscribe((res) => {

      console.log("Get freq data =>", res);

      if (res.status_code == "s_407") {
        this.frequencys = res.data;
      }
    }, (err) => {
      console.log(err.error);

    });

  }

  getdosageunitdetails() {

    let obj = {
      "dosageunitid": null
    }

    this.mainserviceService.getdosageunit(obj).subscribe((res) => {

      console.log("Get Dosage data =>", res);

      if (res.status_code == "s_407") {
        this.dosgaeunits = res.data;
      }
    }, (err) => {
      console.log(err.error);

    });

  }

  addpresxription() {
    try {
      this.visible = true;
      let row = {
        drugid: this.drugid ? this.drugid : '-',
        categoryid: this.categoryid ? this.categoryid : '-',
        when: this.when ? this.when : '-',
        how: this.how ? this.how : '-',
        frequency: this.frequency ? this.frequency : '-',
        dosage: this.dosage ? this.dosage : '-',
        dosageunit: this.dosageunit ? this.dosageunit : '-',
      }

      this.drughistory.push(row);
      this.resetdrugHistory()
      console.log("Drug history ==============", row, this.drughistory);
    } catch (err) {

    }
  }

  resetdrugHistory() {
    try {
      this.drugid = null;
      this.categoryid = null;
      this.when = null;
      this.how = null;
      this.frequency = null;
      this.dosage = null;
      this.dosageunit = null;

    } catch (err) {

    }
  }


  getmedicinemasterdetails() {
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));


    let obj = {
      "medicineid": null,
      "fromdate": moment(new Date()).subtract(1, 'd').format('YYYY-MM-DD'),
      "todate": moment(new Date()).format('YYYY-MM-DD'),
      "clientid": userData.clientid
    }

    // this.mainserviceService.getmedicine(obj).subscribe((res) => {

    //   console.log("Medicine Details =>", res);

    //   if (res.status_code == "s_407") {
    //     this.medicineList = res.data;
    //   }
    // }, (err) => {
    //   console.log(err.error);

    // });
  }

  getbabyid(baby) {
    return this.BabayList.filter(x => {
      if (x.babyname === baby) {
        return x.babyid;
      }
    })
  }

  tomedicinedate() {
    try {

      console.log("form date ====================", new Date(this.frommdate));
      var userData = JSON.parse(sessionStorage.getItem('userInfo1'));

      let babyids = this.getbabyid(this.selectedBaby);

      let obj = {
        "medicineid": null,
        "babyid": babyids[0].babyid,
        "fromdate": moment(new Date(this.frommdate)).subtract(1, 'd').format('YYYY-MM-DD'),
        "todate": moment(new Date(this.tomdate)).format('YYYY-MM-DD'),
        "clientid": userData.clientid
      }

      console.log("obj -----------------------", obj);

      this.mainserviceService.getmedicine(obj).subscribe((res) => {

        console.log("Medicine Details =>", res);

        if (res.status_code == "s_407") {
          this.medicineList = res.data;
        }
      }, (err) => {
        console.log(err.error);

      });



    } catch (err) {

    }
  }


  selectedBabys = (baby) => {
    console.log("BABY DETAILS =================", baby);
    this.babyid = baby.babyid;
    this.babyDob = baby.dob;
    this.babyName = baby.babyname;
    //this.resetDoctorForm();
    this.getDoctorNotes(baby.babyid);
    if (baby.dob) {

      let Difference_In_Days: any = (new Date().getTime() - new Date(baby.dob).getTime()) / (1000 * 3600 * 24);
      this.dol = parseInt(Difference_In_Days) === 0 ? (parseInt(Difference_In_Days) + 1) : parseInt(Difference_In_Days);
      console.log("Difference dol => ", parseInt(Difference_In_Days))
    }
  }

  initmedicinemasterForm() {
    this.registerForm = new FormGroup({

      doctorid: new FormControl(null, [Validators.required]),
      medicinedate: new FormControl(null, [Validators.required]),
      categoryid: new FormControl(null, [Validators.required]),
      drugid: new FormControl(null, [Validators.required]),
      when: new FormControl(null, [Validators.required]),
      how: new FormControl(null, [Validators.required]),
      frequency: new FormControl(null, [Validators.required]),
      dosage: new FormControl(null, [Validators.required]),
      dosageunit: new FormControl(null, [Validators.required]),
    });
  }


  onSubmit = () => {

    console.log("Medicine Master Form Value => ", this.registerForm.value);
    console.log("druglist =============",this.registerForm.value.drugid,this.getdrugname(this.registerForm.value.drugid))
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    if (this.registerForm.valid) {
      let obj = {
        babyid: this.babyid,
        doctornotesid: this.doctornotesid,
        categoryid: this.registerForm.value.categoryid,
        doctorid: this.registerForm.value.doctorid,
        drugname : this.getdrugname(this.registerForm.value.drugid).drugname ? this.getdrugname(this.registerForm.value.drugid).drugname: '',
        dosage: this.registerForm.value.dosage,
        dosageunit: this.registerForm.value.dosageunit,
        drugid: this.registerForm.value.drugid,
        frequency: this.registerForm.value.frequency,
        how: this.registerForm.value.how,
        medicinedate: this.registerForm.value.medicinedate,
        whens: this.registerForm.value.when
      }


      console.log("obj ===> ", obj);
      // this.registerForm.value.clientid = userData.clientid;
      this.mainserviceService.creatdrughistorynotes(obj).subscribe((res) => {

        console.log("Medicine Master res =>", res);

        if (res.status_code == "s_405") {
          swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Record already exist!'
          });

        } else if (res.status_code == "s_444") {
          swal.fire(
            'Good job!',
            'Medicine Added Succsefully!',
            'success'
          );

          // this.getmedicinemasterdetails()
          this.closeBtnClick()
        } else if (res.status_code == "s_1015") {
          console.log("error response ==========",res);
          swal.fire(
            'Bad Response!',
            'An Error Occured, Please Contact System Administrator!',
            'error'
          );
        }

      }, (err) => {
        console.log(err);

      });


    } else {

    }
    this.drugs = '';
    // this.initmedicinemasterForm();
    // this.closeBtnClick();
  }

  getdrugname = (drugid) => {
    console.log("Drugid ==========",drugid,"druglist =====",this.drugs);
    let returnDrug ;
    this.drugs.filter((x) => {
       if(x.drugid === Number(drugid)){
        console.log("drug return ========",x);
        returnDrug =  x;
       }
       console.log("drug not return ========",x);
    })

    return returnDrug;
  }

  getDrugHistoryNotes = (babyid, doctornotesid) => {
    try {
      this.drughistorynotes = [];
      console.log("")
      this.mainserviceService.getdrugHistory({ babyid: babyid, doctornotesid: doctornotesid }).subscribe((res) => {
        console.log("Drug history res===============", res);
        if (res && res.data) {
          this.drughistorynotes = res.data;
        }
      });

    } catch (errDrugNotes) {
      console.log("err =====================", errDrugNotes);
    }
  }

  exportexcel(): void {
    try {
      const workBook = XLSX.utils.book_new(); // create a new blank book
      const workSheet = XLSX.utils.json_to_sheet(this.doctorNotesList);

      XLSX.utils.book_append_sheet(workBook, workSheet, 'data'); // add the worksheet to the book
      XLSX.writeFile(workBook, 'TreatmentNotes' + new Date() + '' + '.xlsx'); // initiate a file download in browser
    
    } catch (err) {
      console.log("err================",err);
    }
  }

  getTreatmentSummary () {
    try{
      this.mainserviceService.getTratmentSummary({
        diseasemasterid:null
      }).subscribe((resGet) => {
        console.log("getTreatmentSummary ========",resGet);
        if(resGet && resGet.data){
          this.treatmentSummary = resGet.data;
        }else{
          this.treatmentSummary =[];
        }
      });

    }catch(errTreatmentSummary){
      console.log("err=============",errTreatmentSummary);
    }
  }

  clinicalfindingchange(){
    try{
      console.log("clinical finding ====",this.ClinicalFindings);
      if(this.ClinicalFindings != null && this.ClinicalFindings != undefined && this.ClinicalFindings.length>0){
        let finding = this.treatmentSummary.filter((x)=> {
          return x.clinicalfinding === this.ClinicalFindings;
        })

        console.log("Treatment Summary details=====",finding);

        this.TreatmentOrders = finding? finding[0].tratmentsummary: "";
      }
    }catch(err){

    }
  }

  admitprevious() {
    if (this.pageadmit >= 2) {
      this.pageadmit = this.pageadmit - 1;
      console.log("decriment => ", this.pageadmit)
      // this.getbabydetails(this.page);
      this.getbabydetails(this.pageadmit, "admitted");
    }
  }

  admitnext() {
    this.pageadmit = this.pageadmit + 1;
    console.log("Incriment => ", this.pageadmit)
    // this.getbabydetails(this.page);
    this.getbabydetails(this.pageadmit, "admitted");

  }
  
  dischargeprevious() {
    if (this.pagedischarge >= 2) {
      this.pagedischarge = this.pagedischarge - 1;
      console.log("decriment => ", this.pagedischarge)
      // this.getbabydetails(this.page);
      this.getbabydetails(this.pagedischarge, "discharge");
    }
  }
  dischargenext() {
    this.pagedischarge = this.pagedischarge + 1;
    console.log("Incriment => ", this.pagedischarge)
    // this.getbabydetails(this.page);
    this.getbabydetails(this.pagedischarge, "discharge");

  }

  
  onChange(event: MatTabChangeEvent) {
    try {
      const tab = event.tab.textLabel;
      console.log(tab);

      if (tab === "Admited") {
        this.tabReset = true;
        this.getbabydetails(1, "admitted");
      } else if (tab == "Discharged") {
        this.tabReset = false;
        this.getbabydetails(1, "discharge");

      }
    } catch (err) {
      console.log(err)
    }
  }

}
