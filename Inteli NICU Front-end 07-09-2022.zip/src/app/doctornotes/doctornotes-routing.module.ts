import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DoctornotesComponent } from './doctornotes.component';

const routes: Routes = [
  {
    path:'', component: DoctornotesComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DoctornotesRoutingModule { }
