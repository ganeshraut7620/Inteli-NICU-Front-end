import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { UsermasterRoutingModule } from './usermaster-routing.module';
import { UsermasterComponent } from './usermaster.component';
import { NgxSpinnerModule } from "ngx-spinner";

@NgModule({
  declarations: [UsermasterComponent],
  imports: [
    CommonModule,FormsModule,ReactiveFormsModule,
    UsermasterRoutingModule,NgxSpinnerModule
  ]
})
export class UsermasterModule { }
