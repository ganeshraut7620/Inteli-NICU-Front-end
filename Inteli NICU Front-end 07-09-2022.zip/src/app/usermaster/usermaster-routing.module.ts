import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UsermasterComponent } from './usermaster.component';

const routes: Routes = [
  { path : '' ,  component: UsermasterComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UsermasterRoutingModule { }
