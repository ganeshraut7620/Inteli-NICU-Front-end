import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, RequiredValidator,FormBuilder  } from '@angular/forms';
import { MainserviceService } from '../mainservice.service';
import swal from 'sweetalert2';
import { NgxSpinnerService } from "ngx-spinner";
@Component({
  selector: 'app-usermaster',
  templateUrl: './usermaster.component.html',
  styleUrls: ['./usermaster.component.css']
})
export class UsermasterComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;

  states:any = ['Mharastra','Bihar','Delhi'];
  citys:any = ['Nagpur','Pune','Kanpur','Agra'];
  category:any = [1,2,3,4,5,6,7,8,9,10,11,12,13];

  categorys:any = { 2:"Customer Service Master", 3:"Manager",4:"Field Engineer",5:"Client master"}


  constructor(private spinner: NgxSpinnerService,private fb: FormBuilder,public mainserviceService:MainserviceService) {
    this.spinner.show();

    setTimeout(() => {
      /** spinner ends after 5 seconds */
      this.spinner.hide();
    }, 1000);

  }

  ngOnInit(): void {

    this.registerForm = this.fb.group({
      usercategoryid:[,Validators.required],
      usermastername:['',Validators.required],
      address:['',Validators.required],
      state:[''],
      city:[''],
      pincode:[,Validators.required],
      emailid:['',Validators.required],
      mobilenumber:['',Validators.required],
      username:['',Validators.required],
      password:['',Validators.required]
    }
    );

  }

  changestate($event){}
  changecity($event){}
  changecat($event){}

  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;

    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }

    if (event.keyCode === 32 ) {
      return false;
    }
  }


  get registerFormControl() {
    return this.registerForm.controls;
  }


onSubmit() {
    this.submitted = true;
    if (this.registerForm.valid) {
      this.registerForm.value.usercategoryid = Number(this.registerForm.value.usercategoryid);
      console.log("Register Form Details => ", this.registerForm.value);
      this.registerForm.value.usersubcategoryid = null;
      this.mainserviceService.createUser(this.registerForm.value).subscribe((res) => {
        console.log(res);
        swal.fire(
          'Good job!',
          'User Added Succsefully!',
          'success'
        );
        this.registerForm.patchValue({
        });

        }, (err) => {
              console.log(err.error);

      });
    }

  }

}
