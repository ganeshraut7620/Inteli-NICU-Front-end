import { Injectable } from '@angular/core';

import { Alarmmaster } from './alarmmaster';
import { alarmmaster } from './alarmmaster-data';

@Injectable({
  providedIn: 'root'
})

export class AlarmmasterService {

  public alarmmaster: Alarmmaster[] = alarmmaster;

  public getAlarmDetails() {
      return this.alarmmaster;
  }

}
