import { TestBed } from '@angular/core/testing';

import { AlarmmasterService } from './alarmmaster.service';

describe('AlarmmasterService', () => {
  let service: AlarmmasterService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AlarmmasterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
