import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AlrammasterRoutingModule } from './alrammaster-routing.module';
import { AlrammasterComponent } from './alrammaster.component';
import { UiSwitchModule } from 'ngx-ui-switch';
import { NgxSpinnerModule } from "ngx-spinner";

@NgModule({
  declarations: [AlrammasterComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    NgxSpinnerModule,


    UiSwitchModule.forRoot({
      size: 'small',
      color: 'rgb(0, 189, 99)',
      switchColor: '#80FFA2',
      defaultBgColor: '#00ACFF',
      defaultBoColor : '#476EFF',
      checkedLabel: 'on',
      uncheckedLabel: 'off'
    }),
    AlrammasterRoutingModule
  ]
})
export class AlrammasterModule { }
