export class Alarmmaster {
  public alarmmasterid:String;
  public alarmdescription:String;
  public alarmname:String;
  public machineid:Number;
  public clientid:Number;
}
