import { Component, OnInit ,NgModule} from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner";
import { Alarmmaster } from './alarmmaster';
import { AlarmmasterService } from './alarmmaster.service';
import { MainserviceService } from '.././mainservice.service';
@Component({
  selector: 'app-alrammaster',
  templateUrl: './alrammaster.component.html',
  styleUrls: ['./alrammaster.component.css']
})
export class AlrammasterComponent implements OnInit {

  page = 1;
  pageSize = 7;

  filterArray: Alarmmaster[];
  isSwitchedOn = false;
  alarmList: Alarmmaster[] = this.alarmmasterService.getAlarmDetails();

  constructor(private spinner: NgxSpinnerService,private alarmmasterService:AlarmmasterService,private mainserviceService: MainserviceService) {
    this.getalarmmasterdetails()
    this.spinner.show();

      setTimeout(() => {
        /** spinner ends after 5 seconds */
        this.spinner.hide();
      }, 1000);

   }

  ngOnInit(): void {

  }

  _searchTerm: string;
  get searchTerm(): string {
      return this._searchTerm;
  }
  set searchTerm(val: string) {
      this._searchTerm = val;
      this.filterArray = this.filter(val);
  }

  filter(v: string) {
      return this.alarmList.filter(x => x.alarmname.toLowerCase().indexOf(v.toLowerCase()) !== -1);
  }

  getalarmmasterdetails(){
    let dummy_data ={
      "alarmcode": null,
      "machineid": null,
      "clientid": null,
      "isactive": true,
      "page": 1,
      "pagesize": 7
    }
    this.mainserviceService.getAlarmDetails(dummy_data).subscribe((res) => {
      console.log(res);
      this.filterArray = res.data;
      this.alarmList = res.data;
      console.log(this.filterArray);
    }, (err) => {
      console.log(err.error);
    });
  }

}
