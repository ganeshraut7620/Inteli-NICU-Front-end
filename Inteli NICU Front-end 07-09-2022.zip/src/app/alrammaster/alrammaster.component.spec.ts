import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AlrammasterComponent } from './alrammaster.component';

describe('AlrammasterComponent', () => {
  let component: AlrammasterComponent;
  let fixture: ComponentFixture<AlrammasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AlrammasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlrammasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
