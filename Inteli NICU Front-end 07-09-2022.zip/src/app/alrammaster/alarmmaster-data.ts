import { Alarmmaster } from './alarmmaster';

export const alarmmaster : Alarmmaster[] = [

]
