import { Component, OnInit } from '@angular/core';
import { MainserviceService } from '../mainservice.service';
import * as moment from 'moment';

@Component({
  selector: 'app-babyhistory',
  templateUrl: './babyhistory.component.html',
  styleUrls: ['./babyhistory.component.css']
})
export class BabyhistoryComponent implements OnInit {

  BabyList:any;
  myfilename:any;
  fileUrl:any;
  folder_name:any;
  status_flag = false;
  BabyListprint: any;
  page = 1;
  filterArray: any;

  constructor(public mainserviceService:MainserviceService) {
   // this.getdailybabyreport();
    this.getbabydetails(this.page)
   }

  ngOnInit(): void {
  }
  _searchTerm: string;
  get searchTerm(): string {
      return this._searchTerm;
  }
  set searchTerm(val: string) {
      this._searchTerm = val;
      this.filterArray = this.filter(val);
  }

  filter(v: string) {
      return this.BabyList.filter(x => x.mothername.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.babyname.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.gender.toLowerCase().indexOf(v.toLowerCase()) !== -1);
  }

  getbabydetails(page) {

    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    console.log( "session storage value => ",userData);

    let dummy_data ={
      "babyno": null,
      "babyname": null,
      "machineid": null,
      "clientid": userData.clientid,
      "isactive": true,
      "page": page,
      "pagesize": 5
    }

    this.mainserviceService.getbabyid(dummy_data).subscribe((res) => {
      console.log("Baby Details => ",res.data);
      this.BabyList = res.data;
      this.filterArray = res.data;

      this.BabyListprint =  this.genarte_flag();
      console.log("Updated Baby History Report =>",this.BabyListprint);
      }, (err) => {
            console.log(err.error);

    });

  }

  generatereport(baby){
    console.log("Baby Details => ",baby,"index of baby => ",this.BabyListprint.findIndex(x => x.babyid ===baby.babyid));

    let dummy_data ={
      "machineid": baby.machineid,
      "babyid": baby.babyid,
      "fromdate": moment(new Date(baby.admissiondate)).format('YYYY-MM-DD'),
      "todate": moment(new Date()).format('YYYY-MM-DD')
    }

    this.mainserviceService. getdailybabyreport(dummy_data).subscribe((res) => {
      console.log("Dialy Baby Report => ",res,res.data)
      //this.BabyList[i].push()
      if(res.status){
        this.BabyListprint[this.BabyListprint.findIndex(x => x.babyid ===baby.babyid)].awspath =res.data[0].awspath;
        this.BabyListprint[this.BabyListprint.findIndex(x => x.babyid ===baby.babyid)].report_status = "Download";
        this.BabyListprint[this.BabyListprint.findIndex(x => x.babyid ===baby.babyid)].awspathfalg = true;
      }



    });

  }

  previous(){
   if(this.page>=2){
    this.page = this.page - 1;
    console.log("decriment => ",this.page)
    this.getbabydetails(this.page);
   }else{
     
   }
  }

  next(){
    this.page = this.page + 1;
    console.log("Incriment => ",this.page)
    this.getbabydetails(this.page);
  }

  genarte_flag(){

    for(let i=0;i<this.BabyList.length;i++){
      this.BabyList[i].awspath = null;
      this.BabyList[i].awspathfalg = false;
      this.BabyList[i].report_status = "Generate Report";
      }
      return this.BabyList;

    }




}
