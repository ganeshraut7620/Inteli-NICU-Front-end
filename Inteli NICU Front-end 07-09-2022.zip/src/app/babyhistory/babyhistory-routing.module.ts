import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BabyhistoryComponent } from './babyhistory.component';


const routes: Routes = [
  { path: '' ,component: BabyhistoryComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BabyhistoryRoutingModule { }
