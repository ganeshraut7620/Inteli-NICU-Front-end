import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { BabyhistoryRoutingModule } from './babyhistory-routing.module';
import { BabyhistoryComponent } from './babyhistory.component';


@NgModule({
  declarations: [BabyhistoryComponent],
  imports: [
    CommonModule,
    FormsModule,ReactiveFormsModule,
    BabyhistoryRoutingModule
  ]
})
export class BabyhistoryModule { }
