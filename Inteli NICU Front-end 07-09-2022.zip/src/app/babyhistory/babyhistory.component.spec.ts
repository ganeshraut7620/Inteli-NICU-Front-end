import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BabyhistoryComponent } from './babyhistory.component';

describe('BabyhistoryComponent', () => {
  let component: BabyhistoryComponent;
  let fixture: ComponentFixture<BabyhistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BabyhistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BabyhistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
