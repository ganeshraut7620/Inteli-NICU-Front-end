import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ClientwarmerstatusComponent } from './clientwarmerstatus.component';
import { TrendsComponent } from  '../trends/trends.component';
import { IndusialwarmerstatusComponent } from '../indusialwarmerstatus/indusialwarmerstatus.component'

const routes: Routes = [
  { path: '' , component: ClientwarmerstatusComponent },
  { path: 'indusialwrmerstatus' , component:IndusialwarmerstatusComponent }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ClientwarmerstatusRoutingModule { }
