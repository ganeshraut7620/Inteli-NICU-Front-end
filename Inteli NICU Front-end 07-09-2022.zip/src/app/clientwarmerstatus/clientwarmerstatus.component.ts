import { Component, OnInit } from '@angular/core';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { TrendsComponent } from '../trends/trends.component';
import { io } from 'socket.io-client';
import { MainserviceService } from '../mainservice.service';
import { NgbDropdownConfig } from '@ng-bootstrap/ng-bootstrap';

const socket = io('http://3.109.128.197:3000');
// const socket = io('http://192.168.0.111:3000');

@Component({
  selector: 'app-clientwarmerstatus',
  templateUrl: './clientwarmerstatus.component.html',
  styleUrls: ['./clientwarmerstatus.component.css'],
  providers: [NgbDropdownConfig]
})

export class ClientwarmerstatusComponent implements OnInit {

  warmer_data: any;
  tempwarmer_data: any;
  displayflag = false;
  machines: any;
  machineList: any;
  babyList: any;
  trendsform: trends_form = new trends_form();
  alaramstatusdata: any;
  dummyCoponent = TrendsComponent;
  dashboardheading: any;
  machinemsg: any;
  isFilter = false;
  lastUpdatedAt: any;
  bedDeatails: any = {};
  statusDeatails: any = {};
  hallList: any = [];
  bedList: any = [];

  constructor(private modalService: NgbModal, private mainserviceService: MainserviceService, config: NgbDropdownConfig) {
    // customize default values of dropdowns used by this component tree
    config.placement = 'top-left';
    config.autoClose = false;

    if (sessionStorage.getItem('flag') == "true") {
      window.location.reload();
      sessionStorage.setItem('flag', 'false');
    }
    this.getmachine();

    var temp = JSON.parse(sessionStorage.getItem("userInfo1"));
    this.dashboardheading = temp.usercategoryname;
    try {
      socket.on('dataUpdate', (res) => {
        console.log("Actual Data =>", res);
        this.displayflag = true;
        this.getconditionstatus();
        
        let card_res = JSON.parse(res);
        var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
        // console.log("session storage value => ", userData);

        // console.log(typeof (card_res), card_res);
        if (card_res.status) {
          this.warmer_data = card_res.data;
          console.log('card_res.data==>', card_res.data)
          this.machineList = this.warmer_data.filter(x => x.clientid == userData.clientid);

          console.log("warmer Data =>", this.machineList);
        } else {

        }


      });
    } catch (err) {
      // console.log("Error => ", err)
    }
  }

  requesttodata = () => {
    try {
      let Data = {
        "machineid": null,
        "fieldengineerid": null,
        "clientid": null,
        "doctorid": null,
        "nurseid": null
      }

      this.mainserviceService.getdasboard(Data).subscribe((res) => {
        console.log("Request Data =>", res);

      }, (err) => {
        // console.log(err.error);
      });

    } catch (err) {
      console.log(err);
    }
  }


  ngOnInit(): void {
    this.lastUpdatedAt = new Date();
    this.gethallbeds();
    this.gethallbedsstatus();
    this.getconditionstatus();
    this.getstaticdashboards();
  }

  gethallbeds() {
    try {
      let user = JSON.parse(localStorage.getItem('userInfo'));
      this.mainserviceService.getdashboardupdate({
        "clientid": user.clientid,
        "page": 1,
        "pagesize": 1
      }).subscribe((res) => {
        if (res.status) {
          console.log("Details => ", res);
          this.hallList = res.data[0]
          this.bedList = res.data[1];
        } else {

        }
      }, (err) => {
        console.log(err.error);
      });


    } catch (err) {

    }
  }

  //getdashboarddetails

  gethallbedsstatus() {
    try {
      let user = JSON.parse(localStorage.getItem('userInfo'));
      this.mainserviceService.getdashboarddetails({
        "clientid": user.clientid,
        "isactive": true,
        "babystatus": "admitted",
        "isdashboard": null,
        "babyno": null,
        "babyname": null,
        "machineid": null,
        "page": 1,
        "pagesize": 10000
      }).subscribe((res) => {
        if (res.status) {
          console.log("get middle Details => ", res);
          this.bedDeatails = res.data;
        } else {

        }
      }, (err) => {
        console.log(err.error);
      });


    } catch (err) {

    }
  }

  //getdashboarddetailsstatus

  getconditionstatus() {
    try {
      let user = JSON.parse(localStorage.getItem('userInfo'));
      this.mainserviceService.getdashboarddetailsstatus({
        "clientid": user.clientid,
        "isactive": true,
        "babystatus": "admitted",
        "isdashboard": null,
        "babyno": null,
        "babyname": null,
        "machineid": null,
        "page": 1,
        "pagesize": 10000
      }).subscribe((res) => {
        if (res.status) {
          console.log("get middle Details => ", res);
          this.statusDeatails = res.data;
        } else {

        }
      }, (err) => {
        console.log(err.error);
      });


    } catch (err) {

    }
  }

  //getstaticdashboard

  getstaticdashboards() {
    try {
      var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
      this.displayflag = true;
      this.mainserviceService.getstaticdashboard({
        "machineid": null,
        "clientid": userData.clientid,
        "doctorid":null,
        "fieldengineerid": null,
        "nurseid": null
      }).subscribe((res) => {
        console.log("get machine Details => ", res);
        if (res.status) {
          this.machineList = res.data;
        } else {

        }
      }, (err) => {
        console.log(err.error);
      });


    } catch (err) {

    }
  }

  trends_submit() {
    // console.log(this.trendsform);
  }


  machinechange() {
    try {
      if (!(this.trendsform.machineid == null || this.trendsform.machineid == undefined)) {
        console.log("Machine Id===>", this.trendsform.machineid)
        let dummy_data = {
          "babyno": null,
          "babyname": null,
          "machineid": Number(this.trendsform.machineid),
          "isdashboard": true,
          "clientid": null,
          "isactive": true,
          "page": 1,
          "pagesize": 10000
        }

        this.mainserviceService.getbaby(dummy_data).subscribe((res) => {
          // console.log("Baby Details => ", res.data);
          if (res.status) {
            this.babyList = res.data;
          } else {

          }

        }, (err) => {
          // console.log(err.error);
        });
        var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
        // console.log("session storage value => ", this.warmer_data);


      } else {

      }
    } catch (err) {
      // console.log(err);
    }

  }

  babydata = () => {
    if (!(this.trendsform.babyid == null || this.trendsform.babyid == undefined)) {
      var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
      // console.log("session storage value => ", userData);
      this.machineList = this.warmer_data.filter(x => x.babyid == this.trendsform.babyid);
      // this.machineList = this.warmer_data((e, i) => e.babyid == this.trendsform.babyid ? e : undefined).filter(x => x);
    } else {

    }
  }

  machinealert(warmerid) {
    console.log("Warmer Details => ", warmerid);
    let dummy_data = {
      "machineid": warmerid
    }
    this.mainserviceService.getactivealarm(dummy_data).subscribe((res) => {

      console.log("Alarm Data =>", res.data);
      this.alaramstatusdata = res.data;
      console.log("Alarm Data  pass => ", this.alaramstatusdata);

    }, (err) => {
      // console.log(err.error);
    });

  }

  getmachine = () => {
    try {
      var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
      // console.log("session storage value => ", userData);
      let dummy_data = {
        "clientid": userData.clientid,
        "isactive": true
      }
      this.mainserviceService.getmachineclientwise(dummy_data).subscribe((res) => {
        if (res.status) {
          // console.log("Get Machine Details => ", res);
          this.machineList = res.data;
          console.log('this.machineList==>', this.machineList);
          // console.log("Machine List =>", this.machineList);
        } else {

        }
      }, (err) => {
        // console.log(err.error);
      });
    } catch (err) {
      // console.log(err);
    }
  }


  openXl(content1) {
    this.modalService.open(content1, { size: 'xl' });
  }

  assignComponents(dynamiccomponents) {
    if (dynamiccomponents == "trends") {
      this.dummyCoponent = TrendsComponent;
    }
  }

}


class trends_form {
  reset() {
    throw new Error('Method not implemented.');
  }
  machineid: Number;
  babyid: Number;
}
