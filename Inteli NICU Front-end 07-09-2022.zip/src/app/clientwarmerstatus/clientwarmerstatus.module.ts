import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';


import { ClientwarmerstatusRoutingModule } from './clientwarmerstatus-routing.module';
import { ClientwarmerstatusComponent } from './clientwarmerstatus.component';



@NgModule({
  declarations: [ClientwarmerstatusComponent],
  imports: [
    CommonModule,
    ClientwarmerstatusRoutingModule,FormsModule,ReactiveFormsModule
  ]
})
export class ClientwarmerstatusModule { }
