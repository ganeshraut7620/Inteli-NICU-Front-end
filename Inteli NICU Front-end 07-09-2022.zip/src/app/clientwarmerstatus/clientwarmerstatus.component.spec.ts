import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientwarmerstatusComponent } from './clientwarmerstatus.component';

describe('ClientwarmerstatusComponent', () => {
  let component: ClientwarmerstatusComponent;
  let fixture: ComponentFixture<ClientwarmerstatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClientwarmerstatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientwarmerstatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
