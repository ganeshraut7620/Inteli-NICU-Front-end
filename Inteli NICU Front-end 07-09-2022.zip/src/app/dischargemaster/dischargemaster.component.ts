import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MainserviceService } from '../mainservice.service';
import swal from 'sweetalert2';

@Component({
  selector: 'app-dischargemaster',
  templateUrl: './dischargemaster.component.html',
  styleUrls: ['./dischargemaster.component.css']
})
export class DischargemasterComponent implements OnInit {

  clinicalfinding = new FormControl();
  tratmentsummary = new FormControl();
  BabyList = []
  treatmentSummary: any;
  constructor(private mainserviceService: MainserviceService,) {

  }
  panelOpenState = false;

  ngOnInit(): void {
    this.getTreatmentSummary();
  }

  createTreatmentSummary() {
    try {
      console.log("Clinical Data ======", {
        diseaseid: null,
        diseasename: null,
        clinicalfinding: this.clinicalfinding.value,
        tratmentsummary: this.tratmentsummary.value

      })

      if ((this.clinicalfinding.value != null && this.clinicalfinding.value != undefined) && (this.tratmentsummary.value != undefined)) {
        this.mainserviceService.createTratmentSummary({
          clinicalfinding: this.clinicalfinding.value,
          tratmentsummary: this.tratmentsummary.value
        }).subscribe((data) => {
          console.log("doctor notes response===============", data);

          if (data.status_code == "s_402") {
            swal.fire(
              'Good job!',
              'Treatment Summary Added Succsefully!',
              'success'
            );
            this.getTreatmentSummary();
            this.resetTreatmentSummary()
          }
          if (data.status_code == "s_1015") {
            swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: 'Something wrong!'
            });
          }
        });
      } else {
        swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Wrong Input Enter!'
        });
      }

    } catch (err) {
      console.log("err============================", err);
      swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: err
      });
    }
  }

  resetTreatmentSummary () {
    try{
      this.clinicalfinding = new FormControl();
      this.tratmentsummary = new FormControl();

    }catch(err){
      console.log(err);
    }
  }

  getTreatmentSummary () {
    try{
      this.mainserviceService.getTratmentSummary({
        diseasemasterid:null
      }).subscribe((resGet) => {
        console.log("getTreatmentSummary ========",resGet);
        if(resGet && resGet.data){
          this.treatmentSummary = resGet.data;
        }else{
          this.treatmentSummary =[];
        }
      });

    }catch(errTreatmentSummary){
      console.log("err=============",errTreatmentSummary);
    }
  }

}
