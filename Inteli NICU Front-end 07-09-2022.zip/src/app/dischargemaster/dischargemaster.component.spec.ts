import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DischargemasterComponent } from './dischargemaster.component';

describe('DischargemasterComponent', () => {
  let component: DischargemasterComponent;
  let fixture: ComponentFixture<DischargemasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DischargemasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DischargemasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
