import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
// import {MatFormFieldModule} from '@angular/material/form-field';
import { DischargemasterRoutingModule } from './dischargemaster-routing.module';
import { DischargemasterComponent } from './dischargemaster.component';
import {MatExpansionModule} from '@angular/material/expansion';

@NgModule({
  declarations: [DischargemasterComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatExpansionModule,
    DischargemasterRoutingModule
  ]
})
export class DischargemasterModule { }
