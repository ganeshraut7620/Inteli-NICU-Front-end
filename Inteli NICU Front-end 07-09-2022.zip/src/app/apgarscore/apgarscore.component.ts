import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, RequiredValidator,FormBuilder  } from '@angular/forms';
import { MainserviceService } from '../mainservice.service';

@Component({
  selector: 'app-apgarscore',
  templateUrl: './apgarscore.component.html',
  styleUrls: ['./apgarscore.component.css']
})
export class ApgarscoreComponent implements OnInit {
  apgarscore: any;
  trendsform : trends_form = new trends_form();
  machineList: any;
  BabyList: any;
  displayflag:boolean = false;

  constructor(public mainserviceService:MainserviceService) {
    this.getmachinedata();

  }

  ngOnInit(): void {
  }

  machineselect(){
    console.log("After Machine Click => ");
    this.getbabydetails(this.trendsform.machinenid)

  }

  getmachinedata(){

    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    console.log( "session storage value => ",userData);

    let dummy_data ={
      "clientid":userData.clientid
    }

    this.mainserviceService.getmachineclientwise(dummy_data).subscribe((res) => {
      console.log("Get Machine Details => ",res);
      this.machineList = res.data;
      this.trendsform.machinenid = res.data[0].machineid;
      console.log("Machine List =>",this.machineList);
      this.machineselect();

    }, (err) => {
      console.log(err.error);
    });
  }

  getbabydetails(machineid) {

    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    console.log( "session storage value => ",userData);

    let dummy_data ={
      "babyno":null,
      "babyname": null,
      "machineid": machineid,
      "clientid":userData.clientid,
      "isactive": true,
      "page": 1,
      "pagesize": 10900
    }

    this.mainserviceService.getbabyid(dummy_data).subscribe((res) => {
      console.log("Baby Details => ",res.data);
      this.BabyList = res.data;
      this.trendsform.babyid = res.data[0].babyid;
      this.getapgarscorerecord();
      }, (err) => {
            console.log(err.error);

    });

  }

  getapgarscorerecord() {
    this.displayflag = true;
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    console.log( "session storage value => ",userData);

    let dummy_data ={
      "machineid": this.trendsform.machinenid,
      "babyid": this.trendsform.babyid
    }

    this.mainserviceService.getapgarscore(dummy_data).subscribe((res) => {
      console.log("Baby Apgar Score => ",res.data);
      this.apgarscore = res.data;
      }, (err) => {
            console.log(err.error);

    });


  }



}

class trends_form {
  machinenid:Number;
  babyid:Number
}
