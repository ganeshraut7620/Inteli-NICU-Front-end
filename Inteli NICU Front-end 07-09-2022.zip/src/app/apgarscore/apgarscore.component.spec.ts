import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApgarscoreComponent } from './apgarscore.component';

describe('ApgarscoreComponent', () => {
  let component: ApgarscoreComponent;
  let fixture: ComponentFixture<ApgarscoreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApgarscoreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApgarscoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
