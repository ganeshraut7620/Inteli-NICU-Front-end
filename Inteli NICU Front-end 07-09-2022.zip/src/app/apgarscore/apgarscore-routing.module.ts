import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ApgarscoreComponent } from './apgarscore.component';

const routes: Routes = [{
  path:'',
  component:ApgarscoreComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ApgarscoreRoutingModule { }
