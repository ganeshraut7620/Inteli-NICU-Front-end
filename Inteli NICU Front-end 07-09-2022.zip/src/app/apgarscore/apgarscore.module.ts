import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { ApgarscoreRoutingModule } from './apgarscore-routing.module';
import { ApgarscoreComponent } from './apgarscore.component';


@NgModule({
  declarations: [ApgarscoreComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ApgarscoreRoutingModule
  ]
})
export class ApgarscoreModule { }
