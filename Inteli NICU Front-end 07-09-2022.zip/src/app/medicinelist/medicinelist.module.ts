import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { MedicinelistRoutingModule } from './medicinelist-routing.module';
import { MedicinelistComponent } from './medicinelist.component';


@NgModule({
  declarations: [MedicinelistComponent],
  imports: [
    CommonModule,FormsModule,ReactiveFormsModule,
    MedicinelistRoutingModule
  ]
})
export class MedicinelistModule { }
