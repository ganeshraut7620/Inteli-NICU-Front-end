import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, RequiredValidator, FormBuilder } from '@angular/forms';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { MainserviceService } from '../mainservice.service';
import swal from 'sweetalert2';
@Component({
  selector: 'app-medicinelist',
  templateUrl: './medicinelist.component.html',
  styleUrls: ['./medicinelist.component.css']
})
export class MedicinelistComponent implements OnInit {

  registerForm: FormGroup;
  changetext: any = '';
  cattypenamestatus: boolean = false;
  drugs: boolean = false;
  when: boolean = false;
  how: boolean = false;
  frequency: boolean = false;
  dosageunit: boolean = false;
  response_catch: any;

  cattypes: any = ['Category', 'Drug', 'When to give medicine', 'How to give medicine', 'Frequency', 'Dosage Unit'];
  categorys: any;
  catdata: any;
  drugsdata; any;
  whendata: any;
  howdata: any;
  frequencydata: any;
  dosageunitdata: any;



  constructor(private fb: FormBuilder, private modalService: NgbModal, private mainserviceService: MainserviceService) {
    this.getcategory();
    this.getwhenmasterdetails();
    this.gethowmasterdetails();
    this.getfreqdetails();
    this.getdosageunitdetails();
    this.getdruglistdetails();
  }

  _searchTerm: string;

  get searchTerm(): string {
    return this._searchTerm;
  }
  set searchTerm(val: string) {
    this._searchTerm = val;
    //this.filterArray = this.filter(val);
  }

  filter(v: string) {
    return;
  }

  closeBtnClick() {
    this.modalService.dismissAll()
    this.ngOnInit();
  }

  get registerFormControl() {
    return this.registerForm.controls;
  }

  ngOnInit(): void {
    this.registerForm = this.fb.group({
      cattype: ['', Validators.required],
      category: [, Validators.required],
      medicinecategory: ['', Validators.required],
      medicinecategoryid: [],
      drugname: ['', Validators.required],
      whenmedicine: ['', Validators.required],
      howmedicine: ['', Validators.required],
      frequencymedicine: ['', Validators.required],
      dosageunit: ['', Validators.required]
    });
  }

  openModal(targetModal) {
    this.modalService.open(targetModal, {
      centered: true,
      backdrop: 'static',
      size: 'lg'
    })
  }

  openLg(content1) {
    this.modalService.open(content1, { size: 'lg' });
  }

  onSubmit = () => {
    console.log("Medicine Master Form Value => ", this.registerForm.value);
    if (this.registerForm.value.cattype == null) {
      console.log('Something Went Wrong');

    } else if (this.registerForm.value.cattype == "Category") {

      let obj = {
        "medicinecategory": this.registerForm.value.medicinecategory
      }

      console.log("Inside Cat => ", obj);

      this.mainserviceService.createMedicinecategory(obj).subscribe((res) => {
        console.log("category res =>", res);
        this.response_catch = res;
        if (this.response_catch.status_code == "s_405") {
          swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Record already exist!',

          })
          this.closeBtnClick();

        } else if (this.response_catch.status_code == "s_402") {
          swal.fire(
            'Good job!',
            'Medicine Category Added Succsefully!',
            'success'
          );
          this.getcategory();
          this.closeBtnClick();
        } else if (this.response_catch.status_code == "s_1015") {
          swal.fire(
            'Something Wrong!',
            'An Error Occured, Please Contact System Administrator!',
            'error'
          );
          this.closeBtnClick();

        }
        this.closeBtnClick();
      }, (err) => {
        console.log(err.error);
        swal.fire(
          err,
          'error'
        );

      });

    } else if (this.registerForm.value.cattype == "Drug") {

      let obj = {
        "medicinecategoryid": this.registerForm.value.medicinecategoryid,
        "drugname": this.registerForm.value.drugname
      }

      console.log("Inside drug function => ", obj);

      this.mainserviceService.createdrugmaster(obj).subscribe((res) => {
        console.log("Drug res =>", res);
        this.response_catch = res;

        if (this.response_catch.status_code == "s_405") {
          swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Record already exist!',

          })
          this.closeBtnClick();

        } else if (this.response_catch.status_code == "s_402") {
          swal.fire(
            'Good job!',
            'Drug Added Succsefully!',
            'success'
          );
          this.getdruglistdetails();
          this.closeBtnClick();
        } else if (this.response_catch.status_code == "s_1015") {
          swal.fire(
            'Something Wrong!',
            'An Error Occured, Please Contact System Administrator!',
            'error'
          );
          this.closeBtnClick();

        }
        this.closeBtnClick();

      }, (err) => {
        console.log(err.error);
        swal.fire(
          err,
          'error'
        );

      });

    } else if (this.registerForm.value.cattype == "When to give medicine") {

      let obj = {
        "whenmedicine": this.registerForm.value.whenmedicine
      }

      console.log("Inside when function => ", obj);

      this.mainserviceService.createwhenmedcinemaster(obj).subscribe((res) => {
        console.log("when res =>", res);
        this.response_catch = res;

        if (this.response_catch.status_code == "s_405") {
          swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Record already exist!',

          })
          this.closeBtnClick();

        } else if (this.response_catch.status_code == "s_402") {
          swal.fire(
            'Good job!',
            'When Added Succsefully!',
            'success'
          );
          this.getwhenmasterdetails();
          this.closeBtnClick();
        } else if (this.response_catch.status_code == "s_1015") {
          swal.fire(
            'Something Wrong!',
            'An Error Occured, Please Contact System Administrator!',
            'error'
          );
          this.closeBtnClick();

        }
        this.closeBtnClick();

      }, (err) => {
        console.log(err.error);
        swal.fire(
          err,
          'error'
        );

      });

    } else if (this.registerForm.value.cattype == "How to give medicine") {

      let obj = {
        "howmedicine": this.registerForm.value.howmedicine
      }

      console.log("Inside how function => ", obj);

      this.mainserviceService.createhowmaster(obj).subscribe((res) => {
        console.log("how res =>", res);
        this.response_catch = res;

        if (this.response_catch.status_code == "s_405") {
          swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Record already exist!',

          })
          this.closeBtnClick();

        } else if (this.response_catch.status_code == "s_402") {
          swal.fire(
            'Good job!',
            'How Added Succsefully!',
            'success'
          );
          this.gethowmasterdetails();
          this.closeBtnClick();
        } else if (this.response_catch.status_code == "s_1015") {
          swal.fire(
            'Something Wrong!',
            'An Error Occured, Please Contact System Administrator!',
            'error'
          );
          this.closeBtnClick();

        }
        this.closeBtnClick();
      }, (err) => {
        console.log(err.error);
        swal.fire(
          err,
          'error'
        );

      });

    } else if (this.registerForm.value.cattype == "Frequency") {

      let obj = {
        "frequencymedicine": this.registerForm.value.frequencymedicine
      }

      console.log("Inside Frequency function => ", obj);

      this.mainserviceService.createfrequencymaster(obj).subscribe((res) => {
        console.log("Frequency res =>", res);
        this.response_catch = res;

        if (this.response_catch.status_code == "s_405") {
          swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Record already exist!',

          })
          this.closeBtnClick();

        } else if (this.response_catch.status_code == "s_402") {
          swal.fire(
            'Good job!',
            'Frequency Added Succsefully!',
            'success'
          );
          this.getfreqdetails();
          this.closeBtnClick();
        } else if (this.response_catch.status_code == "s_1015") {
          swal.fire(
            'Something Wrong!',
            'An Error Occured, Please Contact System Administrator!',
            'error'
          );
          this.closeBtnClick();

        }
        this.closeBtnClick();

      }, (err) => {
        console.log(err.error);
        swal.fire(
          err,
          'error'
        );

      });

    } else if (this.registerForm.value.cattype == "Dosage Unit") {

      let obj = {
        "dosageunit": this.registerForm.value.dosageunit
      }

      console.log("Inside Dosage function => ", obj);

      this.mainserviceService.createdosageunitmaster(obj).subscribe((res) => {
        console.log("Dosage res =>", res);
        this.response_catch = res;

        if (this.response_catch.status_code == "s_405") {
          swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Record already exist!',

          })
          this.closeBtnClick();

        } else if (this.response_catch.status_code == "s_402") {
          swal.fire(
            'Good job!',
            'Dosage Unit Added Succsefully!',
            'success'
          );
          this.getdosageunitdetails();
          this.closeBtnClick();
        } else if (this.response_catch.status_code == "s_1015") {
          swal.fire(
            'Something Wrong!',
            'An Error Occured, Please Contact System Administrator!',
            'error'
          );
          this.closeBtnClick();

        }
        this.closeBtnClick();


        this.closeBtnClick();
      }, (err) => {
        swal.fire(
          err,
          'error'
        );

      });

    }

    this.cattypenamestatus = false;
    this.drugs = false;
    this.when = false;
    this.how = false;
    this.frequency = false;
    this.dosageunit = false;


  }


  getdruglistdetails() {

    let changecategoryid = {
      "drugid": null,
      "medicinecategoryid": null
    }

    this.mainserviceService.getdruglist(changecategoryid).subscribe((res) => {

      console.log("Drug List  =>", res);

      if (res.status_code == "s_407") {
        this.drugsdata = res.data;
        console.log("Druglist => ", this.drugsdata);
      }

    }, (err) => {
      console.log(err.error);

    });
  }


  getcategory() {
    let obj = {
      "medicinecategoryid": null
    }

    this.mainserviceService.getMedicinecategory(obj).subscribe((res) => {
      console.log("Categorys =>", res);
      if (res.status_code == "s_407") {
        this.categorys = res.data;
        this.catdata = res.data;
        // console.log("Category => ",this.cat);
      }

    }, (err) => {
      console.log(err.error);

    });


  }


  getwhenmasterdetails() {

    let obj = {
      "whenmedicineid": null
    }

    this.mainserviceService.getwhenmaster(obj).subscribe((res) => {

      console.log("Get when data =>", res);

      if (res.status_code == "s_407") {
        this.whendata = res.data;
        console.log("When to give Medicine =>", this.whendata)

      }

    }, (err) => {
      console.log(err.error);

    });

  }

  gethowmasterdetails() {

    let obj = {
      "howmedicineid": null
    }

    this.mainserviceService.gethowmaster(obj).subscribe((res) => {

      console.log("Get how data =>", res);

      if (res.status_code == "s_407") {
        this.howdata = res.data;
        console.log("How to give Medicine => ", this.howdata)
      }
    }, (err) => {
      console.log(err.error);

    });

  }

  getfreqdetails() {

    let obj = {
      "frquencymedicineid": null
    }

    this.mainserviceService.getfrequency(obj).subscribe((res) => {

      console.log("Get freq data =>", res);

      if (res.status_code == "s_407") {
        this.frequencydata = res.data;
        console.log("Frequency Data =>", this.frequencydata)
      }
    }, (err) => {
      console.log(err.error);

    });

  }

  getdosageunitdetails() {

    let obj = {
      "dosageunitid": null
    }

    this.mainserviceService.getdosageunit(obj).subscribe((res) => {

      console.log("Get Dosage data =>", res);

      if (res.status_code == "s_407") {
        this.dosageunitdata = res.data;
        console.log("Dosage Unit Data => ", this.dosageunitdata);
      }
    }, (err) => {
      console.log(err.error);

    });

  }

  onchangestatus() {
    if (this.registerForm.value.cattype == null) {
      console.log("Category not selected");
    } else if (this.registerForm.value.cattype == "Category") {
      this.cattypenamestatus = true;
      this.drugs = false;
      this.when = false;
      this.how = false;
      this.frequency = false;
      this.dosageunit = false;
      this.changetext = this.registerForm.value.cattype;
    } else if (this.registerForm.value.cattype == "Drug") {
      this.cattypenamestatus = false;
      this.drugs = true;
      this.when = false;
      this.how = false;
      this.frequency = false;
      this.dosageunit = false;
      // this.changetext = this.registerForm.value.cattype;
    } else if (this.registerForm.value.cattype == "When to give medicine") {
      this.cattypenamestatus = false;
      this.drugs = false;
      this.when = true;
      this.how = false;
      this.frequency = false;
      this.dosageunit = false;
      // this.changetext = this.registerForm.value.cattype;
    } else if (this.registerForm.value.cattype == "How to give medicine") {
      this.cattypenamestatus = false;
      this.drugs = false;
      this.when = false;
      this.how = true;
      this.frequency = false;
      this.dosageunit = false;
      // this.changetext = this.registerForm.value.cattype;
    } else if (this.registerForm.value.cattype == "Frequency") {
      this.cattypenamestatus = false;
      this.drugs = false;
      this.when = false;
      this.how = false;
      this.frequency = true;
      this.dosageunit = false;
      // this.changetext = this.registerForm.value.cattype;
    } else if (this.registerForm.value.cattype == "Dosage Unit") {
      this.cattypenamestatus = false;
      this.drugs = false;
      this.when = false;
      this.how = false;
      this.frequency = false;
      this.dosageunit = true;
      // this.changetext = this.registerForm.value.cattype;
    }

  }

}
