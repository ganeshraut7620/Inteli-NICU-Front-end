import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { ClientdetailsRoutingModule } from './clientdetails-routing.module';
import { ClientdetailsComponent } from './clientdetails.component';


@NgModule({
  declarations: [ClientdetailsComponent],
  imports: [
    CommonModule,
    FormsModule,ReactiveFormsModule,
    ClientdetailsRoutingModule
  ]
})
export class ClientdetailsModule { }
