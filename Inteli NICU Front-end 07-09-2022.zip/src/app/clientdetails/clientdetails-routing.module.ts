import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ClientdetailsComponent } from './clientdetails.component';
const routes: Routes = [
  { path:'', component: ClientdetailsComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ClientdetailsRoutingModule { }
