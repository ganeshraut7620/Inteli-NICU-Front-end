import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, RequiredValidator,FormBuilder  } from '@angular/forms';
import { MainserviceService } from '../mainservice.service';
import { ClientmasterService } from '../clientmaster/clientmaster.service';
import { Clientmaster } from '../clientmaster/clientmaster';


@Component({
  selector: 'app-clientdetails',
  templateUrl: './clientdetails.component.html',
  styleUrls: ['./clientdetails.component.css']
})
export class ClientdetailsComponent implements OnInit {
  page = 1;

  clientList: Clientmaster[] = this.clientmasterService.getClientmaster();


  filterArray:Clientmaster[];
  tempsiteList: any;

  constructor(public mainserviceService :MainserviceService , public clientmasterService:ClientmasterService) {
    this.getSiteDetails(this.page);
    
    // this.getClientMasterDetails(this.page);

  }


  ngOnInit(): void {

  }

  _searchTerm: string;
    get searchTerm(): string {
        return this._searchTerm;
    }
    set searchTerm(val: string) {
        this._searchTerm = val;
        this.filterArray = this.filter(val);
    }

    filter(v: string) {
        return this.tempsiteList.filter(x => x.clientname.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.machinename.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.fieldengineername.toLowerCase().indexOf(v.toLowerCase()) !== -1);
    }


  getClientMasterDetails(page){
    let dummy_data ={
      "usersubcategoryid": 2,
      "page": page,
      "pagesize": 5
    }

    this.mainserviceService.getUserDetails(dummy_data).subscribe((res) => {
      console.log(res);
      this.filterArray = res.data;
      this.clientList = res.data;

      console.log(this.filterArray);
        }, (err) => {
      console.log(err.error);
    });

  }

  getSiteDetails(page){
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    console.log( "session storage value => ",userData);

      let dummy_data ={
        "siteid": null,
        "locationid": null,
        "sitecode": null,
        "sitename": null,
        "clientid": null,
        "machineid": null,
        "fieldengineerid": null,
        "isactive": true,
        "page": page,
        "pagesize": 5
      }


    this.mainserviceService.getSite(dummy_data).subscribe((data1) => {
      console.log("Get Site Details =>",data1);
      this.filterArray = data1.data;
      this.tempsiteList = data1.data;
      console.log("Site Details =>",this.tempsiteList );

    }, (err) => {
      console.log(err.error);
    });

}
  previous(){
    if(this.page>=2){
    this.page = this.page - 1;
    console.log("decriment => ",this.page);
    this.getSiteDetails(this.page);
    }else{
  
    }
  }
  
  next(){
    this.page = this.page + 1;
    console.log("Incriment => ",this.page);
    this.getSiteDetails(this.page);
  }

}

