import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BootstraptestRoutingModule } from './bootstraptest-routing.module';
import { BootstraptestComponent } from './bootstraptest.component';


@NgModule({
  declarations: [BootstraptestComponent],
  imports: [
    CommonModule,
    BootstraptestRoutingModule
  ]
})
export class BootstraptestModule { }
