import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bootstraptest',
  templateUrl: './bootstraptest.component.html',
  styleUrls: ['./bootstraptest.component.css']
})
export class BootstraptestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
