import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerservicedashboardComponent } from './customerservicedashboard.component';

const routes: Routes = [{path:'',component:CustomerservicedashboardComponent}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CustomerservicedashboardRoutingModule { }
