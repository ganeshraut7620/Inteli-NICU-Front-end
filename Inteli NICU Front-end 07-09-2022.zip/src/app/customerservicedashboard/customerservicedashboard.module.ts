import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CustomerservicedashboardRoutingModule } from './customerservicedashboard-routing.module';
import { CustomerservicedashboardComponent } from './customerservicedashboard.component';


@NgModule({
  declarations: [CustomerservicedashboardComponent],
  imports: [
    CommonModule,
    CustomerservicedashboardRoutingModule
  ]
})
export class CustomerservicedashboardModule { }
