import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerservicedashboardComponent } from './customerservicedashboard.component';

describe('CustomerservicedashboardComponent', () => {
  let component: CustomerservicedashboardComponent;
  let fixture: ComponentFixture<CustomerservicedashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerservicedashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerservicedashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
