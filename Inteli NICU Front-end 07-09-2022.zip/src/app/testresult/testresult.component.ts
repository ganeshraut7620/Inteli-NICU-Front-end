import { Component, OnInit } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material/tabs';
import * as moment from 'moment';
import swal from 'sweetalert2';
import { MainserviceService } from '../mainservice.service';
@Component({
  selector: 'app-testresult',
  templateUrl: './testresult.component.html',
  styleUrls: ['./testresult.component.css']
})
export class TestresultComponent implements OnInit {
  date: string;
  time: string;
  view = false;
  BabayList: any[];
  selectedBaby: string = "";
  viewFlag = false;
  NurseList: any[];
  selectedNurse: string = "";

  panelOpenState = false;
  testReportList = [];
  HMG = null;
  ROP = null;
  NAKICAL = null;
  BlOODCULTURE = null;
  ECHO = null;
  SBR = null;
  URINEFUNGUS = null;
  USGBRAIN = null;
  XRAY = null;
  nurseid: any;
  BabyList = [];
  babyid: any;
  pageadmit: number = 1;
  pagedischarge: number = 1;
  recentInvestiggation = ["HMG", "Biochemistry", "Sepsis Screen", "S.Biirubin", "Others", "NBST", "OOP", "Metabolic Workup", "Urine", "Hypoglycemia Workup", "Inflamatory Markers", "LFT"];
  recentInvestigation = "HMG";

  recentInvestigationDate: any = "";
  imagingDate: any = "";

  // HBG
  HB: '';
  WBC: '';
  PLATELET: '';
  PCR: '';
  NEUTROPHILS: '';
  ANC: '';

  //Biochemistry
  RFTUREA: '';
  Creatine: '';
  SE: '';
  Na: '';
  K: '';
  Ca: '';
  Mg: '';

  //Sepsis Screen
  CRP: "";
  BloodCells: "";
  UrineRoutine: "";
  CSF: "";
  UrineCLS: "";
  CSFCLS: "";
  ETCLS: "";

  //Blood Group
  MotherBlood: "";
  BabyBlood: "";
  //S.Biirubin
  SBiirubin_T: "";
  direct: "";

  //imaging field
  USGBrain: any = "";
  USG_ATP: any = "";
  USG_KUB: any = "";

  //opp
  Total_Cal: any = "";
  PO4: any = "";
  ALP: any = "";
  VitD: any = "";

  //Metabolic Workup
  Ammonia: any = "";

  //Others: 
  Gastric_Aspirate: any = "";
  Fluid_Cytology: any = "";
  Biopsy: any = "";
  TFT: any = "";
  TORCH_IgG: any = "";
  IgM: any = "";

  //NBST
  NBST: any = "";

  //Urine
  urineCmv: any = "";

  //Hypoglycemia Workup
  RBS: any = "";
  Sv: any = "";
  Cortisol: any = "";
  Sv_Insulin: any = "";

  //Inflamatory Markers:
  Ferrite: any = "";
  Fibrinogen: any = "";

  //LFT
  SGPT: any = "";
  SGOT: any = "";
  GGT: any = "";
  ALPLFT: any = "";
  Bilirubin: any = "";
  Protien: any = "";
  PTCINR: any = "";
  APTT: any = "";

  //view flag 
  viewRecentFlag: boolean = false;
  viewImagingFlag: boolean = false;

  hbgFlag: boolean = true;
  bioChemistryFlag: boolean = false;
  screenFlag: boolean = false;
  bloodgroupFlag: boolean = false;
  biirubinFlag: boolean = false;
  NBSTFlag: boolean = false;

  recentInvestigationList = [];
  recentInvestigationBiochemistryList = [];
  recentInvestigationSepsisScreenList = [];
  recentInvestigationSBiirubinList = [];
  recentIvestigationoppList = []
  recentIvestigationMetabolic_WorkupList = []
  recentIvestigationOthersList = []
  recentIvestigationNBSTList = [];
  recentIvestigationUrineList = [];
  recentIvestigationHyPoglycemia_WorkupList = [];
  recentIvestigationHyInflamatoryMarkersList = [];
  recentIvestigationLFTList = []

  //"USG Brain", "USB Abdomen", "USG(KUB)"
  USG_BrainViweList = [];
  USG_ATPViewList = [];
  USG_KUBViewList = [];


  bioChemistryList = [];

  //imaging
  imaging: any = "";
  imagingList = ["USG Brain", "USB Abdomen"];

  //imaging flag
  USGBrainFlag: boolean = true;
  USG_ATPFlag: boolean = false;
  USG_KUBFlag: boolean = false;
  OPPFlag: boolean = false;
  Metabolic_WorkupFlag: boolean = false;
  OthersFlag: boolean = false;
  UrineFlag: boolean = false;
  Hypoglycemia_WorkupFlag: boolean = false;
  Inflamatory_MarkersFlag: boolean = false;
  LFTFlag: boolean = false;
  imagingHeader: string;

  constructor(private mainserviceService: MainserviceService) {
    this.date = moment().format('L');
    this.time = moment().format('LTS');
  }

  ngOnInit(): void {
    this.getNursemaster();
    this.getbabydetails(1, "admitted");
  }

  changeRecentView() {
    try {
      console.log("view flag =================", this.viewRecentFlag);
      this.getRecentInvestigation("HMG");
    } catch (err) {
      console.log(err);
    }
  }

  getbabydetails(pageinc, status) {
    try {
      this.mainserviceService.getbabyid({
        "babyno": null,
        "babyname": null,
        "machineid": null,
        "clientid": JSON.parse(sessionStorage.getItem('userInfo1')).clientid,
        "babystatus": status,
        "isactive": true,
        "page": pageinc,
        "pagesize": 5
      }).subscribe((res) => {
        console.log("Baby Details => ", res.data);
        this.BabyList = res.data ? res.data : [];
      }, (err) => {
        console.log(err.error);

      });

    } catch (err) {
      console.log(err);
    }
  }

  onChange(event: MatTabChangeEvent) {
    try {
      const tab = event.tab.textLabel;
      console.log(tab);

      if (tab === "Admited") {
        this.getbabydetails(1, "admitted");
      } else if (tab == "Discharged") {
        this.getbabydetails(1, "discharge");

      }
    } catch (err) {
      console.log(err)
    }
  }

  selectedBabys = (baby) => {
    console.log("BABY DETAILS =================", baby);
    this.babyid = baby.babyid;
    this.resetRecentInvestigation();
    this.recetRecentTable();
    
  }

  admitprevious() {
    if (this.pageadmit >= 2) {
      this.pageadmit = this.pageadmit - 1;
      console.log("decriment => ", this.pageadmit)
      // this.getbabydetails(this.page);
      this.getbabydetails(this.pageadmit, "admitted");
    }
  }

  admitnext() {
    this.pageadmit = this.pageadmit + 1;
    console.log("Incriment => ", this.pageadmit)
    // this.getbabydetails(this.page);
    this.getbabydetails(this.pageadmit, "admitted");
  }

  dischargeprevious() {
    if (this.pagedischarge >= 2) {
      this.pagedischarge = this.pagedischarge - 1;
      console.log("decriment => ", this.pagedischarge)
      // this.getbabydetails(this.page);
      this.getbabydetails(this.pagedischarge, "discharge");
    }
  }

  dischargenext() {
    this.pagedischarge = this.pagedischarge + 1;
    console.log("Incriment => ", this.pagedischarge)
    // this.getbabydetails(this.page);
    this.getbabydetails(this.pagedischarge, "discharge");

  }

  getNursemaster() {
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    let dummy_data = {
      "usercategoryid": 9,
      "usersubcategoryid": null,
      "clientid": userData.clientid,
      "page": 1,
      "pagesize": 100000
    }

    this.mainserviceService.getUser(dummy_data).subscribe((res) => {
      console.log("Nurse Master Data => ", res.data);
      this.NurseList = res.data;
    }, (err) => {
      console.log(err.error);
    });
  }

  selectedInvestigation(recentInvestigation) {
    try {
      if (recentInvestigation) {
        console.log("Recent investigation ====", recentInvestigation);
        switch (recentInvestigation) {
          case 'HMG':
            this.hbgFlag = true;
            this.bioChemistryFlag = false;
            this.screenFlag = false;
            this.biirubinFlag = false;
            this.OPPFlag = false;
            this.Metabolic_WorkupFlag = false;
            this.OthersFlag = false;
            this.NBSTFlag = false;
            this.UrineFlag = false;
            this.Hypoglycemia_WorkupFlag = false;
            this.Inflamatory_MarkersFlag = false;
            this.LFTFlag = false;
            break;
          case 'Biochemistry':
            this.hbgFlag = false;
            this.bioChemistryFlag = true;
            this.screenFlag = false;
            this.biirubinFlag = false;
            this.OPPFlag = false;
            this.Metabolic_WorkupFlag = false;
            this.OthersFlag = false;
            this.NBSTFlag = false;
            this.UrineFlag = false;
            this.Hypoglycemia_WorkupFlag = false;
            this.Inflamatory_MarkersFlag = false;
            this.LFTFlag = false;
            break;
          case 'Sepsis Screen':
            this.hbgFlag = false;
            this.bioChemistryFlag = false;
            this.screenFlag = true;
            this.biirubinFlag = false;
            this.OPPFlag = false;
            this.Metabolic_WorkupFlag = false;
            this.OthersFlag = false;
            this.NBSTFlag = false;
            this.UrineFlag = false;
            this.Hypoglycemia_WorkupFlag = false;
            this.Inflamatory_MarkersFlag = false;
            this.LFTFlag = false;
            break;
          case 'Blood Group':
            this.hbgFlag = false;
            this.bioChemistryFlag = false;
            this.screenFlag = false;
            this.biirubinFlag = false;
            this.OPPFlag = false;
            this.Metabolic_WorkupFlag = false;
            this.OthersFlag = false;
            this.NBSTFlag = false;
            this.UrineFlag = false;
            this.Hypoglycemia_WorkupFlag = false;
            this.Inflamatory_MarkersFlag = false;
            this.LFTFlag = false;
            break;
          case 'S.Biirubin':
            this.hbgFlag = false;
            this.bioChemistryFlag = false;
            this.screenFlag = false;
            this.biirubinFlag = true;
            this.OPPFlag = false;
            this.Metabolic_WorkupFlag = false;
            this.OthersFlag = false;
            this.NBSTFlag = false;
            this.UrineFlag = false;
            this.Hypoglycemia_WorkupFlag = false;
            this.Inflamatory_MarkersFlag = false;
            this.LFTFlag = false;
            break;
          case 'OOP':
            this.hbgFlag = false;
            this.bioChemistryFlag = false;
            this.screenFlag = false;
            this.biirubinFlag = false;
            this.OPPFlag = true;
            this.Metabolic_WorkupFlag = false;
            this.OthersFlag = false;
            this.NBSTFlag = false;
            this.UrineFlag = false;
            this.Hypoglycemia_WorkupFlag = false;
            this.Inflamatory_MarkersFlag = false;
            this.LFTFlag = false;
            break;
          case 'Metabolic Workup':
            this.hbgFlag = false;
            this.bioChemistryFlag = false;
            this.screenFlag = false;
            this.biirubinFlag = false;
            this.OPPFlag = false;
            this.Metabolic_WorkupFlag = true;
            this.OthersFlag = false;
            this.NBSTFlag = false;
            this.UrineFlag = false;
            this.Hypoglycemia_WorkupFlag = false;
            this.Inflamatory_MarkersFlag = false;
            this.LFTFlag = false;
            break;
          case 'Others':
            this.hbgFlag = false;
            this.bioChemistryFlag = false;
            this.screenFlag = false;
            this.biirubinFlag = false;
            this.OPPFlag = false;
            this.Metabolic_WorkupFlag = false;
            this.OthersFlag = true;
            this.NBSTFlag = false;
            this.UrineFlag = false;
            this.Hypoglycemia_WorkupFlag = false;
            this.Inflamatory_MarkersFlag = false;
            this.LFTFlag = false;
            break;
          case 'NBST':
            this.hbgFlag = false;
            this.bioChemistryFlag = false;
            this.screenFlag = false;
            this.biirubinFlag = false;
            this.OPPFlag = false;
            this.Metabolic_WorkupFlag = false;
            this.OthersFlag = false;
            this.NBSTFlag = true;
            this.UrineFlag = false;
            this.Hypoglycemia_WorkupFlag = false;
            this.Inflamatory_MarkersFlag = false;
            this.LFTFlag = false;
            break;
          case 'Urine':
            this.hbgFlag = false;
            this.bioChemistryFlag = false;
            this.screenFlag = false;
            this.biirubinFlag = false;
            this.OPPFlag = false;
            this.Metabolic_WorkupFlag = false;
            this.OthersFlag = false;
            this.NBSTFlag = false;
            this.UrineFlag = true;
            this.Hypoglycemia_WorkupFlag = false;
            this.Inflamatory_MarkersFlag = false;
            this.LFTFlag = false;
            break;
          case 'Hypoglycemia Workup':
            this.hbgFlag = false;
            this.bioChemistryFlag = false;
            this.screenFlag = false;
            this.biirubinFlag = false;
            this.OPPFlag = false;
            this.Metabolic_WorkupFlag = false;
            this.OthersFlag = false;
            this.NBSTFlag = false;
            this.UrineFlag = false;
            this.Hypoglycemia_WorkupFlag = true;
            this.Inflamatory_MarkersFlag = false;
            this.LFTFlag = false;
            break;
          case 'Inflamatory Markers':
            this.hbgFlag = false;
            this.bioChemistryFlag = false;
            this.screenFlag = false;
            this.biirubinFlag = false;
            this.OPPFlag = false;
            this.Metabolic_WorkupFlag = false;
            this.OthersFlag = false;
            this.NBSTFlag = false;
            this.UrineFlag = false;
            this.Hypoglycemia_WorkupFlag = false;
            this.Inflamatory_MarkersFlag = true;
            this.LFTFlag = false;
            break;
          case 'LFT':
            this.hbgFlag = false;
            this.bioChemistryFlag = false;
            this.screenFlag = false;
            this.biirubinFlag = false;
            this.OPPFlag = false;
            this.Metabolic_WorkupFlag = false;
            this.OthersFlag = false;
            this.NBSTFlag = false;
            this.UrineFlag = false;
            this.Hypoglycemia_WorkupFlag = false;
            this.Inflamatory_MarkersFlag = false;
            this.LFTFlag = true;
            break;
        }
      }
    } catch (err) {
      console.log(err);
    }
  }

  selectedImaging(row) {
    try {
      console.log("Imaging Data ========", row);
      try {
        if (this.imaging) {
          console.log("Recent imaging ====", this.imaging);
          switch (this.imaging) {
            case 'USG Brain':
              this.USGBrainFlag = true;
              this.USG_ATPFlag = false;

              break;
            case 'USB Abdomen':
              this.USGBrainFlag = false;
              this.USG_ATPFlag = true;
             
              break;
          }
        }
      } catch (err) {
        console.log(err);
      }
    } catch (err) {
      console.log(err);
    }
  }

  //add recent investigation 
  addRecentInvestigation() {
    try {
      // console.log("Recent Investigation ==========",this.recentInvestigationDate,moment(new Date(this.recentInvestigationDate)).format('YYYY-MM-DD HH:mm:ss'));
      console.log("Recent Investigation ============================",{
        "babyid": this.babyid,
        "clientid": JSON.parse(sessionStorage.getItem('userInfo1')).usermasterid,
        "recentInvestigationHeader": this.recentInvestigation,
        "recentInvestigationDate": moment(new Date(this.recentInvestigationDate)).format('YYYY-MM-DD HH:mm:ss'),
        "HB": this.HB ? this.HB : '-',
        "WBC": this.WBC ? this.WBC : '-',
        "PLATELET": this.PLATELET ? this.PLATELET : '-',
        "PCR": this.PCR ? this.PCR : '-',
        "NEUTROPHILS": this.NEUTROPHILS ? this.NEUTROPHILS : '-',
        "ANC": this.ANC ? this.ANC : '-',
        "RFTUREA": this.RFTUREA ? this.RFTUREA : '-',
        "Creatine": this.Creatine ? this.Creatine : '-',
        "SE": this.SE ? this.SE : '-',
        "Na": this.Na ? this.Na : '-',
        "K": this.K ? this.K : '-',
        "Ca": this.Ca ? this.Ca : '-',
        "Mg": this.Mg ? this.Mg : '-',
        "CRP": this.CRP ? this.CRP : '-',
        "BloodCells": this.BloodCells ? this.BloodCells : '-',
        "UrineRoutine": this.UrineRoutine ? this.UrineRoutine : '-',
        "CSF": this.CSF ? this.CSF : '-',
        "UrineCLS": this.UrineCLS ? this.UrineCLS : '-',
        "CSFCLS": this.CSFCLS ? this.CSFCLS : '-',
        "ETCLS": this.ETCLS ? this.ETCLS : '-',
        "MotherBlood": '-',
        "BabyBlood": '-',
        "SBiirubin_T": this.SBiirubin_T ? this.SBiirubin_T : '-',
        "direct": this.direct ? this.direct : '-',
        "Gastric_Aspirate": this.Gastric_Aspirate ? this.Gastric_Aspirate : '-',
        "Fluid_Cytology": this.Fluid_Cytology ? this.Fluid_Cytology : '-',
        "Biopsy": this.Biopsy ? this.Biopsy : '-',
        "TFT": this.TFT ? this.TFT : '-',
        "TORCH_IgG": this.TORCH_IgG ? this.TORCH_IgG : '-',
        "IgM": this.IgM ? this.IgM : '-',
        "NBST": this.NBST ? this.NBST : '-',
        "Total_Cal": this.Total_Cal ? this.Total_Cal : '-',
        "PO4": this.PO4 ? this.PO4 : '-',
        "ALP": this.ALP ? this.ALP : '-',
        "VitD": this.VitD ? this.VitD : '-',
        "Ammonia": this.Ammonia ? this.Ammonia : '-',
        "urineCmv": this.urineCmv ? this.urineCmv : '-',
        "RBS": this.RBS ? this.RBS : '-',
        "Sv": this.Sv ? this.Sv : '-',
        "Cortisol": this.Cortisol ? this.Cortisol : '-',
        "Sv_Insulin": this.Sv_Insulin ? this.Sv_Insulin : '-',
        "Ferrite": this.Ferrite ? this.Ferrite : '-',
        "Fibrinogen": this.Fibrinogen ? this.Fibrinogen : '-',
        "SGPT": this.SGPT ? this.SGPT : '-',
        "SGOT": this.SGOT ? this.SGOT : '-',
        "GGT": this.GGT ? this.GGT : '-',
        "ALPLFT": this.ALPLFT ? this.ALPLFT : '-',
        "Bilirubin": this.Bilirubin ? this.Bilirubin : '-',
        "Protien": this.Protien ? this.Protien : '-',
        "PTCINR": this.PTCINR ? this.PTCINR : '-',
        "APTT": this.APTT ? this.APTT : '-'
      });

      this.mainserviceService.createRecentInvestigation({
        "babyid": this.babyid,
        "clientid": JSON.parse(sessionStorage.getItem('userInfo1')).usermasterid,
        "recentInvestigationHeader": this.recentInvestigation,
        "recentInvestigationDate": moment(new Date(this.recentInvestigationDate)).format('YYYY-MM-DD HH:mm:ss'),
        "HB": this.HB ? this.HB : '-',
        "WBC": this.WBC ? this.WBC : '-',
        "PLATELET": this.PLATELET ? this.PLATELET : '-',
        "PCR": this.PCR ? this.PCR : '-',
        "NEUTROPHILS": this.NEUTROPHILS ? this.NEUTROPHILS : '-',
        "ANC": this.ANC ? this.ANC : '-',
        "RFTUREA": this.RFTUREA ? this.RFTUREA : '-',
        "Creatine": this.Creatine ? this.Creatine : '-',
        "SE": this.SE ? this.SE : '-',
        "Na": this.Na ? this.Na : '-',
        "K": this.K ? this.K : '-',
        "Ca": this.Ca ? this.Ca : '-',
        "Mg": this.Mg ? this.Mg : '-',
        "CRP": this.CRP ? this.CRP : '-',
        "BloodCells": this.BloodCells ? this.BloodCells : '-',
        "UrineRoutine": this.UrineRoutine ? this.UrineRoutine : '-',
        "CSF": this.CSF ? this.CSF : '-',
        "UrineCLS": this.UrineCLS ? this.UrineCLS : '-',
        "CSFCLS": this.CSFCLS ? this.CSFCLS : '-',
        "ETCLS": this.ETCLS ? this.ETCLS : '-',
        "MotherBlood": '-',
        "BabyBlood": '-',
        "SBiirubin_T": this.SBiirubin_T ? this.SBiirubin_T : '-',
        "direct": this.direct ? this.direct : '-',
        "Gastric_Aspirate": this.Gastric_Aspirate ? this.Gastric_Aspirate : '-',
        "Fluid_Cytology": this.Fluid_Cytology ? this.Fluid_Cytology : '-',
        "Biopsy": this.Biopsy ? this.Biopsy : '-',
        "TFT": this.TFT ? this.TFT : '-',
        "TORCH_IgG": this.TORCH_IgG ? this.TORCH_IgG : '-',
        "IgM": this.IgM ? this.IgM : '-',
        "NBST": this.NBST ? this.NBST : '-',
        "Total_Cal": this.Total_Cal ? this.Total_Cal : '-',
        "PO4": this.PO4 ? this.PO4 : '-',
        "ALP": this.ALP ? this.ALP : '-',
        "VitD": this.VitD ? this.VitD : '-',
        "Ammonia": this.Ammonia ? this.Ammonia : '-',
        "urineCmv": this.urineCmv ? this.urineCmv : '-',
        "RBS": this.RBS ? this.RBS : '-',
        "Sv": this.Sv ? this.Sv : '-',
        "Cortisol": this.Cortisol ? this.Cortisol : '-',
        "Sv_Insulin": this.Sv_Insulin ? this.Sv_Insulin : '-',
        "Ferrite": this.Ferrite ? this.Ferrite : '-',
        "Fibrinogen": this.Fibrinogen ? this.Fibrinogen : '-',
        "SGPT": this.SGPT ? this.SGPT : '-',
        "SGOT": this.SGOT ? this.SGOT : '-',
        "GGT": this.GGT ? this.GGT : '-',
        "ALPLFT": this.ALPLFT ? this.ALPLFT : '-',
        "Bilirubin": this.Bilirubin ? this.Bilirubin : '-',
        "Protien": this.Protien ? this.Protien : '-',
        "PTCINR": this.PTCINR ? this.PTCINR : '-',
        "APTT": this.APTT ? this.APTT : '-'
      }).subscribe((res) => {
        console.log("Create RecentInvestigation => ", res);
        if (res) {
          swal.fire(
            'Good job!',
            `${this.recentInvestigation} Added Succsefully!`,
            'success'
          );
          this.resetRecentInvestigation()
        } else {
          console.log("something wrong");
          swal.fire(
            'Bad Response!',
            'An Error Occured, Please Contact System Administrator!',
             'error'
           );
           this.resetRecentInvestigation()
        }
      }, (err) => {
        console.log(err.error);
      });
    } catch (err) {
      console.log(err);
    }
  }

  //reset recent investigation
  resetRecentInvestigation = () => {
    try{
      this.recentInvestigation ="";
      this.recentInvestigationDate  ="";
      this.HB  ="";
      this.WBC  ="";
      this.PLATELET  ="";
      this.PCR  ="";
      this.NEUTROPHILS  ="";  
      this.ANC  ="";
      this.RFTUREA ="";
      this.Creatine  ="";
      this.SE ="";
      this.Na ="";
      this.K ="";
      this.Ca ="";
      this.Mg  ="";
      this.CRP ="";
      this.BloodCells  ="";
      this.UrineRoutine  ="";
      this.CSF  ="";
      this.UrineCLS  ="";
      this.CSFCLS  ="";
      this.ETCLS  ="";
      this.MotherBlood  ="" ,
      this.BabyBlood  ="", 
      this.SBiirubin_T  =""; 
      this.direct  =""; 
      this.Gastric_Aspirate  =""; 
      this.Fluid_Cytology  ="";
      this.Biopsy  ="";
      this.TFT  ="";
      this.TORCH_IgG  =""; 
      this.IgM   ="";
      this.NBST   ="";
      this.Total_Cal  ="";
      this.PO4 ="";
      this.ALP  ="";
      this.VitD  ="";
      this.Ammonia  ="";
      this.urineCmv  ="";
      this.RBS  ="";
      this.Sv ="";
      this.Cortisol =""; 
      this.Sv_Insulin  ="";
      this.Ferrite  ="";
      this.Fibrinogen  ="";
      this.SGPT  ="";
      this.SGOT  ="";
      this.GGT ="";
      this.ALPLFT  ="";
      this.Bilirubin ="";
      this.Protien ="";
      this.PTCINR  =""; 
      this.APTT ="";
    }catch(err){
      console.log(err);
    }
  }

  //resetTable
  recetRecentTable = () => {
    this.recentInvestigationList = [];
    this.recentInvestigationBiochemistryList = [];
    this.recentInvestigationSepsisScreenList = [];
    this.recentInvestigationSBiirubinList = []; 
    this.recentIvestigationoppList = []
    this.recentIvestigationMetabolic_WorkupList = []
    this.recentIvestigationOthersList = []
    this.recentIvestigationNBSTList = [];
    this.recentIvestigationUrineList = [];
    this.recentIvestigationHyPoglycemia_WorkupList = [];
    this.recentIvestigationHyInflamatoryMarkersList = [];
    this.recentIvestigationLFTList = [];
    this.USG_BrainViweList = [];
    this.USG_ATPViewList = [];
    this.USG_KUBViewList = [];
  }
  //get recent investigation
  getRecentInvestigation = (recentInvestigation) => {
    try{
      console.log(" 679 get Recent investigation =================",recentInvestigation);
      this.mainserviceService.getRecentInvestigation({
        "babyid": this.babyid,
        "clientid": JSON.parse(sessionStorage.getItem('userInfo1')).usermasterid,
        "recentInvestigationHeader": recentInvestigation,
        "page": 1,
        "pagesize": 10000
      }).subscribe((res) => {
        console.log("687 Get RecentInvestigation response  => ", res);
        if(res.data){
          if (recentInvestigation === "HMG") {
           this.recentInvestigationList = res.data;
          } else if(recentInvestigation === "Biochemistry"){
            this.recentInvestigationBiochemistryList = res.data;
          }else if(recentInvestigation === "Sepsis Screen"){
            this.recentInvestigationSepsisScreenList = res.data;
          }else if(recentInvestigation === "S.Biirubin"){
            this.recentInvestigationSBiirubinList = res.data;
          }else if(recentInvestigation === "Others"){
            this.recentIvestigationOthersList  = res.data;
          }else if(recentInvestigation === "NBST"){
            this.recentIvestigationNBSTList = res.data;
          }else if(recentInvestigation === "Metabolic Workup"){
            this.recentIvestigationMetabolic_WorkupList = res.data;
          }else if(recentInvestigation === "Urine"){
            this.recentIvestigationUrineList = res.data;
          }else if(recentInvestigation === "Hypoglycemia Workup"){
            this.recentIvestigationHyPoglycemia_WorkupList = res.data;
          }else if(recentInvestigation === "Inflamatory Markers"){
            this.recentIvestigationHyInflamatoryMarkersList = res.data;
          }else if(recentInvestigation === "LFT"){
            this.recentIvestigationLFTList = res.data;
          }else if(recentInvestigation === "OOP"){
            this.recentIvestigationoppList = res.data;
          }
        }else{
          //empty data
        }
      }, (err) => {
        console.log(err.error);
      });
    }catch(err){
      console.log(err);
    }
  }

  onChangeRecent(event: MatTabChangeEvent) {
    try {
      const tab = event.tab.textLabel;
      console.log("selected tab ===",tab);
      if (tab === "HMG") {
        this.getRecentInvestigation("HMG");
      } else if(tab === "Biochemistry"){
        this.getRecentInvestigation("Biochemistry");
      }else if(tab === "Sepsis Screen"){
        this.getRecentInvestigation("Sepsis Screen");
      }else if(tab === "S.Biirubin"){
        this.getRecentInvestigation("S.Biirubin");
      }else if(tab === "Others"){
        this.getRecentInvestigation("Others");
      }else if(tab === "NBST"){
        this.getRecentInvestigation("NBST");
      }else if(tab === "Metabolic Workup"){
        this.getRecentInvestigation("Metabolic Workup");
      }else if(tab === "Urine"){
        this.getRecentInvestigation("Urine");
      }else if(tab === "Hypoglycemia Workup"){
        this.getRecentInvestigation("Hypoglycemia Workup");
      }else if(tab === "Inflamatory Markers"){
        this.getRecentInvestigation("Inflamatory Markers");
      }else if(tab === "LFT"){
        this.getRecentInvestigation("LFT");
      }else if(tab === "OOP"){
        this.getRecentInvestigation("OOP");
      }

    } catch (err) {
      console.log(err)
    }
  }

  //create imaging
  addImaging() {
    try {
      this.mainserviceService.createImaging({
        "babyid": this.babyid,
        "clientid": JSON.parse(sessionStorage.getItem('userInfo1')).usermasterid,
        "imagingHeader": this.imaging ? this.imaging : '-',
        "imagingDate": moment(new Date(this.imagingDate)).format('YYYY-MM-DD HH:mm:ss'),
        "USG_Brain": this.USGBrain? this.USGBrain : '-',
        "USG_ATP": this.USG_ATP ? this.USG_ATP : '-',
        "USG_KUB": this.USG_KUB ? this.USG_KUB : '-'
      }).subscribe((res) => {
        console.log("Create Imaging => ", res);
        if (res) {
          swal.fire(
            'Good job!',
            `${this.recentInvestigation} Added Succsefully!`,
            'success'
          );
          this.resetImaging()
        } else {
          console.log("something wrong");
          swal.fire(
            'Bad Response!',
            'An Error Occured, Please Contact System Administrator!',
             'error'
           );
           this.resetImaging()
        }
      }, (err) => {
        swal.fire(
          'Bad Response!',
          'An Error Occured, Please Contact System Administrator!',
           'error'
         );
      });
    } catch (err) {
      console.log(err);
      swal.fire(
        'Bad Response!',
        'An Error Occured, Please Contact System Administrator!',
         'error'
       );
    }
  }
 
  //reset imaging
  resetImaging = () => {
    try{
    this.imagingDate =  "";
    this.imaging = "";
    this.USGBrain = "";
    this.USG_ATP = "";
    this.USG_KUB = "";
    }catch(err){
      console.log(err);
    }
  }

  //get recent investigation
  getImaging = (imaging) => {
    try{
      console.log("get Imaging response ========",{
        "babyid": this.babyid,
        "clientid": JSON.parse(sessionStorage.getItem('userInfo1')).usermasterid,
        "imagingHeader": imaging,
        "page": 1,
        "pagesize": 10000        
      });

      this.mainserviceService.getImaging({
        "babyid": this.babyid,
        "clientid": JSON.parse(sessionStorage.getItem('userInfo1')).usermasterid,
        "imagingHeader": imaging,
        "page": 1,
        "pagesize": 10000        
      }).subscribe((res) => {
        console.log("Get Imaging => ", res);
        if(res.data){
          if (imaging == "USG Brain") {
           this.USG_BrainViweList = res.data;
           console.log("updated to var ====="+imaging +" = ",this.USG_BrainViweList);
          } else if(imaging == "USB Abdomen"){
            this.USG_ATPViewList = res.data;
            console.log("updated to var ====="+imaging +" = ",this.USG_ATPViewList);
          }else if(imaging == "USG(KUB)"){
            this.USG_KUBViewList = res.data;
            console.log("updated to var ====="+imaging +" = ",this.USG_KUBViewList);
          }
        }else{
          //empty data
        }
      }, (err) => {
        console.log(err.error);
      });
    }catch(err){
      console.log(err);
    }
  }

  //tab cahnge
  onChangeImaging(event: MatTabChangeEvent) {
    try {
      const tab = event.tab.textLabel;
      console.log(tab);
      if (tab == "USG Brain") {
        this.getImaging("USG Brain");
      } else if(tab == "USB Abdomen"){
        this.getImaging("USB Abdomen");
      }else if(tab == "USG(KUB)"){
        this.getImaging("USG(KUB)");
      }
    } catch (err) {
      console.log(err)
    }
  }

  //change
  changeImaging(){
    try {
      console.log("view flag =================", this.viewImagingFlag);
      this.getImaging("USG Brain");
    } catch (err) {
      console.log(err);
    }
  }


}
