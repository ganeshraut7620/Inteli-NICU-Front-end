import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { TestresultRoutingModule } from './testresult-routing.module';
import { TestresultComponent } from './testresult.component';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatTabsModule} from '@angular/material/tabs';
import {MatSelectModule} from '@angular/material/select';
import {MatInputModule} from '@angular/material/input';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';

@NgModule({
  declarations: [TestresultComponent],
  imports: [
    CommonModule,
    TestresultRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatExpansionModule,
    MatTabsModule,
    MatSelectModule,
    MatInputModule,
    MatSlideToggleModule
  ]
})
export class TestresultModule { }
