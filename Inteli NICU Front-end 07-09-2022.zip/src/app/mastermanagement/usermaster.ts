export class Usermaster{
  public usermasterid:Number;
  public usermastername:String;
  public address:String;
  public state:String;
  public city:String;
  public prefix:String;
  public pincode:String;
  public emailid:String;
  public mobilenumber:String;

}
