import { Usermaster  } from './usermaster';

export const usermaster : Usermaster[] = [

]

/*
{
    usermastername: "Ganesh",
    address: "pune South west",
    state:"mh",
    city:"pune",
    pincode:"434302",
    emailid:"rautganesh199820@gmail.com",
    mobilenumber:"7620062298"
  },
  {
    usermastername: "Suresh",
    address: "pune South west",
    state:"mh",
    city:"pune",
    pincode:"434302",
    emailid:"suresh@gmail.com",
    mobilenumber:"7620062298"
  }

*/
