import { Component, OnInit } from '@angular/core';
import { Usermaster } from './usermaster';
import { FormGroup, FormControl, Validators, RequiredValidator,FormBuilder  } from '@angular/forms';
import swal from 'sweetalert2';
import { NgxSpinnerService } from "ngx-spinner";
import { MastermanagementService } from './mastermanagement.service';
import { MainserviceService } from '../mainservice.service';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CustomvalidationService } from '../services/customvalidation.service';
@Component({
  selector: 'app-mastermanagement',
  templateUrl: './mastermanagement.component.html',
  styleUrls: ['./mastermanagement.component.css']
})
export class MastermanagementComponent implements OnInit {

  page = 1;
  editUser_Details:any;
  registerForm: FormGroup;
  submitted = false;
  countrys:any;
  states:any;
  citys:any;

  categorys = { 2:"Customer Service Master", 3:"Manager",4:"Field Engineer",5:"Client master"}

  userList : Usermaster[] = this.mastermanagementService.getUsermaster();
  filterArray: any;
  constructor(private mastermanagementService:MastermanagementService,public mainserviceService:MainserviceService ,private modalService: NgbModal,private spinner: NgxSpinnerService,private fb: FormBuilder,private customValidator: CustomvalidationService) {
    
    
    //this.registerForm.value.usercategoryid;
    this.filterArray = this.userList;
     this.getcountry();
    this.spinner.show();

    setTimeout(() => {
      /** spinner ends after 5 seconds */
      this.spinner.hide();
    }, 1000);

    this.getUserDetails()
   }

   _searchTerm: string;
    get searchTerm(): string {
        return this._searchTerm;
    }
    set searchTerm(val: string) {
        this._searchTerm = val;
        this.filterArray = this.filter(val);
    }

    filter(v: string) {
        return this.userList.filter(x => x.usermastername.toLowerCase().indexOf(v.toLowerCase()) !== -1);
    }

  ngOnInit(): void {
   this.registerForm =  new FormGroup({
      usercategoryid:new FormControl(null,[Validators.required]),
      usermastername:new FormControl(null,[Validators.required]),
      country:new FormControl(null,[Validators.required]),
      state:new FormControl(null,[Validators.required]),
      city:new FormControl(null,[Validators.required]),
      pincode:new FormControl(null,[Validators.required]),
      emailid:new FormControl(null,[Validators.required, Validators.pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$")]),
      mobilenumber:new FormControl(null,[Validators.required]),
      username:new FormControl(null,[Validators.required]),
      password:new FormControl(null,[Validators.compose([Validators.required, this.customValidator.patternValidator()])])
    });
    //Validators.compose([Validators.required, this.customValidator.patternValidator()])

  }




  changecat($event){}

  changecity(){

    console.log(this.registerForm.value.state);
    let data = {
      "districtid": null,
      "stateid": this.registerForm.value.state,
      "page": 1,
      "pagesize": 100000
    }

    this.mainserviceService.getdist(data).subscribe((res) => {
      console.log("District res =>",res);
      this.citys = res.data;
      console.log("District detals => ",this.citys);

      }, (err) => {
            console.log(err.error);

    });

  }

  changestate(){
    console.log(this.registerForm.value.country);
    let data = {
      "countryid": this.registerForm.value.country,
      "stateid": null,
      "page": 1,
      "pagesize": 10000
    }

    this.mainserviceService.getstate(data).subscribe((res) => {
      console.log("statre res =>",res);
      this.states = res.data;
      console.log("state detals => ",this.states);

      }, (err) => {
            console.log(err.error);

    });
  }

  getcountry(){
    let data = {
      "countryid": null,
      "page": 1,
      "pagesize": 100000
    }

    this.mainserviceService.getcountry(data).subscribe((res) => {
      console.log("country res =>",res);
      
      if(res.status_code = "s_407"){
        this.countrys = res.data;
        this.changestate();
        console.log("country detals => ",this.countrys);
        //return res.data;
      }
      

      }, (err) => {
            console.log(err.error);

    });
  }


  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;

    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }

    if (event.keyCode === 32 ) {
      return false;
    }
  }


  get registerFormControl() {
    return this.registerForm.controls;
  }

  openLg(content1) {
    this.ngOnInit();
    this.modalService.open(content1, { size: 'lg' });
    
  }

  onSubmit() {
    this.submitted = false;
    if (this.registerForm.valid) {
      var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
      console.log( "session storage value => ",userData);
      this.registerForm.value.usercategoryid = Number(this.registerForm.value.usercategoryid);
      this.registerForm.value.usersubcategoryid = 1;
      this.registerForm.value.submasterid = userData.usermasterid;
      this.registerForm.value.address = "-";
      this.registerForm.value.logo = "-";
      this.registerForm.value.hallsrange = 1;
      this.registerForm.value.roomsrange = 9;


      this.mainserviceService.createUser(this.registerForm.value).subscribe((res) => {
        console.log("User Master Res => ",res);

        if(res.status_code == 400){
          swal.fire(
            'error',
            res.message,

           );
        }

        if(res.status_code =="s_402"){
          this.registerForm =  new FormGroup({
            usercategoryid:new FormControl(null,[Validators.required]),
            usermastername:new FormControl(null,[Validators.required]),
            country:new FormControl(null,[Validators.required]),
            state:new FormControl(null,[Validators.required]),
            city:new FormControl(null,[Validators.required]),
            pincode:new FormControl(null,[Validators.required]),
            emailid:new FormControl(null,[Validators.required, Validators.pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$")]),
            mobilenumber:new FormControl(null,[Validators.required]),
            username:new FormControl(null,[Validators.required]),
            password:new FormControl(null,[Validators.compose([Validators.required, this.customValidator.patternValidator()])])
          });
          this.registerForm.reset();
          swal.fire(
           'Good job!',
           'User Added Succsefully!',
            'success'
          );
          
          
        }else if(res.status_code =="s_430"){
          swal.fire(
            'Bad Response!',
            'Username or Password Already in System!',
             'error'
           );
        }else if(res.status_code =="s_1015"){
          swal.fire(
            'Bad Response!',
            'An Error Occured, Please Contact System Administrator!',
             'error'
           );
        }

        this.getUserDetails();
        this.ngOnInit();
        this.closeBtnClick();

        }, (err) => {
              console.log(err);
      });

    }

    
   
  }

  onUpdate(){
   console.log(this.editUser_Details);

   this.editUser_Details.country = null;
   this.editUser_Details.state = null;
   this.editUser_Details.city = null;

   this.editUser_Details.password =null;
   this.editUser_Details.usersubcategoryid = null;
   this.editUser_Details.submasterid = null;

   delete this.editUser_Details['countryid'];
   delete this.editUser_Details['countryname'];
   delete this.editUser_Details['stateid'];
   delete this.editUser_Details['statename'];
   delete this.editUser_Details['cityid'];
   delete this.editUser_Details['cityname'];
   delete this.editUser_Details['usercategoryid'];
   delete this.editUser_Details['usercategoryname'];
   delete this.editUser_Details['prefix'];

   this.editUser_Details.isactive = true;


  this.mainserviceService.updateUser(this.editUser_Details).subscribe((res) => {
    console.log("Update Response => ",res);

    if(res.status_code == 400){
      swal.fire(
        'error',
        res.message,

       );
    }

    if(res.status_code == "s_403"){
      swal.fire(
        'Good job!',
        'User Updated Succsefully!',
        'success'
      );
      this.getUserDetails();

    }else if(res.status_code =="s_1015"){
      swal.fire(
        'Bad Response!',
        'An Error Occured, Please Contact System Administrator!',
         'error'
       );
    }else{
      swal.fire(
        'Something Wrong!',
        'Call System Admin!',
         'error'
       );
    }

    this.getUserDetails();

  }, (err) => {
    console.log(err.error);

  });
  this.closeBtnClick();
  }

  openModal(targetModal, usermaster) {
    this.modalService.open(targetModal, {
        centered: true,
        backdrop: 'static',
        size: 'lg'
    })
    console.log("Edit User Details => ",usermaster);
   
      this.changestate();
      this.changecity();
    this.editUser_Details = usermaster;


  }

  closeBtnClick() {
    this.ngOnInit();
    this.modalService.dismissAll()
   
  }

  getUserDetails() {
    let dummy_data ={
      "usercategoryid": null,
      "usersubcategoryid": 1,
      "page": 1,
      "pagesize": 5
    }
    this.mainserviceService.getUser(dummy_data).subscribe((res) => {
      console.log(res.data);
      this.filterArray = res.data;
      this.userList = res.data;
      }, (err) => {
            console.log(err.error);

    });
  }


  getUserDetails_pagination(page_incr) {
    console.log("Inside FUnction => ",page_incr);
    let dummy_data ={
      "usercategoryid": null,
      "usersubcategoryid": 1,
      "page": page_incr,
      "pagesize": 5
    }
    this.filterArray = [];
    this.mainserviceService.getUser(dummy_data).subscribe((res) => {
      console.log("After Increment Data => ",res.data);
      this.filterArray = res.data;
      this.userList = res.data;
      }, (err) => {
            console.log(err.error);

    });
  }



  previous(){
    if(this.page>=2){
      this.page = this.page - 1;
      console.log("decriment => ",this.page)
      this.getUserDetails_pagination(this.page);
    }else{

    }
  }

  next(){
    this.page = this.page + 1;
    console.log("Incriment => ",this.page)
    this.getUserDetails_pagination(this.page);
  }

}
