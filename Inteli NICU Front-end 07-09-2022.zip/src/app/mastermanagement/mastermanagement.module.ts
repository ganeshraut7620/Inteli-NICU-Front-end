import { NgModule,CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { MastermanagementRoutingModule } from './mastermanagement-routing.module';
import { MastermanagementComponent } from './mastermanagement.component';
import { NgxSpinnerModule } from "ngx-spinner";

@NgModule({
  declarations: [MastermanagementComponent],
  imports: [
    CommonModule,
    MastermanagementRoutingModule,
    FormsModule,ReactiveFormsModule,
    NgxSpinnerModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class MastermanagementModule { }
