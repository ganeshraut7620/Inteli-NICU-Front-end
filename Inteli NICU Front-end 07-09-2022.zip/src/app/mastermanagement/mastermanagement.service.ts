import { Injectable } from '@angular/core';

import { Usermaster } from './usermaster';
import { usermaster } from './usermaster-data';

@Injectable({
  providedIn: 'root'
})
export class MastermanagementService {
  public usermaster: Usermaster[] = usermaster;

  public getUsermaster() {
    return this.usermaster;
  }

}
