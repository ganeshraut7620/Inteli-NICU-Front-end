import { Component, OnInit } from '@angular/core';
import { Usermaster } from '../mastermanagement/usermaster';
import { FormGroup, FormControl, Validators, RequiredValidator, FormBuilder } from '@angular/forms';

import swal from 'sweetalert2';
import { NgxSpinnerService } from "ngx-spinner";
import { MastermanagementService } from '../mastermanagement/mastermanagement.service';
import { MainserviceService } from '../mainservice.service';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CustomvalidationService } from '../services/customvalidation.service';
@Component({
  selector: 'app-controlroommanager',
  templateUrl: './controlroommanager.component.html',
  styleUrls: ['./controlroommanager.component.css']
})
export class ControlroommanagerComponent implements OnInit {

  page = 1;

  editUser_Details: any;
  registerForm: FormGroup;
  submitted = false;
  countrys: any;
  states: any;
  citys: any;

  categorys: any = { 8: "Doctor Master", 9: "Nurse Master" }

  userList: Usermaster[] = this.mastermanagementService.getUsermaster();
  filterArray: any;
  dummy_country: any;



  constructor(private mastermanagementService: MastermanagementService, public mainserviceService: MainserviceService, private modalService: NgbModal, private spinner: NgxSpinnerService, private fb: FormBuilder, private customValidator: CustomvalidationService) {

    //this.getcountry();


    this.spinner.show();

    setTimeout(() => {
      /** spinner ends after 5 seconds */
      this.spinner.hide();
    }, 1000);

    this.getUserDetails()
  }

  _searchTerm: string;
  get searchTerm(): string {
    return this._searchTerm;
  }
  set searchTerm(val: string) {
    this._searchTerm = val;
    this.filterArray = this.filter(val);
  }

  filter(v: string) {
    return this.userList.filter(x => x.usermastername.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.emailid.toLowerCase().indexOf(v.toLowerCase()) !== -1);
  }

  ngOnInit(): void {
    this.fromset();
  }

  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;

    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }

    if (event.keyCode === 32) {
      return false;
    }
  }


  get registerFormControl() {
    return this.registerForm.controls;
  }

  openLg(content1) {
    this.submitted = false;

    // this.getcountry();
    this.fromset();

    this.modalService.open(content1, { size: 'lg' });
  }

  fromset() {
    this.registerForm = new FormGroup({
      usercategoryid: new FormControl(null, [Validators.required]),
      firstname: new FormControl(null, [Validators.required]),
      lastname: new FormControl(null, [Validators.required]),

      emailid: new FormControl(null, [Validators.required, Validators.pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$")]),
      mobilenumber: new FormControl(null, [Validators.required]),
      username: new FormControl(null, [Validators.required]),
      password: new FormControl(null, [Validators.compose([Validators.required, this.customValidator.patternValidator()])])
    });
  }
  onSubmit() {
    

    if (this.registerForm.valid) {
      this.submitted = false;
      var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
      console.log("session storage value => ", userData);
      let obj = {
        usercategoryid :Number(this.registerForm.value.usercategoryid) ,
        usermastername :this.registerForm.value.firstname+' '+this.registerForm.value.lastname,
        country :1,
        state:1,
        city:1,
        pincode:414302,
        emailid : this.registerForm.value.emailid,
        mobilenumber : this.registerForm.value.mobilenumber,
        username : this.registerForm.value.username,
        password : this.registerForm.value.password,
        usersubcategoryid :5,
        submasterid:  userData.usermasterid,
        clientid:userData && userData.prefix.toUpperCase().trim() == 'CMA' || userData.prefix.toUpperCase().trim() == 'BMA' || userData.prefix.toUpperCase().trim() == 'BCS' || userData.prefix.toUpperCase().trim() == 'BMG' || userData.prefix.toUpperCase().trim() == 'BFE' ? userData.prefix.toUpperCase().trim() == 'CMA' ? userData.usermasterid : null : userData.clientid,
        address: "-",
        logo:"-",
        hallsrange:1,
        roomsrange:9
      } 
      console.log("User Master details => ",obj);
 

      this.mainserviceService.createUser(obj).subscribe((res) => {
        console.log("User Master Res => ", res);

        if (res.statusCod == 400) {
          swal.fire(
            'error',
            res.message,

          );
        }

        if (res.status_code == "s_402") {
          swal.fire(
            'Good job!',
            'User Added Succsefully!',
            'success'
          );
          this.getUserDetails();
        } else if (res.status_code == "s_430") {
          swal.fire(
            'Bad Response!',
            'Username or Password Already in System!',
            'error'
          );
        } else if (res.status_code == "s_1015") {
          swal.fire(
            'Bad Response!',
            'An Error Occured, Please Contact System Administrator!',
            'error'
          );
        }

        this.fromset();
        this.closeBtnClick();

      }, (err) => {
        console.log("err==========",err);

      });
    } else {
      this.submitted = true;
    }


  }

  onUpdate() {
    console.log(this.editUser_Details);

    this.editUser_Details.country = null;
    this.editUser_Details.state = null;
    this.editUser_Details.city = null;

    this.editUser_Details.password = null;
    this.editUser_Details.usersubcategoryid = null;
    this.editUser_Details.submasterid = null;
    this.editUser_Details['usermastername'] = this.editUser_Details.firstname + ' ' + this.editUser_Details.lastname;

    delete this.editUser_Details['countryid'];
    delete this.editUser_Details['countryname'];
    delete this.editUser_Details['stateid'];
    delete this.editUser_Details['statename'];
    delete this.editUser_Details['cityid'];
    delete this.editUser_Details['cityname'];
    delete this.editUser_Details['usercategoryid'];
    delete this.editUser_Details['usercategoryname'];
    delete this.editUser_Details['prefix'];
    delete this.editUser_Details['clientid'];
    delete this.editUser_Details['firstname'];
    delete this.editUser_Details['lastname'];

    this.editUser_Details.isactive = true;


    this.mainserviceService.updateUser(this.editUser_Details).subscribe((res) => {
      console.log("Update Response => ", res);

      if (res.statusCod == 400) {
        swal.fire(
          'error',
          res.message,

        );
      }
      if (res.status_code == "s_403") {
        swal.fire(
          'Good job!',
          'User Updated Succsefully!',
          'success'
        );
        //this.getUserDetails_pagination(this.page)

      } else if (res.status_code == "s_1015") {
        swal.fire(
          'Bad Response!',
          'An Error Occured, Please Contact System Administrator!',
          'error'
        );
      } else {
        swal.fire(
          'Something Wrong!',
          'Call System Admin!',
          'error'
        );
      }
      // this.getUserDetails_pagination(this.page)

    }, (err) => {
      console.log(err.error);

    });
    this.closeBtnClick();
  }

  openModal(targetModal, usermaster) {
    this.modalService.open(targetModal, {
      centered: true,
      backdrop: 'static',
      size: 'lg'
    });
    // this.getcountry();
    // this.changestate();
    // this.changecity();
    console.log("user master details =>",usermaster);
    let user = usermaster.usermastername.split(" ");
  
    this.editUser_Details = usermaster;
    this.editUser_Details.firstname = user[0];
    this.editUser_Details.lastname = user[1];

  }

  closeBtnClick() {
    this.modalService.dismissAll()
    this.ngOnInit();
  }

  getUserDetails() {
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    let dummy_data = {
      "usercategoryid": null,
      "usersubcategoryid": null,
      "clientid": userData.clientid ? userData.clientid : null,
      "categoryid": [8, 9],
      "page": 1,
      "pagesize": 5
    }
    this.mainserviceService.getUser(dummy_data).subscribe((res) => {
      console.log(res.data);
      this.filterArray = res.data;
      this.userList = res.data;
    }, (err) => {
      console.log(err.error);

    });
  }

  getUserDetails_pagination(page_incr) {
    console.log("Inside FUnction => ", page_incr);
    let dummy_data = {
      "usercategoryid": null,
      "usersubcategoryid": 7,
      "page": page_incr,
      "pagesize": 5
    }
    this.filterArray = [];
    this.mainserviceService.getUser(dummy_data).subscribe((res) => {
      console.log("After Increment Data => ", res.data);
      this.filterArray = res.data;
      this.userList = res.data;
    }, (err) => {
      console.log(err.error);

    });
  }



  previous() {
    this.page = this.page - 1;
    console.log("decriment => ", this.page)
    this.getUserDetails_pagination(this.page);
  }

  next() {
    this.page = this.page + 1;
    console.log("Incriment => ", this.page)
    this.getUserDetails_pagination(this.page);
  }


  // changecity() {

  //   console.log(this.registerForm.value.state);
  //   let data = {
  //     "districtid": null,
  //     "stateid": this.registerForm.value.state,
  //     "page": 1,
  //     "pagesize": 10000
  //   }

  //   this.mainserviceService.getdist(data).subscribe((res) => {
  //     console.log("District res =>", res);
  //     this.citys = res.data;
  //     console.log("District detals => ", this.citys);

  //   }, (err) => {
  //     console.log(err.error);

  //   });

  // }

  // changestate() {
  //   console.log(this.registerForm.value.country);
  //   let data = {
  //     "countryid": this.registerForm.value.country,
  //     "stateid": null,
  //     "page": 1,
  //     "pagesize": 10000
  //   }

  //   this.mainserviceService.getstate(data).subscribe((res) => {
  //     console.log("statre res =>", res);
  //     this.states = res.data;
  //     console.log("state detals => ", this.states);

  //   }, (err) => {
  //     console.log(err.error);

  //   });
  // }

  // getcountry() {
  //   let data = {
  //     "countryid": null,
  //     "page": 1,
  //     "pagesize": 10000
  //   }

  //   this.mainserviceService.getcountry(data).subscribe((res) => {
  //     console.log("country res =>", res);
  //     this.countrys = res.data;
  //     this.registerForm.value.country = res.data[0].countryid;
  //     this.dummy_country = res.data[0].countryid;
  //     this.changestate()
  //     console.log("country detals => ", this.countrys);

  //   }, (err) => {
  //     console.log(err.error);

  //   });
  // }

}
