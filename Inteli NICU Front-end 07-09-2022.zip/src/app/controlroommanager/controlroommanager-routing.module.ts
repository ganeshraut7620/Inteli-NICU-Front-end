import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ControlroommanagerComponent } from './controlroommanager.component';

const routes: Routes = [
  { path: '' , component:ControlroommanagerComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ControlroommanagerRoutingModule { }
