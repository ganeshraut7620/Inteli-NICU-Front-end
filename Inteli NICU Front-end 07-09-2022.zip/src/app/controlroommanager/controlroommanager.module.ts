import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ControlroommanagerRoutingModule } from './controlroommanager-routing.module';
import { ControlroommanagerComponent } from './controlroommanager.component';

import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { NgxSpinnerModule } from "ngx-spinner";

@NgModule({
  declarations: [ControlroommanagerComponent],
  imports: [
    CommonModule,
    ControlroommanagerRoutingModule,FormsModule,ReactiveFormsModule,NgxSpinnerModule
  ]
})
export class ControlroommanagerModule { }
