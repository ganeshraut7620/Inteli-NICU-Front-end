import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ControlroommanagerComponent } from './controlroommanager.component';

describe('ControlroommanagerComponent', () => {
  let component: ControlroommanagerComponent;
  let fixture: ComponentFixture<ControlroommanagerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ControlroommanagerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ControlroommanagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
