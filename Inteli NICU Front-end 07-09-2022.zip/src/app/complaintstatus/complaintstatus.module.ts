import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { ComplaintstatusRoutingModule } from './complaintstatus-routing.module';
import { ComplaintstatusComponent } from './complaintstatus.component';


@NgModule({
  declarations: [ComplaintstatusComponent],
  imports: [
    CommonModule,
    ComplaintstatusRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class ComplaintstatusModule { }
