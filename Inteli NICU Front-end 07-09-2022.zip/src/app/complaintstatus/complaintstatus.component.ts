import { Component, OnInit } from '@angular/core';
import { MainserviceService } from '../mainservice.service';
import swal from 'sweetalert2';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, Validators, RequiredValidator, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-complaintstatus',
  templateUrl: './complaintstatus.component.html',
  styleUrls: ['./complaintstatus.component.css']
})
export class ComplaintstatusComponent implements OnInit {

  page = 1;

  complaintstatus: any;
  filterArray: any;
  registerForm: FormGroup;
  submitted = false;
  complaint_status: any;
  actionstatus: boolean = false;
  msg: string;
  complaint_status_data: any;

  constructor(public mainserviceService: MainserviceService, private modalService: NgbModal, private fb: FormBuilder) {

    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    console.log("Login Value  => ", userData);

    this.actionstatus = (userData.usercategoryid == 2 && userData.usercategoryname == "customer service") ? true : false;
    console.log("action Status =>", this.actionstatus);

    this.getcomplaintstatusdetails(this.page)
  }

  _searchTerm: string;
  get searchTerm(): string {
    return this._searchTerm;
  }
  set searchTerm(val: string) {
    this._searchTerm = val;
    this.filterArray = this.filter(val);
  }

  filter(v: string) {
    return this.complaint_status_data.filter(x => x.clientname.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.machinename.toLowerCase().indexOf(v.toLowerCase()) !== -1);
  }


  openModal(targetModal, cms) {
    this.modalService.open(targetModal, {
      centered: true,
      backdrop: 'static',
      size: 'lg'
    })
    this.complaint_status = cms;
    console.log("Complaint data = > ", this.complaint_status);
  }

  ngOnInit(): void {
    this.registerForm = this.fb.group({
      closedate: ['', Validators.required],
      remark: ['', Validators.required]
    });

  }

  get registerFormControl() {
    return this.registerForm.controls;
  }


  getcomplaintstatusdetails(page) {
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    let data = {
      "machineid": null,
      "clientid": userData.clientid ? userData.clientid : null,
      "complainttype": null,
      "requiredhelp": null,
      "complaintstatus": null,
      "fieldengineerid": null,
      "page": page,
      "pagesize": 6
    }

    this.mainserviceService.getcomplaint(data).subscribe((res) => {

      if (res.status_code == 's_407') {
        this.filterArray = res.data;
        this.complaint_status_data = res.data;
      } else if (res.status_code == 's_408') {
        this.filterArray = res.data;
      } else if (res.status_code == 's_1015') {
        swal.fire(
          'Bad Job!',
          'An Error Occured Please Contact System Administrator!',
          'error'
        );
      } else if (res.status_code == 's_408') {
        this.msg = "No Record Found";
      }
      // this.countrys = res.data;
      // console.log("country detals => ",this.countrys);

    }, (err) => {
      console.log(err.error);

    });
  }

  previous() {
    if (this.page >= 2) {
      this.page = this.page - 1;
      console.log("decriment => ", this.page)
      this.getcomplaintstatusdetails(this.page)
    } else {

    }
  }

  next() {
    this.page = this.page + 1;
    console.log("Incriment => ", this.page)
    this.getcomplaintstatusdetails(this.page)
  }

  onSubmit() {
    if (this.registerForm.valid) {
      let obj = {
        "complaintid": this.complaint_status.complaintid,
        "machineid": this.complaint_status.machineid,
        "clientid": this.complaint_status.clientid,
        "requestorname": null,
        "complainttype": null,
        "contactno": null,
        "requiredhelp": null,
        "complaintstatus": "close",
        "description": this.complaint_status.description,
        "remark": this.registerForm.value.remark,
        "closeddate": this.registerForm.value.closedate,
      }
      this.mainserviceService.updatecmp(obj).subscribe((res) => {
        if (res.status_code == 's_407') {
          swal.fire(
            'Great Job!',
            'Complaint Close Succesfully!',
            'error'
          );
          this.getcomplaintstatusdetails(this.page);
          this.closeBtnClick()
        } else if (res.status_code == 's_1015') {
          swal.fire(
            'Bad Job!',
            'An Error Occured Please Contact System Administrator!',
            'error'
          );
          this.closeBtnClick()
        } else if (res.status_code == 's_408') {
          swal.fire(
            'No Record Found!',
            'error'
          );
          this.closeBtnClick()
        }
      });
    } else {
      swal.fire(
        'Bad Job!',
        'Something Wrong!',
        'error'
      );
      this.closeBtnClick()
    }

  }


  closeBtnClick() {
    this.modalService.dismissAll()
    this.ngOnInit();
  }


}
