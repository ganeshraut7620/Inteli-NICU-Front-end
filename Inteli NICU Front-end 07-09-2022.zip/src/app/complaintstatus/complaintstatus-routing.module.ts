import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ComplaintstatusComponent } from './complaintstatus.component';

const routes: Routes = [
  {
    path: '' ,
    component: ComplaintstatusComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ComplaintstatusRoutingModule { }
