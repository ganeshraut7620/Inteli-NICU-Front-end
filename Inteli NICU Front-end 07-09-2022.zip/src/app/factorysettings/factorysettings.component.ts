import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-factorysettings',
  templateUrl: './factorysettings.component.html',
  styleUrls: ['./factorysettings.component.css']
})
export class FactorysettingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
