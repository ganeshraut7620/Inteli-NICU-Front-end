import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FactorysettingsComponent } from './factorysettings.component';

const routes: Routes = [

  { path : '',  component:FactorysettingsComponent }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FactorysettingsRoutingModule { }
