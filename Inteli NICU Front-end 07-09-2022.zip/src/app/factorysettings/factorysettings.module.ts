import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FactorysettingsRoutingModule } from './factorysettings-routing.module';
import { FactorysettingsComponent } from './factorysettings.component';


@NgModule({
  declarations: [FactorysettingsComponent],
  imports: [
    CommonModule,
    FactorysettingsRoutingModule
  ]
})
export class FactorysettingsModule { }
