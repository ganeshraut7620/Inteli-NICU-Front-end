import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FactorysettingsComponent } from './factorysettings.component';

describe('FactorysettingsComponent', () => {
  let component: FactorysettingsComponent;
  let fixture: ComponentFixture<FactorysettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FactorysettingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FactorysettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
