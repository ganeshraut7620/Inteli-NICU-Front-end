import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { VitallocationdashboardRoutingModule } from './vitallocationdashboard-routing.module';
import { VitallocationdashboardComponent } from './vitallocationdashboard.component';


@NgModule({
  declarations: [VitallocationdashboardComponent],
  imports: [
    CommonModule,
    VitallocationdashboardRoutingModule
  ]
})
export class VitallocationdashboardModule { }
