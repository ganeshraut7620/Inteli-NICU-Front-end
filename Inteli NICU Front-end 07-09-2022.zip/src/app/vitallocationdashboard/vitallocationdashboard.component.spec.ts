import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VitallocationdashboardComponent } from './vitallocationdashboard.component';

describe('VitallocationdashboardComponent', () => {
  let component: VitallocationdashboardComponent;
  let fixture: ComponentFixture<VitallocationdashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VitallocationdashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VitallocationdashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
