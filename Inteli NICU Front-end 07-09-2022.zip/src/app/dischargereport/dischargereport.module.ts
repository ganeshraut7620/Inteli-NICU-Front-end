import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { DischargereportRoutingModule } from './dischargereport-routing.module';
import { DischargereportComponent } from './dischargereport.component';
import {MatSelectModule} from '@angular/material/select';
import {MatChipsModule} from '@angular/material/chips';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import {MatInputModule} from '@angular/material/input';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatTabsModule} from '@angular/material/tabs';
@NgModule({
  declarations: [DischargereportComponent],
  imports: [
    CommonModule,FormsModule,ReactiveFormsModule,MatTabsModule,
    DischargereportRoutingModule,
    MatSelectModule,
    MatAutocompleteModule,    
    MatChipsModule,
    MatExpansionModule,
    MatInputModule
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class DischargereportModule { }
