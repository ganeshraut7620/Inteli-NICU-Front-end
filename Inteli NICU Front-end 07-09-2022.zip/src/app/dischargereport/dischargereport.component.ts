import { Component, OnInit } from '@angular/core';
import { MainserviceService } from '../mainservice.service';
import { FormControl } from '@angular/forms';
import * as moment from 'moment';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Console } from 'console';

@Component({
  selector: 'app-dischargereport',
  templateUrl: './dischargereport.component.html',
  styleUrls: ['./dischargereport.component.css']
})
export class DischargereportComponent implements OnInit {
  BabyList: any;
  myfilename: any;
  fileUrl: any;
  folder_name: any;
  status_flag = false;
  BabyListprint: any;
  page = 1;
  page_incr = 1;
  filterArray: any;
  sleetecf = new FormControl();
  babyid = new FormControl();
  Maternal_History

  displayDischargeform: boolean = false;

  getDataFromtext: any = "";
  status = "Genrate Report";
  panelOpenState = true;
  // data =[];
  data = [
    { "v": 0, "cf": "HYPERBILIRUBINEMIA", "ts": "The baby was icteric on day [ ] of life. Serum bilirubin/ transcutaneous bilirubin was [ ]mg%.  Maximum serum bilrubin was[ ].mg%. Phototherapy was given for [ ]. days. Baby showed no signs of bilirubin encephalopathy. Last bilirubin level before discharge was[ ]." },
    { "v": 1, "cf": "MECONIUM ASPIRATION SYNDROME", "ts": "Meconium stained liquor was evident at the time of delivery. Baby was vigorous/non-vigorous at the time of birth. Routine resuscitation procedures were followed as per NRP guidelines. Baby had respiratory distress on admission to NICU.   X-Ray Chest was normal/showed evidence of meconium aspiration syndrome with fluffy opacities & hyperinflation. Baby was treated with Head box oxygen/CPAP/Mechanical ventilation/Hi-frequency ventilation. Baby was ventilated for[ ]days. Intra tracheal surfactant was needed/not needed. Baby was weaned to room air on day[ ]." },
    { "v": 2, "cf": "METABPOLIC ABNORMALITIES", "ts": "Baby developed symptomatic/asymptomatic hyponatremia/hypoglycemia/hypokalemia/acidosis on [ ] day of life.  ([ ] meq/L). Hyponatremia was corrected by IV 3% NaCl & Oral supplementation. Last serum sodium before discharge was [ ] meq/L Oral supplementation has been advised at discharge/Oral supplementation is not necessary at discharge. Hypokalemia was corrected by KCL drip over [ ]. Last values were. Baby had Hypoglycemia on day [ ] It was managed with IV Fluids with maximum GIR [ ] sugar was normal on day…...Critical sample was sent/not sent. No/Other medication given was …[ ] Baby was detected with hypocalcemia on day…...Baby was asymptomatic/symptomatic. Calcium gluconate correction was given for 3 days. Repeat calcium is normal." },
    { "v": 3, "cf": "PERSISTENT PULMONARY HYPERTENSION OF NEWBORN(PPHN)", "ts": "Baby was diagnosed with Persistent pulmonary hypertension(PPHN) on day [ ]. Clinical features were high FiO2 requirement, respiratory distress, need for mechanical ventilation, labile oxygen saturations, upper & lower limb saturation difference. Functional ECHO/Colour Doppler showed high pulmonary pressures[ ](mm Hg), Tricuspid regurgitation & myocardial dysfunction. X Ray Chest showed [ ] Baby was treated with headbox oxygen/mechanical ventilation/high frequency ventilation. Stable ventilator settings were[ ] Baby needed inotropic support & Pulmonary vasodilators(Dobutamine/ sildenafil/milrinone/prostacyclins/inhaled nitric oxide/bosentan) were [ ] Baby needed surfactant adminstration on day[ ] Baby was successfully extubated on day [ ]" },
    { "v": 4, "cf": "PATENT DUCTUS ARTERIOSUS(PDA)", "ts": "The baby was diagnosed with PDA on [ ].day. The PDA was confirmed on functional echo/coloured doppler as haemodynamically significant/insignificant. The baby was treated with indomethacin/ibuprofen/parecetamol [ ]doses were needed. Follow up echo showed closure/narrowing of the duct on day[ ]." },
    { "v": 5, "cf": "SHOCK", "ts": "Baby had hemodynamic instability and shock on day [ ] . Functional ECHO showed poor myocardial contractility/hypovolemia/hemodynamically significant PDA/ Pulmonary hypertension/others. Inotropic support was started with dopamine/dobutamine/adrenaline/milrinone/noradrenaline/others. Baby recovered from shock and inotropic support was weaned off after [ ].days" },
    { "v": 6, "cf": "NEONATAL SEIZURES", "ts": "Baby had convulsion on [ ] day of life. Anti convulsant Phenobarbitol/  Levetiracetam /Phenytoin/ Other  was given . Maintenance dose was continued. Gradually anticonvulsant was weaned off/ continued at discharge. Neurological examination was normal/ suggestive of [ ]. MRI was done [ ]/ planned on follow up. EEG was done/ planned on follow up. " },
    { "v": 7, "cf": "FEED INTOLERANCE", "ts": "Enteral feeds were initiated on day [ ].Baby showed signs of feed intolerance/ gastric residuals/ abdominal distension/vomiting/altered aspirate. Baby was kept Nil by mouth for [ ] days. Feeds were restarted and graded up on [ ] Day of life. Baby reached full feeds on day [ ]" },
    { "v": 8, "cf": "INTESTINAL OBSTRUCTION", "ts": "Antenatal USG was suggestive of [ ]/ Baby was diagnosed as intestional obstruction on day [ ] The cause of the obstruction was  [ ] Exploratory laparotomy was done by Dr[ ] on day [ ]. Surgical findings revealed [ ] Feeds were started on [ ]. And graded up to full feeds on [ ] Surgical follow up planned on next visit." },
    { "v": 9, "cf": "ANEMIA OF PREMATURITY", "ts": "Baby developed exaggerated anemia of prematurity. Haemoglobin was [ ] gm% on day [ ]. Baby needed [ ] Packed cell transfusions. Baby was also started on Iron & Folate supplementation. Last haemoglobin was [ ]gm% on (date)." },
    { "v": 10, "cf": "PERIVENTRICULAR LEUKOMALACIA(PVL)", "ts": "Routine cranial ultrasound revealed PVL on day [ ]. Followup ultrasound revealed [ ] MRI brain showed [ ]/MRI Brain has been advised. Parents have been counselled regarding the prognosis and the need for regular neuro-developmental followup." },
    { "v": 11, "cf": "METABOLIC BONE DISEASE", "ts": "Baby was diagnosed with metabolic bone disease on the basis of low serum phosporous ([ ] mg%) and elevated serum alkaline phosphatase ([ ].IU/L). Necessary nutritional supplementation has been started. " },
    { "v": 12, "cf": "RETINOPATHY OF PREMATURITY(ROP)", "ts": "Baby was screened for Retinopathy of prematurity regularly as per protocol. ROP screening on date [ ].revealed Zone-[ ], Stage [ ]. ROP in right/Left/Both eyes. Regular followup revealed [ ] Baby was treated with Laser photocoagulation/Bevacizumab Injection. Next follow up for review is on date[ ]" },
    { "v": 13, "cf": "PREMATURITY", "ts": "Baby was admitted to NICU for prematurity & low birth weight. Baby did not show any signs of sickness. Baby was nursed in a clean thermoneutral environment and was monitored for hypoglycemia. Orogastric feeds was started on day…..and graded up to full feeds on [ ]. Oral feeds were initiated on day[ ]..and baby was discharged on day[ ]..Oral supplementation with multivitamins, calcium and Vitamin-D were started. Discharged counselling was done." },
    { "v": 14, "cf": "INTRAVENTRICULAR HAEMORRHAGE(IVH)", "ts": "Baby was monitored with serial cranial ultrasound as per protocol. Cranial USG on day [ ] revealed IVH Grade I/II/III/IV on right/left/both sides. Follow up ultrasound revealed [ ] Repeat cranial USG is planned on date [ ] MRI brain showed [ ]/MRI Brain has been advised. Parents have been counselled regarding the prognosis and the need for regular neuro-developmental followup." },
    { "v": 15, "cf": "RESPIRATORY DISTRESS SYNDROME", "ts": "Baby was admitted in NICU and had grunting/tachypnea/retractions/cyanosisand was managed by CPAP/Mechnical ventilation on day [ ]. Baby required surfactant/no-surfactant. Chest X Ray was done which was suggestive of [  ].Baby was weaned to rooam air/Non Invasive Ventilation on day[ ]. Caffeine was given to prevent apnea and stopped on 34week CGA. Baby was discharged on room air at day [ ]." },
    { "v": 16, "cf": "TRANSIENT TACHYPNEA OF NEW BORN", "ts": "Baby was admitted in NICU and had grunting/tachypnea/retractions/cyanosis. Baby was managed by CPAP/Nasal prongs [ ] Chest X Ray was normal/ suggestive of fluid in lung/other [ ].Baby was weaned to rooam air on day [ ]." },
    { "v": 17, "cf": "SEPSIS", "ts": "Early onset sepsis/ Late onset sepsis/ Meningitis.Early onset sepsis : Antibiotics were started for prematurity/maternal factors. Blood culture/ CRP/ other was Positive/ negative. Antibiotics were given for [ ] days.   Late onset sepsis: Baby showed signs of sepsis ( tachypnea/ poor perfusion/other) antibiotics were started. CSF/Urine culture/ Fungal culture/ Blood culture/ CRP/ other was Positive/ negative. Antibiotics were given for _____ days." },
    { "v": 18, "cf": "NECROTISING ENTEROCOLITIS", "ts": "Baby had abdominal distension/ feed intolerance/ altered aspirate/ bilious aspirate on [ ] day. Xray erect abdomen was suggestive of [ ]. Lab investigation showed Thrombocytopenia/ hyponatremia/ acidosis/ others. Findings were suggestive of NEC grade 1/2/3. Baby was kept nil by mouth for [ ] days, required antibiotics/ others. Surgical reference was given/not.Feeds were reinitiated on DOL [ ] and gradually graded up. " },
    { "v": 19, "cf": "BIRTH ASPHYXIA", "ts": "Baby required resuscitation at birth as Bag and mask/intubation/Chest compression for [ ] seconds with/without drugs adrenaline/ fluid bolus. Cord ABGA ph/HCO3/Base deficit/Lactate was [ ]. Theraupetic hypothermia was/not intiated for 72 hours. Baby had poor cardiac contractility/ decreased urine output/ seizures at [ ] hour of life. Lab parameters CKMB [ ]/ LFT [ ]/ RFT [ ] suggestive/ not suggestive  of MODS. Neurological examination was [ ]. EEG/MR/ Brain sonography was suggestive of [ ]" },
    { "v": 20, "cf": "BRONCHPULMONARY DYSPLASIA", "ts": "Baby required respiratory support CPAP/ nasal prongs/ Mechanical ventilation/ NIPPV at [ ] day of life at gestational age [ ]. Chest xray was suggestive of BPD changes/ atelectatic bands/ collapse/ hazziness . Treatment was given as diuretics/ steroids- inhaled/oral/intravenous/ others for [ ] days. Baby was weaned off all respiratory support on [ ] day and maintaining saturation on room temperature./ Baby was discharged with minimal oxygen support." },
    { "v": 21, "cf": "DYSMORPHISM", "ts": "Baby shows dismorphism in the form of - 1) Microcephaly, 2) Craniosynostosis, 3) Micrognathia, 4) Ear Tags, 5) Loset Malformed ear, 6) Slanting eyes, 7) Hypertelorism, 8) Hypotelorism, 9) Extremly loose skin, 10) Hirsutism, 11) Hyperplastic skin, 12) Persistent manglorian spot, 13) Webbing between fingers & toes, 14) Cleft Lip, 15) Cleft Palate, 16) Large tounge, 17) Small tounge, 18) Arachnodactyly( long finger or toes), 19) Bradydactyly(small finger/toes), 20) Clinotactyly(curved finger or toes), 21) Hypoplastic, 22) Hypotonic, 23) Polydactyle, 24) Polydactyle, 25) Syndactyle, 26) Others" },
    { "v": 22, "cf": "CONGENITAL ANOMALY", "ts": "The baby shows birth deficiency in the form of  - 1) Congenial heart disease [ ], 2) Hypospodias[ ].3) Club Foot[ ].4) Down Syndrome[ ].5) Clef Lip with Clef+palate, 6) Limb defect [ ].7) Tracheoesophageal fistula [ ].8) Chromosomal defect [ ].9) Anencephaly [ ]., 10)[ ].syndrome[ ]., 11) Congenital adrenal Hyperplasia, 12) Congenital diaphragmatic hernia, 13) Imperforate Anus, 14) Renal deformity in the form of[ ].13) Other in the form of[ ]" }
  ];

  //meternal content
  meternal_content_one: any = '';
  meternal_content_two: any = '';
  meternal_content_three: any = '';

  mothername: any = '';
  babygender: any = '';
  age: any = '';
  bloodgroup: any = '';
  dct: any = '';
  hospitalname: any = '';
  consultantname: any = '';
  pregnancy: any = '';
  anc: any = '';
  PIHmedication: any = '';
  GDMmanagedwith: any = '';
  antenatal_steriod_course: any = '';
  steroid: any = '';
  USGBrainFlag: boolean = true;
  USG_ATPFlag: boolean = false;
  USG_KUBFlag: boolean = false;
  OPPFlag: boolean = false;
  Metabolic_WorkupFlag: boolean = false;
  OthersFlag: boolean = false;
  UrineFlag: boolean = false;
  Hypoglycemia_WorkupFlag: boolean = false;
  Inflamatory_MarkersFlag: boolean = false;
  LFTFlag: boolean = false;

  recentInvestiggation = ["HMG", "Biochemistry", "Sepsis Screen", "S.Biirubin", "Others", "NBST", "OOP", "Metabolic Workup", "Urine", "Hypoglycemia Workup", "Inflamatory Markers", "LFT"];
  NBSTFlag: boolean = false;
  recentInvestigation = "HMG";

  // HMG
  HB: '';
  WBC: '';
  PLATELET: '';
  PCR: '';
  NEUTROPHILS: '';
  ANC: '';

  //Biochemistry
  RFTUREA: '';
  Creatine: '';
  SE: '';
  Na: '';
  K: '';
  Ca: '';
  Mg: '';

  //meternal content list 
  bloodgroupList = ["A positive", "A negative", "B positive", "B negative", "O positive", "O negative", "AB positive", " AB negative", "Not known"];
  dctList = [" ICT is positive", "ICT is negative", "ICT Not done"];
  hospitalnameList = ["KEM Hospital", "an outside hospital"];
  consultantnameList = ["Dr. Umesh Vaidya", "Dr. Tushar Parikh", "Dr. Sandeep Kadam", "Not Known"];
  pregnancyList = ["spontaneous", "IVF", "assisted conception"];
  ancList = ["normal", "with normal doppler changes", "with abnormal doppler changes"];
  GDMmanagedwithList = ["diet", "drugs", "insulin", "hypothyrodism", "UTI", "chronic medical illness", "other", "non diabetic"];
  antenatal_steriod_courseList = ["complete antenatal steroid course was given.", "incomplete antenatal steroid course was given."];
  steroidList = ["Dexamethasone", "Betnasol"];

  //perinatel content 
  deliverytype: any = "";
  laborduration: any = "";
  pregnancycomplication: any = "";
  pregnancycomplicationtime: any = "";
  deliverydate: any = "";
  deliverytime: any = "";
  position: any = "";
  liquor: any = "";
  apgarscoreone: any = "";
  apgarscorefive: any = "";
  babycried: any = "";
  babycriedsecond: any = "";
  deliveryroom: any = "";
  NICU: any = "";
  cordclamping: any = "";


  deliverytypeList = ["vaginal delivery", "assisted vaginal delivery", "lower section cesarean section"]
  pregnancycomplicationList = ["pregnancy complication", "premature rupture of membrane", " PV Bleed"]
  positionList = ["vertex", "breech", "other"]
  liquorList = ["clear", "meconium", "foul smelling"]
  babycriedList = ["immediately after birth", "required resuscitation as Physical stimulation", "bag and mask ventilation", "intubation", "CPR"];
  deliveryroomList = ["CPAP", "without CPAP"]
  NICUList = ["prematurity", "respiratory distress", "reason  "]
  cordclampingList = ["early", "delayed"]

  //recent investigation
  recentInvestigationList = [];
  recentInvestigationBiochemistryList = [];
  recentInvestigationSepsisScreenList = [];
  recentInvestigationSBiirubinList = [];
  recentIvestigationoppList = [];
  recentIvestigationMetabolic_WorkupList = []
  recentIvestigationOthersList = []
  recentIvestigationNBSTList = [];
  recentIvestigationUrineList = [];
  recentIvestigationHyPoglycemia_WorkupList = [];
  recentIvestigationHyInflamatoryMarkersList = [];
  recentIvestigationLFTList = [];

  //USG Brain
  USG_BrainViweList = [];
  USG_ATPViewList = [];
  USG_KUBViewList = [];

  //report Data 
  recentInvestigationHMGReportList = [];
  recentInvestigationReportList = [];
  recentInvestigationBiochemistryReportList = [];
  recentInvestigationSepsisScreenReportList = [];
  recentIvestigationoppReportList = [];
  recentIvestigationMetabolic_WorkupReportList = [];
  recentIvestigationOthersReportList = [];
  recentIvestigationNBSTReportList = [];
  recentIvestigationUrineReportList = [];
  recentIvestigationHyPoglycemia_WorkupReportList = [];
  recentIvestigationHyInflamatoryMarkersReportList = [];
  recentIvestigationLFTReportList = [];
  recentInvestigationSBiirubinReportList = []
  //imaging report selected lists

  USG_BrainViweReportList = [];
  USG_ATPViewReportList = [];
  USG_KUBViewReportList = [];


  babyreport: any;
  downloadflag: boolean = false;
  awspath: any;
  summaryList: any = [];
  medicineList: any;
  babyidReq: boolean;
  downloadLayout: boolean = false;
  babyReportData: any;
  currentBabyReportData: any;
  hbgFlag: boolean = true;
  bioChemistryFlag: boolean = false;
  screenFlag: boolean = false;
  bloodgroupFlag: boolean = false;
  biirubinFlag: boolean = false;
  // recentInvestigationList = [];
  bioChemistryList = [];
  HMGReportList = [];

  imaging: any = "USG Brain";
  imagingList = ["USG Brain", "USG Abdomen",];
  gweeks: any;
  gdays: any;
  meternal_history: void;
  meternal_history_content_clone: string;
  perinatel_history_content_clone: string;
  babyDetails: any;


  constructor(public mainserviceService: MainserviceService, private modalService: NgbModal) {
    //this.getbabydetails(this.page_incr)
    let babydetails = JSON.parse(localStorage.getItem('report'));
    console.log("Baby details ============",babydetails);
  
    //step 1 init existing info 
    if (babydetails != null && babydetails != undefined){
      // in it localstorage
    }


  }

  ngOnInit(): void {
    this.getbabydetails();

  }

  initDischargeTemplate = (baby) => {
    console.log("baby details =============", baby);
    this.currentBabyReportData = baby;
    this.mothername = baby.mothername;
    this.bloodgroup = "";
    this.dct = "";
    this.hospitalname = "KEM Hospital";
    this.consultantname = "Not Known";
    this.pregnancy = "";
    this.anc = "normal";
    this.pregnancycomplication = "pregnancy complication"
    this.GDMmanagedwith = "non diabetic";
    this.antenatal_steriod_course = "";

    this.babyreport = {
      maternal_history: new FormControl('', []),
      perinatal_history: new FormControl('', []),
      neonatal_nicu_journey: new FormControl("", []),
      medicationList: new FormControl("", []),
      ra1: new FormControl("HMG: Hb -…………, WBC:………., Platelet:………., PCR:………Neutrophils:……. ANC:……..".toUpperCase(), []),
      rb1: new FormControl("Biochemistry: RFT Urea-……., Creatine-…, SE-…., Na+….., K+ ……, (I)Ca+2….., mg-…..", []),
      rc1: new FormControl("Sepsis Screen:  CRP…….., Blood Cells……., Urine Routine…….., CSF……., Urine CLS……., CSF CLS……., ET CLS……", []),
      rd1: new FormControl("Blood Group: Mother………., Baby……..", []),
      re1: new FormControl("S. Biirubin(T):…………..,( Direct):…………..", []),
      rf1: new FormControl("NBST -……….", []),
      rgi1: new FormControl("USG Brain:", []),
      rgi2: new FormControl("USG(ATP)", []),
      rgi3: new FormControl("USG(KUB)", []),
      rh1: new FormControl("OPP: Total Cal…….., PO4………, ALP………., Vit D3………", []),
      ri1: new FormControl("Metabolic Workup – Ammonia …………", []),
      rj1: new FormControl("Others: Gastric aspirate………, Fluid Cytology……., Biopsy…….., TFT…….., TORCH IgG…, IgM…", []),
      rk1: new FormControl("Urine: …….CMV", []),
      rl1: new FormControl("Hypoglycemia workup: RBS……., Sv, Cortisol……, Sv Insulin…….", []),
      rm1: new FormControl("Inflamatory markers: Ferrite………, Fibrinogen…….", []),
      rn1: new FormControl("LFT: SGPT………, SGOT…….., GGT………, ALP…….., Bilirubin(D)……(I).,……Protien….. ,PTCINR……, aPTT……", []),
      rop: new FormControl("Last ROP examination (Date): (BOTH EYES ZONE II STAGE I ROP WITH PRE PLUS DISEASE). Please come for eye check up on (Day) at (Time) in NICU after confirming with EYE OPD between (Time).", []),
      dischargetillkg: new FormControl("", []),
      dischargeafterkg: new FormControl("", []),
      nutrition: new FormControl("Baby is receiving milk (EBM via OGT or Breast milk via Vati & spoon) … cc every … hrly. Corrected gestational age at discharge …weeks", []),
      followup_a_oae: new FormControl("OAE:", []),
      followup_b_bera: new FormControl("BERA: After 3months", []),
      followup_c_rop: new FormControl("ROP: Please come for ROP screening on ……with prior appointment", []),
      followup_d_nbst: new FormControl("NBST:", []),
      followup_e: new FormControl("NEURODEVELOPMENTAL FOLLOW UP AT 3,6,9 AND 12 MONTHS DEVELOPMENTAL QUOTIENT AT 18 MONTHS OF AGE", []),
      followup_f_usgbrain: new FormControl("USG Brain: ", []),
      followup_f_mri: new FormControl("MRI:", []),
      followup_g_surgicalfoll: new FormControl("Surgical Follow up: Please come to pediatric surgery OPD on ……. between….", []),
      followup_h_ortho: new FormControl("Ortho:", []),
      followup_h_ent: new FormControl("ENT:", []),
      followup_h_neurology: new FormControl("Neurology:", []),
      RFT: new FormControl('', []),
      LFT: new FormControl('', []),
      Ferritin: new FormControl('', []),
      Hmg: new FormControl('', [])
    }
  }

  updateData(rowid) {
    try {
      console.log("row id===", rowid, "get data from ui =====", this.getDataFromtext);
      let replaceStr1 = this.getDataFromtext ? this.getDataFromtext.replaceAll('[', '') : this.getDataFromtext;
      let replaceStr2 = replaceStr1.replaceAll(']', '');
      console.log("Actual String Data ==============", replaceStr2);

      //find out v and update string

      this.summaryList.filter((x) => {
        if (x.v === rowid) {
          x.ts = replaceStr2;
        }
      })

      console.log("Updated summary list ============", this.summaryList);

    } catch (err) {
      console.log(err);
    }
  }

  updateVariable(row) {
    try {
      this.getDataFromtext = row.ts;
      console.log("update data ==", this.getDataFromtext);

    } catch (err) {
      console.log(err);
    }
  }

  selectedInvestigation(recentInvestigation) {
    try {
      if (recentInvestigation) {
        console.log("Recent investigation ====", recentInvestigation);
        switch (recentInvestigation) {
          case 'HMG':
            this.getRecentInvestigation('HMG');
            this.hbgFlag = true;
            this.bioChemistryFlag = false;
            this.screenFlag = false;
            this.biirubinFlag = false;
            this.OPPFlag = false;
            this.Metabolic_WorkupFlag = false;
            this.OthersFlag = false;
            this.UrineFlag = false;
            this.Hypoglycemia_WorkupFlag = false;
            this.Inflamatory_MarkersFlag = false;
            this.LFTFlag = false;
            this.NBSTFlag = false;
            break;
          case 'Biochemistry':
            this.getRecentInvestigation('Biochemistry');
            this.hbgFlag = false;
            this.bioChemistryFlag = true;
            this.screenFlag = false;
            this.biirubinFlag = false;
            this.OPPFlag = false;
            this.Metabolic_WorkupFlag = false;
            this.OthersFlag = false;
            this.UrineFlag = false;
            this.Hypoglycemia_WorkupFlag = false;
            this.Inflamatory_MarkersFlag = false;
            this.LFTFlag = false;
            this.NBSTFlag = false;
            break;
          case 'Sepsis Screen':
            this.getRecentInvestigation('Sepsis Screen');
            this.hbgFlag = false;
            this.bioChemistryFlag = false;
            this.screenFlag = true;
            this.biirubinFlag = false;
            this.OPPFlag = false;
            this.Metabolic_WorkupFlag = false;
            this.OthersFlag = false;
            this.UrineFlag = false;
            this.Hypoglycemia_WorkupFlag = false;
            this.Inflamatory_MarkersFlag = false;
            this.LFTFlag = false;
            this.NBSTFlag = false;
            break;
          case 'S.Biirubin':
            this.getRecentInvestigation('S.Biirubin');
            this.hbgFlag = false;
            this.bioChemistryFlag = false;
            this.screenFlag = false;
            this.biirubinFlag = true;
            this.OPPFlag = false;
            this.Metabolic_WorkupFlag = false;
            this.OthersFlag = false;
            this.UrineFlag = false;
            this.Hypoglycemia_WorkupFlag = false;
            this.Inflamatory_MarkersFlag = false;
            this.LFTFlag = false;
            this.NBSTFlag = false;
            break;
          case 'Others':
            this.getRecentInvestigation('Others');
            this.hbgFlag = false;
            this.bioChemistryFlag = false;
            this.screenFlag = false;
            this.biirubinFlag = false;
            this.OPPFlag = false;
            this.Metabolic_WorkupFlag = false;
            this.OthersFlag = true;
            this.UrineFlag = false;
            this.Hypoglycemia_WorkupFlag = false;
            this.Inflamatory_MarkersFlag = false;
            this.LFTFlag = false;
            this.NBSTFlag = false;
            break;
          case 'NBST':
            this.getRecentInvestigation('NBST');
            this.hbgFlag = false;
            this.bioChemistryFlag = false;
            this.screenFlag = false;
            this.biirubinFlag = false;
            this.OPPFlag = false;
            this.NBSTFlag = true;
            this.Metabolic_WorkupFlag = false;
            this.OthersFlag = false;
            this.UrineFlag = false;
            this.Hypoglycemia_WorkupFlag = false;
            this.Inflamatory_MarkersFlag = false;
            this.LFTFlag = false;
            break;
          case 'OOP':
            this.getRecentInvestigation('OOP');
            this.hbgFlag = false;
            this.bioChemistryFlag = false;
            this.screenFlag = false;
            this.biirubinFlag = false;
            this.OPPFlag = true;
            this.Metabolic_WorkupFlag = false;
            this.OthersFlag = false;
            this.UrineFlag = false;
            this.Hypoglycemia_WorkupFlag = false;
            this.Inflamatory_MarkersFlag = false;
            this.LFTFlag = false;
            this.NBSTFlag = false;
            break;
          case 'Metabolic Workup':
            this.getRecentInvestigation('Metabolic Workup');
            this.hbgFlag = false;
            this.bioChemistryFlag = false;
            this.screenFlag = false;
            this.biirubinFlag = false;
            this.OPPFlag = false;
            this.Metabolic_WorkupFlag = true;
            this.OthersFlag = false;
            this.UrineFlag = false;
            this.Hypoglycemia_WorkupFlag = false;
            this.Inflamatory_MarkersFlag = false;
            this.LFTFlag = false;
            this.NBSTFlag = false;
            break;
          case 'Urine':
            this.getRecentInvestigation('Urine');
            this.hbgFlag = false;
            this.bioChemistryFlag = false;
            this.screenFlag = false;
            this.biirubinFlag = false;
            this.OPPFlag = false;
            this.Metabolic_WorkupFlag = false;
            this.OthersFlag = false;
            this.UrineFlag = true;
            this.Hypoglycemia_WorkupFlag = false;
            this.Inflamatory_MarkersFlag = false;
            this.LFTFlag = false;
            this.NBSTFlag = false;
            break;
          case 'Hypoglycemia Workup':
            this.getRecentInvestigation('Hypoglycemia Workup');
            this.hbgFlag = false;
            this.bioChemistryFlag = false;
            this.screenFlag = false;
            this.biirubinFlag = false;
            this.OPPFlag = false;
            this.Metabolic_WorkupFlag = false;
            this.OthersFlag = false;
            this.UrineFlag = false;
            this.Hypoglycemia_WorkupFlag = true;
            this.Inflamatory_MarkersFlag = false;
            this.LFTFlag = false;
            this.NBSTFlag = false;
            break;
          case 'Inflamatory Markers':
            this.getRecentInvestigation('Inflamatory Markers');
            this.hbgFlag = false;
            this.bioChemistryFlag = false;
            this.screenFlag = false;
            this.biirubinFlag = false;
            this.OPPFlag = false;
            this.Metabolic_WorkupFlag = false;
            this.OthersFlag = false;
            this.UrineFlag = false;
            this.Hypoglycemia_WorkupFlag = false;
            this.Inflamatory_MarkersFlag = true;
            this.LFTFlag = false;
            this.NBSTFlag = false;
            break;
          case 'LFT':
            this.getRecentInvestigation('LFT');
            this.hbgFlag = false;
            this.bioChemistryFlag = false;
            this.screenFlag = false;
            this.biirubinFlag = false;
            this.OPPFlag = false;
            this.Metabolic_WorkupFlag = false;
            this.OthersFlag = false;
            this.UrineFlag = false;
            this.Hypoglycemia_WorkupFlag = false;
            this.Inflamatory_MarkersFlag = false;
            this.LFTFlag = true;
            this.NBSTFlag = false;
            break;
        }
      }
    } catch (err) {
      console.log(err);
    }
  }

  getbabydetails() {
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    console.log("session storage value => ", userData);
    let dummy_data = {
      "babyno": null,
      "babyname": null,
      "machineid": null,
      "clientid": userData.clientid,
      "isactive": true,
      "page": 1,
      "pagesize": 10000
    }
    this.mainserviceService.getbabyid(dummy_data).subscribe((res) => {
      console.log("Baby Details => ", res.data);
      this.BabyList = res.data;
      //babyid
      // this.filterArray = res.data;
      // this.userList = res.data;

      // this.BabyListprint = this.genarte_report();
      // console.log("Daily Baby Updated Report => ", this.BabyListprint);
    }, (err) => {
      console.log(err.error);

    });
  }

  genarte_report() {

    for (let i = 0; i < this.BabyList.length; i++) {
      let dummy_data = {
        "babyid": this.BabyList[i].babyid
      }
      console.log("Baby Id Pass =>", dummy_data);
      this.mainserviceService.getdischargereport(dummy_data).subscribe((res) => {
        console.log("Dialy Baby Report => ", res, res.data)
        //this.BabyList[i].push()
        if (res.status) {
          this.BabyList[i].awspath = res.data[0].awspath
          this.BabyList[i].awspathfalg = "Download";
          console.log("Updated Aws Key=>", this.BabyList);
        } else {
          this.BabyList[i].awspath = null;
          this.BabyList[i].awspathfalg = "Report Not available";
        }

      });


    }
    return this.BabyList;
  }

  genrateReport() {
    try {
      console.log("form value", this.sleetecf.value, this.babyid.value);
      this.status = "Report Genration in Progress..."
      if ((this.sleetecf.value != null || this.sleetecf.value != undefined) && (this.babyid.value != null || this.babyid.value != undefined)) {
        let obj = {
          "babyid": this.babyid.value,
          "cfdata": this.sleetecf.value
        }

        console.log("Baby Id Pass =>", obj);
        this.mainserviceService.getdischargereport(obj).subscribe((res) => {
          console.log("Dialy Baby Report => ", res, res.data)

          if (res) {
            this.downloadflag = true;
            this.status = "Report Download Succesfully"
            this.awspath = res.data[0].awspath
          } else {
            this.status = "Report is not Genrate,Something Wrong!"
          }


        });


      }
    } catch (err) {

    }
  }

  downloaddocx() {
    try {
      this.awspath = ""
      this.status = "Genrate Report"

    } catch (err) {

    }
  }

  treatmentSummary() {
    try {
      console.log("sleetecf=> ", this.sleetecf);
    } catch (err) {
      console.log(err);
    }
  }

  selected(disease) {
    try {
      let res = this.summaryList.filter(x => {
        if (this.data[disease].cf === x.cf) {
          return true;
        }
      })

      if (res.length === 0) {
        console.log("response =================> ", res);
        this.summaryList.push(this.data[disease]);
      }

      console.log("disease list =====================", disease, this.summaryList);
    } catch (err) {
      console.log(err);
    }
  }

  selectedBaby = (baby: any) => {
    try {
      console.log("baby details => ", baby);
      this.babyDetails = baby;
      this.babyidReq = baby.babyid;
      this.babygender = baby.gender;
      this.gweeks = baby.week;
      this.gdays = baby.days;
      this.displayDischargeform = true;

      this.getBabyReport(this.babyidReq);
      this.initDischargeTemplate(baby);
      this.getmedicinemasterdetails(baby.babyid);
      this.getRecentInvestigation('HMG');
      this.getImaging('USG Brain');
    } catch (errBaby) {
      console.log("err =========", errBaby);
    }
  }

  check() {
    console.log("baby => ", this.babyreport);
  }

  genratetreatmentsummaryas = (summary: any) => {
    try {
      let neonatal_nicu_journey = [];
      for (let i = 0; i < summary.length; i++) {
        neonatal_nicu_journey.push({ 'id': i + 1, 'cf': summary[i].cf, 'ts': summary[i].ts });
      }
      return neonatal_nicu_journey;
    } catch (err) {

    }
  }

  getmedicinemasterdetails(babyid: any) {
    try {
      console.log("babyid => ", babyid);
      this.medicineList = [];
      var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
      let obj = {
        "medicineid": null,
        "babyid": babyid,
        "fromdate": moment(new Date()).subtract(30, 'd').format('YYYY-MM-DD'),
        "todate": moment(new Date()).format('YYYY-MM-DD'),
        "clientid": userData.clientid
      }

      this.mainserviceService.getmedicine(obj).subscribe((res) => {

        if (res.status_code == "s_407") {
          //this.dosgaeunits = res.data;
          this.medicineList = res.data;
          console.log("Medicine list => ", this.medicineList);
        }
      }, (err) => {
        console.log(err.error);
      });
    } catch (err) {

    }
  }


  genrateBabyDischargeReport = () => {
    try {
      this.downloadLayout = true;
      this.status = "Report Generation in Progress...";
      let sentenceGDm = this.GDMmanagedwith == "non diabetic" ? "" : "GDM managed with " + this.GDMmanagedwith + ".";
      let sentencebabycried = this.babycried == "CPR" ? this.babycriedsecond + " seconds as per NPR guidelines" : " ";
      let dateofbirth = new Date(this.babyReportData.dateofdelivery).getDay() + '/' + new Date(this.babyReportData.dateofdelivery).getMonth() + '/' + new Date(this.babyReportData.dateofdelivery).getFullYear();
      console.log("Discharge report details => ", this.babyreport);
      let templateObj = {
        babyid: this.babyidReq,
        template: {
          maternal_history: { id: 1, content: `${this.babyReportData.mothername} is a ${this.babyReportData.motherage ? this.babyReportData.motherage : '-'} years old, G(${this.babyReportData.o_history_g ? this.babyReportData.o_history_g : '-'} ) P(${this.babyReportData.o_history_p ? this.babyReportData.o_history_p : '-'}) A(${this.babyReportData.o_history_a ? this.babyReportData.o_history_a : '-'}) L(${this.babyReportData.o_history_l ? this.babyReportData.o_history_l : '-'}) D(${this.babyReportData.o_history_d ? this.babyReportData.o_history_d : '-'}), whose blood group is ${this.babyReportData.motherbloodgroup ? this.babyReportData.motherbloodgroup : '-'}.Her antenatal scan was suggestive of ${this.babyReportData.usg ? this.babyReportData.usg : '-'} with doppler ${this.babyReportData.uaflow ? this.babyReportData.uaflow : '-'} flow.${this.babyReportData.antenatealsteroids != "no" ? 'The pregnancy was covered by' + this.babyReportData.antenatealsteroids + 'antenatal steroids.' : ''}She delivered at ${this.babyReportData.hospitalname ? this.babyReportData.hospitalname : '-'} by Dr. ${this.babyReportData.obstetrician ? this.babyReportData.obstetrician : '-'} via ${this.babyReportData.modeofdelivery ? this.babyReportData.modeofdelivery : '-'} delivery.This Pregnancy was conceived ${this.babyReportData.assistedreproduction ? this.babyReportData.assistedreproduction : '-'}.Pregnancy was complicated by ${this.babyReportData.pih ? this.babyReportData.pih + ',' : ''}${this.babyReportData.chronicmedicalillness ? this.babyReportData.chronicmedicalillness + ',' : ''}${this.babyReportData.thyroidstatus ? this.babyReportData.thyroidstatus + ',' : ''}${this.babyReportData.infectiondisease ? this.babyReportData.infectiondisease + ',' : ''}${this.babyReportData.diabetes ? this.babyReportData.diabetes + ',' : ''} and managed by ${this.babyReportData.medicationandduration ? this.babyReportData.medicationandduration : ''} ,${this.babyReportData.mgso.length > 0 ? 'MgSo4 is ' + this.babyReportData.mgso + ',' : ''}.PV leaking was ${this.babyReportData.pvleak ? this.babyReportData.pvleak : ''}.` },
          perinatal_history: { id: 2, content: `B/O ${this.babyReportData.mothername},${this.babygender} child was born on ${dateofbirth} at ${this.babyReportData.timeofdelivery ? this.babyReportData.timeofdelivery : '-'} with a birth weight of ${this.currentBabyReportData.bornweight} kg at gestational age ${this.gweeks} weeks & ${this.gdays} days.Baby was born by a ${this.babyReportData.presentation ? this.babyReportData.presentation : '-'} presentation via ${this.babyReportData.modeofdelivery ? this.babyReportData.modeofdelivery : '-'} delivery with ${this.babyReportData.liquor ? this.babyReportData.liquor : '-'} liquor and ${this.babyReportData.resuscitation ? this.babyReportData.resuscitation : '-'} .Apgar scores were ${this.babyReportData.apgaronemin ? this.babyReportData.apgaronemin : '-'} & ${this.babyReportData.apgarfivemin ? this.babyReportData.apgarfivemin : '-'} at 1 and 5 mins respectively.Baby was ${this.babyReportData.deliveryroomcpap ? this.babyReportData.deliveryroomcpap : '-'} delivery room CPAP.Cord clamping was ${this.babyReportData.cordclamping ? this.babyReportData.cordclamping : '-'}.Baby was shifted to NICU in view of ${this.babyReportData.caugeofadmission == "others" ? this.babyReportData.causecomment : this.babyReportData.caugeofadmission}.` },
          tratmentjourney: this.genratetreatmentsummaryas(this.summaryList),
          medicinelist: this.medicineList,
          recentInvestigations: this.createRecentTemplate(),
          imaging: this.createImaging(),
          rop: this.babyreport.rop.value,
          medicationadvice: {
            dischargetillkg: this.babyreport.dischargetillkg.value,
            dischargeafterkg: this.babyreport.dischargeafterkg.value
          },
          nutrition: this.babyreport.nutrition.value,
          followup: {
            followup_a_oae: this.babyreport.followup_a_oae.value,
            followup_b_bera: this.babyreport.followup_b_bera.value,
            followup_c_rop: this.babyreport.followup_c_rop.value,
            followup_d_nbst: this.babyreport.followup_d_nbst.value,
            followup_e: this.babyreport.followup_e.value,
            followup_f_mri: this.babyreport.followup_f_mri.value,
            followup_f_usgbrain: this.babyreport.followup_f_usgbrain.value,
            followup_g_surgicalfoll: this.babyreport.followup_g_surgicalfoll.value,
            followup_h_ent: this.babyreport.followup_h_ent.value,
            followup_h_neurology: this.babyreport.followup_h_neurology.value,
            followup_h_ortho: this.babyreport.followup_h_ortho.value,
            followup_RFT: this.babyreport.RFT.value,
            followup_LFT: this.babyreport.LFT.value,
            followup_Ferritin: this.babyreport.Ferritin.value,
            followup_Hmg: this.babyreport.Hmg.value
          }
        }
      }


      console.log("Baby Id template =>", templateObj);

      this.mainserviceService.getdischargereportclone(templateObj).subscribe((res) => {
        console.log("Dialy Baby Report => ", res, res.data)
        if (res) {
          this.status = "Report Download Succesfully"
          this.awspath = res.data[0].awspath
          console.log("aws path => ", this.awspath);
          this.genrateReportLog(this.awspath, this.babyid);
          this.downloadflag = true;
        } else {
          this.status = "Report is not Generate,Something Wrong!"
        }
      });

    } catch (errBabyDischarge) {
      console.log('err', errBabyDischarge);
    }
  }

  formView() {
    setTimeout(() => {
      this.downloadLayout = false;
      this.displayDischargeform = false;
      this.babyid = new FormControl(null, []);
      this.summaryList = [];
      this.initDischargeTemplate({ mothername: "Mother Name" })
    }, 400);
  }

  genrateReportLog = (reportpath: String, babyid: any) => {
    try {

      console.log("Log Data ------------------", {
        reportpath: reportpath ? reportpath : null,
        babyid: babyid.value ? babyid.value : null,
        downloaddate: new Date().toISOString(),
      });
      this.mainserviceService.createReportlog({
        reportpath: reportpath ? reportpath : null,
        babyid: babyid.value ? babyid.value : null,
        downloaddate: new Date().toISOString(),
      }).subscribe((res) => {
        console.log("Report updated response===============", res);
      });

    } catch (errGenrateReportLog) {
      console.log("Genrate report log===============", errGenrateReportLog);
    }
  }

  getBabyReport = (babyid) => {
    try {
      console.log("Get baby data ===", babyid);
      this.mainserviceService.getBabyReportData({ 'babyid': babyid }).subscribe((res) => {

        this.babyReportData = res ? res.data : [];
        console.log("Get Baby Report response => ", res, this.babyReportData);
        if(this.babyReportData){
          let dateofbirth = new Date(this.babyReportData.dateofdelivery).getDay() + '/' + new Date(this.babyReportData.dateofdelivery).getMonth() + '/' + new Date(this.babyReportData.dateofdelivery).getFullYear();
          this.meternal_history_content_clone = `${this.babyReportData.mothername} is a ${this.babyReportData.motherage ? this.babyReportData.motherage : '-'} years old, G(${this.babyReportData.o_history_g ? this.babyReportData.o_history_g : '-'} ) P(${this.babyReportData.o_history_p ? this.babyReportData.o_history_p : '-'}) A(${this.babyReportData.o_history_a ? this.babyReportData.o_history_a : '-'}) L(${this.babyReportData.o_history_l ? this.babyReportData.o_history_l : '-'}) D(${this.babyReportData.o_history_d ? this.babyReportData.o_history_d : '-'}), whose blood group is ${this.babyReportData.motherbloodgroup ? this.babyReportData.motherbloodgroup : '-'}.Her antenatal scan was suggestive of ${this.babyReportData.usg ? this.babyReportData.usg : '-'} with doppler ${this.babyReportData.uaflow ? this.babyReportData.uaflow : '-'} flow.${this.babyReportData.antenatealsteroids != "no" ? 'The pregnancy was covered by' + this.babyReportData.antenatealsteroids + 'antenatal steroids.' : ''}She delivered at ${this.babyReportData.hospitalname ? this.babyReportData.hospitalname : '-'} by Dr. ${this.babyReportData.obstetrician ? this.babyReportData.obstetrician : '-'} via ${this.babyReportData.modeofdelivery ? this.babyReportData.modeofdelivery : '-'} delivery.This Pregnancy was conceived ${this.babyReportData.assistedreproduction ? this.babyReportData.assistedreproduction : '-'}.Pregnancy was complicated by ${this.babyReportData.pih ? this.babyReportData.pih + ',' : ''}${this.babyReportData.chronicmedicalillness ? this.babyReportData.chronicmedicalillness + ',' : ''}${this.babyReportData.thyroidstatus ? this.babyReportData.thyroidstatus + ',' : ''}${this.babyReportData.infectiondisease ? this.babyReportData.infectiondisease + ',' : ''}${this.babyReportData.diabetes ? this.babyReportData.diabetes + ',' : ''} and managed by ${this.babyReportData.medicationandduration ? this.babyReportData.medicationandduration : ''} ,${this.babyReportData.mgso.length > 0 ? 'MgSo4 is ' + this.babyReportData.mgso + ',' : ''}.PV leaking was ${this.babyReportData.pvleak ? this.babyReportData.pvleak : ''}.`;
          this.perinatel_history_content_clone =  `B/O ${this.babyReportData.mothername},${this.babygender} child was born on ${dateofbirth} at ${this.babyReportData.timeofdelivery ? this.babyReportData.timeofdelivery : '-'} with a birth weight of ${this.currentBabyReportData.bornweight} kg at gestational age ${this.gweeks} weeks & ${this.gdays} days.Baby was born by a ${this.babyReportData.presentation ? this.babyReportData.presentation : '-'} presentation via ${this.babyReportData.modeofdelivery ? this.babyReportData.modeofdelivery : '-'} delivery with ${this.babyReportData.liquor ? this.babyReportData.liquor : '-'} liquor and ${this.babyReportData.resuscitation ? this.babyReportData.resuscitation : '-'} .Apgar scores were ${this.babyReportData.apgaronemin ? this.babyReportData.apgaronemin : '-'} & ${this.babyReportData.apgarfivemin ? this.babyReportData.apgarfivemin : '-'} at 1 and 5 mins respectively.Baby was ${this.babyReportData.deliveryroomcpap ? this.babyReportData.deliveryroomcpap : '-'} delivery room CPAP.Cord clamping was ${this.babyReportData.cordclamping ? this.babyReportData.cordclamping : '-'}.Baby was shifted to NICU in view of ${this.babyReportData.caugeofadmission == "others" ? this.babyReportData.causecomment : this.babyReportData.caugeofadmission}.`
        }

      }, (err) => {
        console.log(err);
      });

    } catch (err) {
      console.log(err);
    }
  }

  addRecentInvestigation() {
    try {

      switch (this.recentInvestigation) {
        case 'HBG':
          this.recentInvestigationList.push({
            date: "",
            header: this.recentInvestigation,
            HB: this.HB ? this.HB : '-',
            WBC: this.WBC ? this.WBC : '-',
            PLATELET: this.PLATELET ? this.PLATELET : '-',
            PCR: this.PCR ? this.PCR : '-',
            NEUTROPHILS: this.NEUTROPHILS ? this.NEUTROPHILS : '-',
            ANC: this.ANC ? this.ANC : '-'
          });
          console.log("recent Data =============", this.recentInvestigationList);

          break;
        case 'Biochemistry':

          this.bioChemistryList.push({
            header: this.recentInvestigation,
            RFTUREA: this.RFTUREA ? this.RFTUREA : '-',
            Creatine: this.Creatine ? this.Creatine : '-',
            SE: this.SE ? this.SE : '-',
            Na: this.Na ? this.Na : '-',
            K: this.K ? this.K : '-',
            Ca: this.Ca ? this.Ca : '-',
            Mg: this.Mg ? this.Mg : '-'
          });
          console.log("recent Data =============", this.bioChemistryList);
          break;
        case 'Sepsis Screen':

          break;
        case 'Blood Group':

          break;
        case 'S.Biirubin(T)':

          break;
      }

    } catch (err) {
      console.log(err);
    }
  }

  openLg2(content3, row) {
    console.log("treatment order view Details ========================", row);
    this.modalService.open(content3, { size: 'lg' });
  }

  openLg3(content4, row) {
    console.log("treatment order view Details ========================", row);
    this.modalService.open(content4, { size: 'lg' });
  }

  selectedImaging(row) {
    try {
      console.log("Imaging Data ========", row);
      try {
        if (this.imaging) {
          console.log("Recent imaging ====", this.imaging);
          switch (this.imaging) {
            case 'USG Brain':
              this.getImaging('USG Brain');
              this.USGBrainFlag = true;
              this.USG_ATPFlag = false;
              this.USG_KUBFlag = false;
              break;
            case 'USG Abdomen':
              this.getImaging('USG Abdomen');
              this.USGBrainFlag = false;
              this.USG_ATPFlag = true;
              this.USG_KUBFlag = false;
              break;

          }
        }
      } catch (err) {
        console.log(err);
      }
    } catch (err) {
      console.log(err);
    }
  }

  //selectedHMG
  selectedHMG = (row) => {
    try {
      console.log("selected row ========", row);

      this.recentInvestigationHMGReportList.push(row);
    } catch (err) {
      console.log(err);
    }
  }

  //selectedBiochemistry
  selectedBiochemistry = (row) => {
    try {
      this.recentInvestigationBiochemistryReportList.push(row);
    } catch (err) {
      console.log(err);
    }
  }

  //SBiirubin
  selectedSBiirubin = (row) => {
    try {
      console.log("selected", row);
      this.recentInvestigationSBiirubinReportList.push(row);
      console.log("selected row", this.recentInvestigationSBiirubinReportList);
    } catch (err) {
      console.log(err);
    }
  }
  //selectedOPP
  selectedopp = (row) => {
    try {
      this.recentIvestigationoppReportList.push(row);
    } catch (err) {
      console.log(err);
    }
  }

  //selectedMetabolic_Workup
  selectedMetabolic_Workup = (row) => {
    try {
      this.recentIvestigationMetabolic_WorkupReportList.push(row);
    } catch (err) {
      console.log(err);
    }
  }

  //selectedOthers
  selectedOthers = (row) => {
    try {
      this.recentIvestigationOthersReportList.push(row);
    } catch (err) {
      console.log(err);
    }
  }

  //selectedOthers
  selectedNBST = (row) => {
    try {
      this.recentIvestigationNBSTReportList.push(row);
    } catch (err) {
      console.log(err);
    }
  }

  //selectedUrine
  selectedUrine = (row) => {
    try {
      this.recentIvestigationUrineReportList.push(row);
    } catch (err) {
      console.log(err);
    }
  }

  //selectedHyPoglycemia_Workup
  selectedHyPoglycemia_Workup = (row) => {
    try {
      this.recentIvestigationHyPoglycemia_WorkupReportList.push(row);
    } catch (err) {
      console.log(err);
    }
  }

  //selectedHyInflamatoryMarkers
  selectedHyInflamatoryMarkers = (row) => {
    try {
      this.recentIvestigationHyInflamatoryMarkersReportList.push(row);
    } catch (err) {
      console.log(err);
    }
  }

  //selectedLFT
  selectedLFT = (row) => {
    try {
      this.recentIvestigationLFTReportList.push(row);
    } catch (err) {
      console.log(err);
    }
  }

  //selected USG
  selectedUSG = (row) => {
    try {
      this.USG_BrainViweReportList.push(row);
    } catch (err) {
      console.log(err);
    }
  }

  //selected ATP
  selectedATP = (row) => {
    try {
      this.USG_ATPViewReportList.push(row);
    } catch (err) {
      console.log(err);
    }
  }

  //selected KUB
  selectedKUB = (row) => {
    try {
      this.USG_KUBViewReportList.push(row);
    } catch (err) {
      console.log(err);
    }
  }

  //get recent investigation
  getRecentInvestigation = (recentInvestigation) => {
    try {
      this.mainserviceService.getRecentInvestigation({
        "babyid": this.babyidReq,
        "clientid": JSON.parse(sessionStorage.getItem('userInfo1')).usermasterid,
        "recentInvestigationHeader": recentInvestigation,
        "page": 1,
        "pagesize": 10000
      }).subscribe((res) => {
        console.log("Get RecentInvestigation => ", res);
        if (res.data) {
          if (recentInvestigation === "HMG") {
            this.recentInvestigationList = res.data;
          } else if (recentInvestigation === "Biochemistry") {
            this.recentInvestigationBiochemistryList = res.data;
          } else if (recentInvestigation === "Sepsis Screen") {
            this.recentInvestigationSepsisScreenList = res.data;
          } else if (recentInvestigation === "S.Biirubin") {
            this.recentInvestigationSBiirubinList = res.data;
          } else if (recentInvestigation === "Others") {
            this.recentIvestigationOthersList = res.data;
          } else if (recentInvestigation === "NBST") {
            this.recentIvestigationNBSTList = res.data;
          } else if (recentInvestigation === "Metabolic Workup") {
            this.recentIvestigationMetabolic_WorkupList = res.data;
          } else if (recentInvestigation === "Urine") {
            this.recentIvestigationUrineList = res.data;
          } else if (recentInvestigation === "Hypoglycemia Workup") {
            this.recentIvestigationHyPoglycemia_WorkupList = res.data;
          } else if (recentInvestigation === "Inflamatory Markers") {
            this.recentIvestigationHyInflamatoryMarkersList = res.data;
          } else if (recentInvestigation === "LFT ") {
            this.recentIvestigationLFTList = res.data;
          }
        } else {
          //empty data
        }
      }, (err) => {
        console.log("error ==", err);
      });
    } catch (err) {
      console.log("error ", err);
    }
  }

  //get imaging
  getImaging = (imaging) => {
    try {
      console.log("get Imaging response ========", {
        "babyid": this.babyidReq,
        "clientid": JSON.parse(sessionStorage.getItem('userInfo1')).usermasterid,
        "imagingHeader": imaging,
        "page": 1,
        "pagesize": 10000
      });
      this.mainserviceService.getImaging({
        "babyid": this.babyidReq,
        "clientid": JSON.parse(sessionStorage.getItem('userInfo1')).usermasterid,
        "imagingHeader": imaging,
        "page": 1,
        "pagesize": 10000
      }).subscribe((res) => {
        console.log("Get Imaging => ", res);
        if (res.data) {
          if (imaging == "USG Brain") {
            this.USG_BrainViweList = res.data;
            console.log("updated to var =====" + imaging + " = ", this.USG_BrainViweList);
          } else if (imaging == "USG(ATP)") {
            this.USG_ATPViewList = res.data;
            console.log("updated to var =====" + imaging + " = ", this.USG_ATPViewList);
          } else if (imaging == "USG(KUB)") {
            this.USG_KUBViewList = res.data;
            console.log("updated to var =====" + imaging + " = ", this.USG_KUBViewList);
          }
        } else {
          //empty data
        }
      }, (err) => {
        console.log(err.error);
      });
    } catch (err) {
      console.log(err);
    }
  }

  //create recentimaging
  createRecentTemplate = () => {
    try {
      let recentTemplate = [];
      console.log("Hmg-----------------------", this.recentInvestigationHMGReportList.length)
      if (this.recentInvestigationHMGReportList && this.recentInvestigationHMGReportList.length > 0) {
        recentTemplate.push({
          mainHeader: 'HMG',
          header1: "HB",
          header2: "WBC",
          header3: "PLATELET",
          header4: "PCR",
          header5: "NEUTROPHILS",
          header6: "ANC",
          recentInvestigationDate: moment(new Date(this.recentInvestigationHMGReportList[0].recentInvestigationDate)).format('YYYY-MM-DD'),
          HB: this.recentInvestigationHMGReportList[0].HB,
          WBC: this.recentInvestigationHMGReportList[0].WBC,
          PLATELET: this.recentInvestigationHMGReportList[0].PLATELET,
          PCR: this.recentInvestigationHMGReportList[0].PCR,
          NEUTROPHILS: this.recentInvestigationHMGReportList[0].NEUTROPHILS,
          ANC: this.recentInvestigationHMGReportList[0].ANC
        });

      } else {
        recentTemplate.push({
          mainHeader: 'HMG',
          header1: "HB",
          header2: "WBC",
          header3: "PLATELET",
          header4: "PCR",
          header5: "NEUTROPHILS",
          header6: "ANC",
          recentInvestigationDate: '-',
          HB: '-',
          WBC: '-',
          PLATELET: '-',
          PCR: '-',
          NEUTROPHILS: '-',
          ANC: '-',
        });

      }
      if (this.recentInvestigationBiochemistryReportList && this.recentInvestigationBiochemistryReportList.length > 0) {
        recentTemplate.push({
          mainHeader: "Biochemistry",
          header1: "RFTUREA",
          header2: "Creatine",
          header3: "SE",
          header4: "Na",
          header5: "K",
          header6: "Ca",
          header7: "Mg",
          recentInvestigationDate: moment(new Date(this.recentInvestigationBiochemistryReportList[0].recentInvestigationDate)).format('YYYY-MM-DD'),
          RFTUREA: this.recentInvestigationBiochemistryReportList[0].RFTUREA,
          Creatine: this.recentInvestigationBiochemistryReportList[0].Creatine,
          SE: this.recentInvestigationBiochemistryReportList[0].SE,
          Na: this.recentInvestigationBiochemistryReportList[0].Na,
          K: this.recentInvestigationBiochemistryReportList[0].K,
          Ca: this.recentInvestigationBiochemistryReportList[0].Ca,
          Mg: this.recentInvestigationBiochemistryReportList[0].Mg
        });
      } else {
        recentTemplate.push({
          mainHeader: "Biochemistry",
          header1: "RFTUREA",
          header2: "Creatine",
          header3: "SE",
          header4: "Na",
          header5: "K",
          header6: "Ca",
          header7: "Mg",
          recentInvestigationDate: '-',
          RFTUREA: '-',
          Creatine: '-',
          SE: '-',
          Na: '-',
          K: '-',
          Ca: '-',
          Mg: '-',
        });
      }
      if (this.recentInvestigationSepsisScreenReportList && this.recentInvestigationSepsisScreenReportList.length > 0) {
        recentTemplate.push({
          mainHeader: "Sepsis Screen",
          header1: "CRP",
          header2: "BloodCells",
          header3: "UrineRoutine",
          header4: "CSF",
          header5: "UrineCLS",
          header6: "CSFCLS",
          header7: "ETCLS",
          recentInvestigationDate: moment(new Date(this.recentInvestigationSepsisScreenReportList[0].recentInvestigationDate)).format('YYYY-MM-DD'),
          CRP: this.recentInvestigationSepsisScreenReportList[0].CRP,
          BloodCells: this.recentInvestigationSepsisScreenReportList[0].BloodCells,
          UrineRoutine: this.recentInvestigationSepsisScreenReportList[0].UrineRoutine,
          CSF: this.recentInvestigationSepsisScreenReportList[0].CSF,
          UrineCLS: this.recentInvestigationSepsisScreenReportList[0].UrineCLS,
          CSFCLS: this.recentInvestigationSepsisScreenReportList[0].CSFCLS,
          ETCLS: this.recentInvestigationSepsisScreenReportList[0].ETCLS
        })
      } else {
        recentTemplate.push({
          mainHeader: "Sepsis Screen",
          header1: "CRP",
          header2: "BloodCells",
          header3: "UrineRoutine",
          header4: "CSF",
          header5: "UrineCLS",
          header6: "CSFCLS",
          header7: "ETCLS",
          recentInvestigationDate: '-',
          CRP: '-',
          BloodCells: '-',
          UrineRoutine: '-',
          CSF: '-',
          UrineCLS: '-',
          CSFCLS: '-',
          ETCLS: '-'
        })
      }
      if (this.recentInvestigationSBiirubinReportList && this.recentInvestigationSBiirubinReportList.length > 0) {
        recentTemplate.push({
          mainHeader: "Sbilirubin",
          header1: "SBiirubin(T)",
          header2: "Direct",
          recentInvestigationDate: moment(new Date(this.recentInvestigationSBiirubinReportList[0].recentInvestigationDate)).format('YYYY-MM-DD'),
          SBiirubin_T: this.recentInvestigationSBiirubinReportList[0].SBiirubin_T,
          direct: this.recentInvestigationSBiirubinReportList[0].direct
        });
      } else {
        recentTemplate.push({
          mainHeader: "Sbilirubin",
          header1: "SBiirubin(T)",
          header2: "Direct",
          recentInvestigationDate: '-',
          SBiirubin_T: '-',
          direct: '-'
        });
      }
      if (this.recentIvestigationoppReportList && this.recentIvestigationoppReportList.length > 0) {
        recentTemplate.push({
          mainHeader: "OPP",
          header1: "Total_Cal",
          header2: "PO4",
          header3: "ALP",
          header4: "VitD",
          recentInvestigationDate: moment(new Date(this.recentIvestigationoppReportList[0].recentInvestigationDate)).format('YYYY-MM-DD'),
          Total_Cal: this.recentIvestigationoppReportList[0].Total_Cal,
          PO4: this.recentIvestigationoppReportList[0].PO4,
          ALP: this.recentIvestigationoppReportList[0].ALP,
          VitD: this.recentIvestigationoppReportList[0].VitD
        });
      } else {
        recentTemplate.push({
          mainHeader: "OPP",
          header1: "Total_Cal",
          header2: "PO4",
          header3: "ALP",
          header4: "VitD",
          recentInvestigationDate: '-',
          Total_Cal: '-',
          PO4: '-',
          ALP: '-',
          VitD: '-'
        });
      }
      if (this.recentIvestigationMetabolic_WorkupReportList && this.recentIvestigationMetabolic_WorkupReportList.length > 0) {
        recentTemplate.push({
          mainHeader: "Metabolic Workup",
          header1: "Ammonia",
          recentInvestigationDate: moment(new Date(this.recentIvestigationMetabolic_WorkupReportList[0].recentInvestigationDate)).format('YYYY-MM-DD'),
          Ammonia: this.recentIvestigationMetabolic_WorkupReportList[0].Ammonia
        });
      } else {
        recentTemplate.push({
          mainHeader: "Metabolic Workup",
          header1: "Ammonia",
          recentInvestigationDate: '-',
          Ammonia: '-',
        });
      }
      if (this.recentIvestigationOthersReportList && this.recentIvestigationOthersReportList.length > 0) {
        recentTemplate.push({
          mainHeader: "Others",
          header1: "Gastric_Aspirate",
          header2: "Fluid_Cytology",
          header3: "Biopsy",
          header4: "TFT",
          header5: "TORCH_IgG",
          header6: "IgM",
          recentInvestigationDate: moment(new Date(this.recentIvestigationOthersReportList[0].recentInvestigationDate)).format('YYYY-MM-DD'),
          Gastric_Aspirate: this.recentIvestigationOthersReportList[0].Gastric_Aspirate,
          Fluid_Cytology: this.recentIvestigationOthersReportList[0].Fluid_Cytology,
          Biopsy: this.recentIvestigationOthersReportList[0].Biopsy,
          TFT: this.recentIvestigationOthersReportList[0].TFT,
          TORCH_IgG: this.recentIvestigationOthersReportList[0].TORCH_IgG,
          IgM: this.recentIvestigationOthersReportList[0].IgM
        });
      } else {
        recentTemplate.push({
          mainHeader: "Others",
          header1: "Gastric_Aspirate",
          header2: "Fluid_Cytology",
          header3: "Biopsy",
          header4: "TFT",
          header5: "TORCH_IgG",
          header6: "IgM",
          recentInvestigationDate: '-',
          Gastric_Aspirate: '-',
          Fluid_Cytology: '-',
          Biopsy: '-',
          TFT: '-',
          TORCH_IgG: '-',
          IgM: '-'
        });
      }
      if (this.recentIvestigationNBSTReportList && this.recentIvestigationNBSTReportList.length > 0) {
        recentTemplate.push({
          mainHeader: "NBST",
          header1: "NBST",
          recentInvestigationDate: moment(new Date(this.recentIvestigationNBSTReportList[0].recentInvestigationDate)).format('YYYY-MM-DD'),
          NBST: this.recentIvestigationNBSTReportList[0].NBST
        });
      } else {
        recentTemplate.push({
          mainHeader: "NBST",
          header1: "NBST",
          recentInvestigationDate: '-',
          NBST: '-'
        });
      }

      if (this.recentIvestigationUrineReportList && this.recentIvestigationUrineReportList.length > 0) {
        recentTemplate.push({
          mainHeader: "Urine",
          header1: "Urine Cmv",
          recentInvestigationDate: moment(new Date(this.recentIvestigationUrineReportList[0].recentInvestigationDate)).format('YYYY-MM-DD'),
          urineCmv: this.recentIvestigationUrineReportList[0].NBST
        });
      } else {
        recentTemplate.push({
          mainHeader: "Urine",
          header1: "Urine Cmv",
          recentInvestigationDate: '-',
          urineCmv: '-'
        });
      }


      if (this.recentIvestigationHyPoglycemia_WorkupReportList && this.recentIvestigationHyPoglycemia_WorkupReportList.length > 0) {
        recentTemplate.push({
          mainHeader: "Hypoglycemia Workup",
          header1: "RBS",
          header2: "Sv",
          header3: "Cortisol",
          header4: "Sv Insulin",
          recentInvestigationDate: moment(new Date(this.recentIvestigationHyPoglycemia_WorkupReportList[0].recentInvestigationDate)).format('YYYY-MM-DD'),
          RBS: this.recentIvestigationHyPoglycemia_WorkupReportList[0].RBS,
          Sv: this.recentIvestigationHyPoglycemia_WorkupReportList[0].Sv,
          Cortisol: this.recentIvestigationHyPoglycemia_WorkupReportList[0].Cortisol,
          Sv_Insulin: this.recentIvestigationHyPoglycemia_WorkupReportList[0].Sv_Insulin,
        });
      } else {
        recentTemplate.push({
          mainHeader: "Hypoglycemia Workup",
          header1: "RBS",
          header2: "Sv",
          header3: "Cortisol",
          header4: "Sv Insulin",
          recentInvestigationDate: '-',
          RBS: '-',
          Sv: '-',
          Cortisol: '-',
          Sv_Insulin: '-'
        });
      }

      if (this.recentIvestigationHyInflamatoryMarkersReportList && this.recentIvestigationHyInflamatoryMarkersReportList.length > 0) {
        recentTemplate.push({
          mainHeader: "Inflamatory Markers",
          header1: "Ferrite",
          header2: "Fibrinogen",
          recentInvestigationDate: moment(new Date(this.recentIvestigationHyInflamatoryMarkersReportList[0].recentInvestigationDate)).format('YYYY-MM-DD'),
          Ferrite: this.recentIvestigationHyInflamatoryMarkersReportList[0].Ferrite,
          Fibrinogen: this.recentIvestigationHyInflamatoryMarkersReportList[0].Fibrinogen
        });
      } else {
        recentTemplate.push({
          mainHeader: "Inflamatory Markers",
          header1: "Ferrite",
          header2: "Fibrinogen",
          recentInvestigationDate: '-',
          Ferrite: '-',
          Fibrinogen: '-'
        });
      }
      if (this.recentIvestigationLFTReportList && this.recentIvestigationLFTReportList.length > 0) {
        recentTemplate.push({
          mainHeader: "LFT",
          header1: "SGPT",
          header2: "SGOT",
          header3: "GGT",
          header4: "ALPLFT",
          header5: "Protien",
          header6: "PTCINR",
          header7: "APTT",
          recentInvestigationDate: moment(new Date(this.recentIvestigationLFTReportList[0].recentInvestigationDate)).format('YYYY-MM-DD'),
          SGPT: this.recentIvestigationLFTReportList[0].SGPT,
          SGOT: this.recentIvestigationLFTReportList[0].SGOT,
          GGT: this.recentIvestigationLFTReportList[0].GGT,
          ALPLFT: this.recentIvestigationLFTReportList[0].ALPLFT,
          Bilirubin: this.recentIvestigationLFTReportList[0].Bilirubin,
          Protien: this.recentIvestigationLFTReportList[0].Protien,
          PTCINR: this.recentIvestigationLFTReportList[0].PTCINR,
          APTT: this.recentIvestigationLFTReportList[0].APTT
        });
      } else {
        recentTemplate.push({
          mainHeader: "LFT",
          header1: "SGPT",
          header2: "SGOT",
          header3: "GGT",
          header4: "ALPLFT",
          header5: "Protien",
          header6: "PTCINR",
          header7: "APTT",
          recentInvestigationDate: '-',
          SGPT: '-',
          SGOT: '-',
          GGT: '-',
          ALPLFT: '-',
          Bilirubin: '-',
          Protien: '-',
          PTCINR: '-',
          APTT: '-'
        });
      }

      console.log("Recent template ==========", recentTemplate);
      return recentTemplate;
    } catch (err) {
      console.log(err);
    }
  }

  //createImaging
  createImaging = () => {
    try {
      let imahingTemplate = [];
      console.log("USG_BrainViweList-----------------------", this.USG_BrainViweReportList.length)
      if (this.USG_BrainViweReportList && this.USG_BrainViweReportList.length > 0) {
        imahingTemplate.push({
          mainHeader: 'USG Brain',
          header1: "USG_Brain",
          imagingDate: moment(new Date(this.USG_BrainViweReportList[0].imagingDate)).format('YYYY-MM-DD'),
          USG_Brain: this.USG_BrainViweReportList[0].USG_Brain
        });
      } else {
        imahingTemplate.push({
          mainHeader: 'USG Brain',
          header1: "USG_Brain",
          imagingDate: '-',
          USG_Brain: '-'
        });
      }

      if (this.USG_ATPViewReportList && this.USG_ATPViewReportList.length > 0) {
        imahingTemplate.push({
          mainHeader: 'USG ATP',
          header1: "USG_ATP",
          imagingDate: moment(new Date(this.USG_ATPViewReportList[0].imagingDate)).format('YYYY-MM-DD'),
          USG_ATP: this.USG_ATPViewReportList[0].USG_ATP
        });
      } else {
        imahingTemplate.push({
          mainHeader: 'USG ATP',
          header1: "USG_ATP",
          imagingDate: '-',
          USG_ATP: '-'
        });
      }


      console.log("Imaging Template =============", imahingTemplate);
      return imahingTemplate;

    } catch (err) {
      console.log(err);
    }
  }

  //store report locally
  createReportLocal = () => {
    try {
     
      let templateObj = {
        baby: this.babyDetails,
        template: {
          maternal_history: { id: 1, content: this.meternal_history_content_clone } ,
          perinatal_history: { id: 2, content: this.perinatel_history_content_clone },
          tratmentjourney: this.summaryList,
          medicinelist: this.medicineList,
          recentInvestigations: {
            'recentInvestigationHMGReportList' : this.recentInvestigationHMGReportList,
            'recentInvestigationBiochemistryReportList' : this.recentInvestigationBiochemistryReportList,
            'recentInvestigationSepsisScreenReportList' : this.recentInvestigationSepsisScreenReportList,
            'recentInvestigationSBiirubinReportList' : this.recentInvestigationSBiirubinReportList,
            'recentIvestigationoppReportList' : this.recentIvestigationoppReportList,
            'recentIvestigationMetabolic_WorkupReportList' : this.recentIvestigationMetabolic_WorkupReportList,
            'recentIvestigationOthersReportList' : this.recentIvestigationOthersReportList,
            'recentIvestigationNBSTReportList' : this.recentIvestigationNBSTReportList,
            'recentIvestigationUrineReportList' : this.recentIvestigationUrineReportList,
            'recentIvestigationHyPoglycemia_WorkupReportList' : this.recentIvestigationHyPoglycemia_WorkupReportList,
            'recentIvestigationHyInflamatoryMarkersReportList' : this.recentIvestigationHyInflamatoryMarkersReportList,
            'recentIvestigationLFTReportList' : this.recentIvestigationLFTReportList
          },
          imaging: {
            "USG_BrainViweReportList" : this.USG_BrainViweReportList,
            "USG_ATPViewReportList": this.USG_ATPViewReportList
          },
          rop: this.babyreport.rop.value,
          medicationadvice: {
            dischargetillkg: this.babyreport.dischargetillkg.value,
            dischargeafterkg: this.babyreport.dischargeafterkg.value
          },
          nutrition: this.babyreport.nutrition.value,
          followup: {
            followup_a_oae: this.babyreport.followup_a_oae.value,
            followup_b_bera: this.babyreport.followup_b_bera.value,
            followup_c_rop: this.babyreport.followup_c_rop.value,
            followup_d_nbst: this.babyreport.followup_d_nbst.value,
            followup_e: this.babyreport.followup_e.value,
            followup_f_mri: this.babyreport.followup_f_mri.value,
            followup_f_usgbrain: this.babyreport.followup_f_usgbrain.value,
            followup_g_surgicalfoll: this.babyreport.followup_g_surgicalfoll.value,
            followup_h_ent: this.babyreport.followup_h_ent.value,
            followup_h_neurology: this.babyreport.followup_h_neurology.value,
            followup_h_ortho: this.babyreport.followup_h_ortho.value,
            followup_RFT: this.babyreport.RFT.value,
            followup_LFT: this.babyreport.LFT.value,
            followup_Ferritin: this.babyreport.Ferritin.value,
            followup_Hmg: this.babyreport.Hmg.value
          }
        }
      }
      
      console.log("Template obj ============",templateObj);
      localStorage.setItem('report',JSON.stringify([templateObj]));
      console.log("convert string to json ======",JSON.parse(JSON.stringify([templateObj])));

    } catch (errCreateReportLocal) {
      console.log(errCreateReportLocal);
    }
  }
}
