import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DischargereportComponent } from './dischargereport.component';

describe('DischargereportComponent', () => {
  let component: DischargereportComponent;
  let fixture: ComponentFixture<DischargereportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DischargereportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DischargereportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
