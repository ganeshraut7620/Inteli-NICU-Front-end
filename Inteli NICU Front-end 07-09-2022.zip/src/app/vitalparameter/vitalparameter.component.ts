import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, RequiredValidator, FormBuilder } from '@angular/forms';
import swal from 'sweetalert2';
import { MainserviceService } from '../mainservice.service';
import * as moment from 'moment';
import { MatTabChangeEvent } from '@angular/material/tabs';

@Component({
  selector: 'app-vitalparameter',
  templateUrl: './vitalparameter.component.html',
  styleUrls: ['./vitalparameter.component.css']
})
export class VitalparameterComponent implements OnInit {

  viewFlag: boolean = false;
  vitalForm: FormGroup;
  range_1 = [];
  range_2 = [];
  range_3 = [];
  range_4 = [];
  weight_range = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0,
    1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0,
    2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0,
    3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7, 3.8, 3.9, 4.0,
    4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7, 4.8, 4.9, 5.0]
  viewVitalparameter = [];
  BabyList = [];
  nurseList: any;
  babyid: any;
  pagedischarge: number = 1;
  pageadmit: number = 1;
  constructor(private mainserviceService: MainserviceService) { }

  ngOnInit(): void {

    this.getbabydetails(1, "admitted")
    this.getNursemaster();
    this.range_1 = this.genrateIndexes(50, 100);
    this.range_2 = this.genrateIndexes(0, 200);
    this.range_3 = this.genrateIndexes(0, 10);
    this.range_4 = this.genrateIndexes(0, 200);
    console.log("sp02 range => ", this.range_1, this.range_2, this.range_3);
  }

  createVital() {
    try {
      this.viewFlag = true;
      // spo2, PR, HR, Weight, RR, NIBP( sys/ dia)
      this.vitalForm = new FormGroup({
        babyid: new FormControl(null, [Validators.required]),
        nurseid: new FormControl(null, [Validators.required]),
        spo2: new FormControl(0),
        PR: new FormControl(0),
        HR: new FormControl(0),
        Weight: new FormControl(0),
        RR: new FormControl(0),
        sys: new FormControl(0),
        dia: new FormControl(0),
        PI: new FormControl(0),

      });
    } catch (errVital) {
      console.log("Add Vital Parameter", errVital);
    }
  }


  get registerFormControl() {
    return this.vitalForm.controls;
  }

  resetview = () => {
    try {
      this.viewFlag = false;
    } catch (err) {

    }
  }

  onSubmit = () => {
    try {
      // this.vitalForm.value.createdtime = new Date().toISOString();
      // this.vitalForm.value.updatedtime = new Date().toISOString();
      var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
      console.log("session storage value => ", userData);


      let obj = {
        spotwovalue: this.vitalForm.value.spo2 ? Number(this.vitalForm.value.spo2) : 0,
        pulseratevalue: this.vitalForm.value.PR ? Number(this.vitalForm.value.PR) : 0,
        pivalue: this.vitalForm.value.PI ? Number(this.vitalForm.value.PI) : 0,
        HRvalue: this.vitalForm.value.HR ? Number(this.vitalForm.value.HR) : 0,
        Weightvalue: this.vitalForm.value.Weight ? Number(this.vitalForm.value.Weight) : 0,
        RRvalue: this.vitalForm.value.RR ? Number(this.vitalForm.value.RR) : 0,
        sysvalue: this.vitalForm.value.sys ? Number(this.vitalForm.value.sys) : 0,
        diavalue: this.vitalForm.value.dia ? Number(this.vitalForm.value.dia) : 0,
        // babyid : this.vitalForm.value.babyid? Number(this.vitalForm.value.babyid):0 ,
        babyid: this.getBabyid(this.vitalForm.value.babyid),
        machineid: this.getMachieid(this.vitalForm.value.babyid),
        clientid: this.getClientID(this.vitalForm.value.babyid),
        nurseid: this.getnurseid(this.vitalForm.value.nurseid),
        isactive: true,
        mode: 2

      }
      console.log("form", this.vitalForm.value, "obj =>", obj);

      //  this.viewVitalparameter.push(this.vitalForm.value);
      // console.log("vital parameter list => ", this.viewVitalparameter);

      this.mainserviceService.createVitalParameter(obj).subscribe((data) => {
        console.log("response => ", data);
        if (data) {
          this.getbabydetails(1, "admitted")
          swal.fire(
            'Good job!',
            'Vital Parameter Create Succsefully!',
            'success'
          );
        } else {
          swal.fire(
            'Error!',
            'Something Wrong!',
            'error'
          );
        }
      }, (err) => {
        swal.fire(
          'Error!',
          'Something Wrong!',
          'error'
        );
      });

      this.viewFlag = false;

    } catch (err) {

    }
  }

  getnurseid(nursename) {
    let x = this.nurseList.filter((x) => {
      return x.usermastername == nursename;
    })
    return x[0].usermasterid;
  }

  getBabyid(babyname) {
    let x = this.BabyList.filter((x) => {
      return x.babyname == babyname;
    })
    return x[0].babyid;
  }

  getClientID(babyname) {
    let x = this.BabyList.filter((x) => {
      return x.babyname == babyname;
    })
    return x[0].clientid;
  }

  getMachieid(babyname) {
    let x = this.BabyList.filter((x) => {
      return x.babyname == babyname;
    })
    return x[0].machineid;
  }

  genrateIndexes = (start, end) => {
    try {
      let arr = [];
      for (let i = start; i <= end; i++) {
        arr.push(i);
      }

      return arr;

    } catch (err) {

    }
  }

  getVital(babyid, mode) {
    try {
      this.viewVitalparameter =[];
      this.mainserviceService.getVitalParameter({
        mode: 2,
        babyid: babyid
      }).subscribe((res) => {
        console.log("res ------------",res);
        if (res) {
          this.viewVitalparameter = res.data;
        }
      }, (err) => {
        console.log(err.error);
      });
    } catch (errGetVital) {
      //catch error
      console.log("err===========",errGetVital);
    }

  }



  getNursemaster() {
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    let dummy_data = {
      "usercategoryid": 9,
      "usersubcategoryid": null,
      "clientid": userData.clientid,
      "page": 1,
      "pagesize": 100000
    }

    this.mainserviceService.getUser(dummy_data).subscribe((res) => {
      console.log("Nurse Master Data => ", res.data);
      this.nurseList = res.data;
    }, (err) => {
      console.log(err.error);
    });
  }

  getbabydetails(pageinc, status) {
    try {
      this.mainserviceService.getbabyid({
        "babyno": null,
        "babyname": null,
        "machineid": null,
        "clientid": JSON.parse(sessionStorage.getItem('userInfo1')).clientid,
        "babystatus": status,
        "isactive": true,
        "page": pageinc,
        "pagesize": 5
      }).subscribe((res) => {
        console.log("Baby Details => ", res.data);
        this.BabyList = res.data;
      }, (err) => {
        console.log(err.error);

      });

    } catch (err) {
      console.log(err);
    }
  }

  onChange(event: MatTabChangeEvent) {
    try {
      const tab = event.tab.textLabel;
      console.log(tab);

      if (tab === "Admited") {
        this.getbabydetails(1, "admitted");
      } else if (tab == "Discharged") {
        this.getbabydetails(1, "discharge");

      }
    } catch (err) {
      console.log(err)
    }
  }

  selectedBabys = (baby) => {
    console.log("BABY DETAILS =================", baby);
    this.babyid = baby.babyid;
    //this.resetDoctorForm();
    this.getVital(baby.babyid, null);

  }
  admitprevious() {
    if (this.pageadmit >= 2) {
      this.pageadmit = this.pageadmit - 1;
      console.log("decriment => ", this.pageadmit)
      // this.getbabydetails(this.page);
      this.getbabydetails(this.pageadmit, "admitted");
    }
  }
  admitnext() {
    this.pageadmit = this.pageadmit + 1;
    console.log("Incriment => ", this.pageadmit)
    // this.getbabydetails(this.page);
    this.getbabydetails(this.pageadmit, "admitted");

  }

  dischargeprevious() {
    if (this.pagedischarge >= 2) {
      this.pagedischarge = this.pagedischarge - 1;
      console.log("decriment => ", this.pagedischarge)
      // this.getbabydetails(this.page);
      this.getbabydetails(this.pagedischarge, "discharge");
    }
  }
  dischargenext() {
    this.pagedischarge = this.pagedischarge + 1;
    console.log("Incriment => ", this.pagedischarge)
    // this.getbabydetails(this.page);
    this.getbabydetails(this.pagedischarge, "discharge");

  }


}
