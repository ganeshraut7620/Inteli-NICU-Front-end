import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VitalparameterComponent } from './vitalparameter.component';

describe('VitalparameterComponent', () => {
  let component: VitalparameterComponent;
  let fixture: ComponentFixture<VitalparameterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VitalparameterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VitalparameterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
