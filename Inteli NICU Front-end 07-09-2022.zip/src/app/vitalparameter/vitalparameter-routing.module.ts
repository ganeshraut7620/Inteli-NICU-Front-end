import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {VitalparameterComponent } from './vitalparameter.component';
const routes: Routes = [
  {
    path:'',component: VitalparameterComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class VitalparameterRoutingModule { }
