import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { NerseInterventionRoutingModule } from './nerse-intervention-routing.module';
import { NerseInterventionComponent } from './nerse-intervention.component';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatTabsModule} from '@angular/material/tabs';

@NgModule({
  declarations: [NerseInterventionComponent],
  imports: [
    CommonModule,
    MatExpansionModule,
    MatTabsModule,
    FormsModule,
    ReactiveFormsModule ,
    NerseInterventionRoutingModule
  ]
})
export class NerseInterventionModule { }
