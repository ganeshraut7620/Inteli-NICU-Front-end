import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NerseInterventionComponent } from './nerse-intervention.component';

describe('NerseInterventionComponent', () => {
  let component: NerseInterventionComponent;
  let fixture: ComponentFixture<NerseInterventionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NerseInterventionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NerseInterventionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
