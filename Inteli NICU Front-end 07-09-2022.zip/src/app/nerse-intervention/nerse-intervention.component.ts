import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, RequiredValidator, FormBuilder } from '@angular/forms';
import swal from 'sweetalert2';
import { MainserviceService } from '../mainservice.service';
import * as moment from 'moment';
import { MatTabChangeEvent } from '@angular/material/tabs';

@Component({
  selector: 'app-nerse-intervention',
  templateUrl: './nerse-intervention.component.html',
  styleUrls: ['./nerse-intervention.component.css']
})
export class NerseInterventionComponent implements OnInit {

  viewFlag: boolean = false;
  nurseForm: FormGroup;
  nurseIntervention = [];
  date: string;
  time: string;
  nurseList: any;
  BabyList = [];
  babyid: any;
  pagedischarge: number = 1;
  pageadmit: number = 1;

  constructor(private mainserviceService: MainserviceService) {
    this.date = moment().format('L');
    this.time = moment().format('LTS');
    console.log("Client json object ==========", JSON.parse(sessionStorage.getItem('userInfo1')));
  }

  resetDateandtime() {
    this.date = moment().format('L');
    this.time = moment().format('LTS');
  }

  ngOnInit(): void {
    this.getbabydetails(1, 'admitted');
    this.getNursemaster();
  }

  createNurseIntervention() {
    try {
      this.viewFlag = true;

      this.nurseForm = new FormGroup({
        nurseid: new FormControl(null, [Validators.required]),
        babyid: new FormControl(null, [Validators.required]),
        date: new FormControl(null, [Validators.required]),
        time: new FormControl(null, [Validators.required]),
        nurse_intervention: new FormControl(null, [Validators.required])
      });
    } catch (errVital) {
      console.log("Add Vital Parameter", errVital);
    }
  }

  get registerFormControl() {
    return this.nurseForm.controls;
  }

  resetview = () => {
    try {
      this.viewFlag = false;
    } catch (err) {

    }
  }

  onSubmit = () => {
    try {
      console.log("Nurse Intervention ==============================", {
        babyid: this.nurseForm.value.babyid,
        nurseid: this.nurseForm.value.nurseid,
        clientid: JSON.parse(sessionStorage.getItem('userInfo1')).usermasterid,
        date: moment().format(),
        time: moment().format(),
        nurse_intervention: this.nurseForm.value.nurse_intervention
      });


      this.mainserviceService.createNurseIntervention({
        babyid: this.nurseForm.value.babyid,
        nurseid: this.nurseForm.value.nurseid,
        clientid: JSON.parse(sessionStorage.getItem('userInfo1')).usermasterid,
        date: moment().format(),
        time: moment().format(),
        nurse_intervention: this.nurseForm.value.nurse_intervention
      }).subscribe((data) => {
        if (data) {
          this.getbabydetails(1, 'admitted')
          swal.fire(
            'Good job!',
            'Nurse Intervention Create Succsefully!',
            'success'
          );

        } else {
          swal.fire(
            'Error!',
            'Wrong Input put !',
            'error'
          );
        }
      }, (err) => {
        swal.fire(
          'Error!',
          'Something Wrong!',
          'error'
        );
      });

      this.viewFlag = false;

    } catch (err) {
      swal.fire(
        'Error!',
        'Something Wrong!',
        'error'
      );
    }
  }


  getNurseIntervention(babyid, nurseid) {
    try {
      this.nurseIntervention = [];
      this.mainserviceService.getNureseIntervention({
        "babyid": babyid,
        "nurseid": nurseid
      }).subscribe((res) => {
        if (res) {
          this.nurseIntervention = res.data;
          console.log("Get Nurse Intervention =>", res.data);
        }
      }, (err) => {
        console.log(err);
      });
    } catch (err) {
      console.log("err ========", err);
    }
  }

  getbabydetails(pageinc, status) {
    try {

      this.mainserviceService.getbabyid({
        "babyno": null,
        "babyname": null,
        "machineid": null,
        "clientid": JSON.parse(sessionStorage.getItem('userInfo1')).clientid,
        "babystatus": status,
        "isactive": true,
        "page": pageinc,
        "pagesize": 5
      }).subscribe((res) => {
        console.log("Baby Details => ", res.data);
        this.BabyList = res.data;
      }, (err) => {
        console.log(err.error);

      });

    } catch (err) {
      console.log(err);
    }
  }

  onChange(event: MatTabChangeEvent) {
    try {
      const tab = event.tab.textLabel;
      console.log(tab);

      if (tab === "Admited") {
        this.getbabydetails(1, "admitted");
      } else if (tab == "Discharged") {
        this.getbabydetails(1, "discharge");

      }
    } catch (err) {
      console.log(err)
    }
  }

  selectedBabys = (baby) => {
    console.log("BABY DETAILS =================", baby);
    this.babyid = baby.babyid;
    //this.resetDoctorForm();
    this.getNurseIntervention(baby.babyname, null);

  }

  getNursemaster() {
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    let dummy_data = {
      "usercategoryid": 9,
      "usersubcategoryid": null,
      "clientid": userData.clientid,
      "page": 1,
      "pagesize": 100000
    }

    this.mainserviceService.getUser(dummy_data).subscribe((res) => {
      console.log("Nurse Master Data => ", res.data);
      this.nurseList = res.data;
    }, (err) => {
      console.log(err.error);
    });
  }

  admitprevious() {
    if (this.pageadmit >= 2) {
      this.pageadmit = this.pageadmit - 1;
      console.log("decriment => ", this.pageadmit)
      // this.getbabydetails(this.page);
      this.getbabydetails(this.pageadmit, "admitted");
    }
  }

  admitnext() {
    this.pageadmit = this.pageadmit + 1;
    console.log("Incriment => ", this.pageadmit)
    // this.getbabydetails(this.page);
    this.getbabydetails(this.pageadmit, "admitted");

  }

  dischargeprevious() {
    if (this.pagedischarge >= 2) {
      this.pagedischarge = this.pagedischarge - 1;
      console.log("decriment => ", this.pagedischarge)
      // this.getbabydetails(this.page);
      this.getbabydetails(this.pagedischarge, "discharge");
    }
  }
  dischargenext() {
    this.pagedischarge = this.pagedischarge + 1;
    console.log("Incriment => ", this.pagedischarge)
    // this.getbabydetails(this.page);
    this.getbabydetails(this.pagedischarge, "discharge");

  }


}
