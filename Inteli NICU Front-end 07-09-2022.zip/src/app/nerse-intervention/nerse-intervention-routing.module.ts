import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NerseInterventionComponent } from './nerse-intervention.component';

const routes: Routes = [
  {
    path:'',component: NerseInterventionComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class NerseInterventionRoutingModule { }
