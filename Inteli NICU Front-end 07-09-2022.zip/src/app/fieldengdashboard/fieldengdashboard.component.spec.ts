import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FieldengdashboardComponent } from './fieldengdashboard.component';

describe('FieldengdashboardComponent', () => {
  let component: FieldengdashboardComponent;
  let fixture: ComponentFixture<FieldengdashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FieldengdashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FieldengdashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
