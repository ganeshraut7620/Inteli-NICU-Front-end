import { Component, OnInit } from '@angular/core';
import { MainserviceService } from '../mainservice.service';
@Component({
  selector: 'app-fieldengdashboard',
  templateUrl: './fieldengdashboard.component.html',
  styleUrls: ['./fieldengdashboard.component.css']
})
export class FieldengdashboardComponent implements OnInit {

  msg: string;
  totalsite:any = '';
  installsites:any = '';
  pendingsites:any = '';
  ready:any = '';

  totalmachines:any = '';
  installmachines:any =  '';
  activemachine:any = '';
  inactivemachines:any = '';
  totalcomplaint: any = '';
  opencomplaint: any = '';
  closecomplaint: any = '';
  totalamc: any = '';
  activeamc: any = '';
  inactiveamc_data: any = '';
  expire: any;
  totalclient: any;

  constructor(public mainserviceService:MainserviceService) {
    if(sessionStorage.getItem('flag') == "true"){
      window.location.reload(true);
      sessionStorage.setItem('flag','false');
    }
    this.getfieldengdashboardanalytics();
   }

  ngOnInit(): void {
  }

  getfieldengdashboardanalytics(){
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
     console.log( "session storage value => ",userData);
    let data = {"fieldengineerid": userData.usermasterid}

    this.mainserviceService.getfieldengdashboard(data).subscribe((res) => {
      console.log("field eng data  =>",res);

      if(res.status_code == 's_407'){
       console.log("data => ",res.data);
       this.totalsite = res.data[0].siteandmachinedetails.totalsites;
       this.pendingsites =res.data[0].siteandmachinedetails.pendingsites;
       this.installsites =res.data[0].siteandmachinedetails.installedsites;
       this.ready = res.data[0].siteandmachinedetails.readytoinstallsites;

       this.totalmachines = this.totalsite;
       this.installmachines = this.installsites;
       this.activemachine = this.installsites;
       this.inactivemachines = this.pendingsites + this.ready;

       this.totalcomplaint = res.data[0].complaintdetails[0].totalcomplaint;
       this.opencomplaint = res.data[0].complaintdetails[0].opencomplaint;
       this.closecomplaint = res.data[0].complaintdetails[0].closecomplaint;

       this.totalamc = res.data[0].siteandmachinedetails.totalamc;
       this.activeamc = res.data[0].siteandmachinedetails.activeamc;
       this.expire = res.data[0].siteandmachinedetails.expeiredamc;
   

      }else if(res.status_code == 's_1015'){

      }else if(res.status_code == 's_408'){
        this.msg = "No Record Found";
      }


      }, (err) => {
            console.log(err.error);

    });
  }

}
