import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FieldengdashboardComponent } from './fieldengdashboard.component';

const routes: Routes = [{
  path:'',component:FieldengdashboardComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FieldengdashboardRoutingModule { }
