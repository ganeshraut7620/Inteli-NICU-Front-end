import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FieldengdashboardRoutingModule } from './fieldengdashboard-routing.module';
import { FieldengdashboardComponent } from './fieldengdashboard.component';


@NgModule({
  declarations: [FieldengdashboardComponent],
  imports: [
    CommonModule,
    FieldengdashboardRoutingModule
  ]
})
export class FieldengdashboardModule { }
