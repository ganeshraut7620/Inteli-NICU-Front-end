import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BabymedicinereportComponent } from './babymedicinereport.component';

const routes: Routes = [
  {path:'',component:BabymedicinereportComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class BabymedicinereportRoutingModule { }
