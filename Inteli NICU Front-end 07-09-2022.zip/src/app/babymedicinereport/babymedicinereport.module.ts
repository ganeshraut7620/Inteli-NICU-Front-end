import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BabymedicinereportRoutingModule } from './babymedicinereport-routing.module';
import { BabymedicinereportComponent } from './babymedicinereport.component';


@NgModule({
  declarations: [BabymedicinereportComponent],
  imports: [
    CommonModule,
    BabymedicinereportRoutingModule
  ]
})
export class BabymedicinereportModule { }
