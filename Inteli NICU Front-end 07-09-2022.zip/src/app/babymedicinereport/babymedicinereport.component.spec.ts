import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BabymedicinereportComponent } from './babymedicinereport.component';

describe('BabymedicinereportComponent', () => {
  let component: BabymedicinereportComponent;
  let fixture: ComponentFixture<BabymedicinereportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BabymedicinereportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BabymedicinereportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
