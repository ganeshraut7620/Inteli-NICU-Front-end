import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-babymedicinereport',
  templateUrl: './babymedicinereport.component.html',
  styleUrls: ['./babymedicinereport.component.css']
})
export class BabymedicinereportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
