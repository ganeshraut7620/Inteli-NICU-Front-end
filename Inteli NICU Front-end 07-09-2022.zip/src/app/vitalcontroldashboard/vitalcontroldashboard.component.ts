import { Component, OnInit } from '@angular/core';
import { MainserviceService } from '../mainservice.service';
@Component({
  selector: 'app-vitalcontroldashboard',
  templateUrl: './vitalcontroldashboard.component.html',
  styleUrls: ['./vitalcontroldashboard.component.css']
})

export class VitalcontroldashboardComponent implements OnInit {

  msg: string;
  totalsite:any = '';
  installsites:any = '';
  pendingsites:any = '';
  ready:any = '';

  totalmachines:any = '';
  installmachines:any =  '';
  activemachine:any = '';
  inactivemachines:any = '';
  totalcomplaint: any = '';
  opencomplaint: any = '';
  closecomplaint: any = '';
  totalamc: any = '';
  activeamc: any = '';
  inactiveamc_data: any = '';
  expire: any = '';
  totalclient: any = '';
  totalalram:any = '';
  inactivealarm:any = '';
  activealarm:any = '';
  totalfeedalarm:any = '';
  totallocationadmin: any;
  totalcontrolroommanager: any;
  totalnurse: any='-';
  totaldoctor: any = '-';


  constructor(public mainserviceService:MainserviceService) { 
    if(sessionStorage.getItem('flag') == "true"){
      window.location.reload(true);
      sessionStorage.setItem('flag','false');
    }
    this.getcontroldashboarddata();
  }

  ngOnInit(): void {
  }

  getcontroldashboarddata(){
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    console.log( "session storage value => ",userData);
   let data = {"clientid": userData.submasterid}

   this.mainserviceService.getvitaldashboard(data).subscribe((res) => {
     console.log("client data  =>",res);

     if(res.status_code == 's_407'){

      console.log("data => ",res.data);
      console.log("Alarm Data => ",res.data[0].alarmdetails.totalalarm)

      this.totalmachines = (res.data[0].machinedetails.totalmachine == null && res.data[0].machinedetails.totalmachine == undefined)? 0 : res.data[0].machinedetails.totalmachine;
      this.activemachine = (res.data[0].machinedetails.activemachine ==null && res.data[0].machinedetails.activemachine == undefined)? 0:res.data[0].machinedetails.activemachine;
      this.inactivemachines = (res.data[0].machinedetails.inactivemachine ==null && res.data[0].machinedetails.inactivemachine ==undefined)? 0: res.data[0].machinedetails.inactivemachine;
      this.installmachines = (this.activemachine + this.inactivemachines ==null && this.activemachine + this.inactivemachines ==undefined)? 0:this.activemachine + this.inactivemachines;
    

      this.totalcomplaint = (res.data[0].complaintdetails[0].totalcomplaint ==null && res.data[0].complaintdetails[0].totalcomplaint == undefined)? 0: res.data[0].complaintdetails[0].totalcomplaint;
      this.opencomplaint = (res.data[0].complaintdetails[0].opencomplaint == null && res.data[0].complaintdetails[0].opencomplaint==undefined)? 0:res.data[0].complaintdetails[0].opencomplaint;
      this.closecomplaint =  (res.data[0].complaintdetails[0].closecomplaint == null && res.data[0].complaintdetails[0].closecomplaint==undefined)? 0: res.data[0].complaintdetails[0].closecomplaint;  
      this.totalamc = (res.data[0].amcdetails.totalamc == null && res.data[0].amcdetails.totalamc==undefined)? 0: res.data[0].amcdetails.totalamc;
      this.activeamc = (res.data[0].amcdetails.activeamc == null && res.data[0].amcdetails.activeamc==undefined)? 0: res.data[0].amcdetails.activeamc;
      this.expire = (res.data[0].amcdetails.expeiredamc == null && res.data[0].amcdetails.expeiredamc==undefined)? 0: res.data[0].amcdetails.expeiredamc;
      // this.totallocationadmin = (res.data[0].nurseanddoctor[0].totalcount == null && res.data[0].nurseanddoctor[0].totalcount == undefined)? 0 : res.data[0].nurseanddoctor[0].totalcount;
      // this.totalcontrolroommanager = (res.data[0].nurseanddoctor[1].totalcount == null && res.data[0].nurseanddoctor[1].totalcount == undefined)? 0 : res.data[0].nurseanddoctor[1].totalcount;
      // this.totaldoctor = (res.data[0].nurseanddoctor[2].totalcount == null && res.data[0].nurseanddoctor[2].totalcount == undefined)? 0 : res.data[0].nurseanddoctor[2].totalcount;
      // this.totalnurse =(res.data[0].nurseanddoctor[3].totalcount == null && res.data[0].nurseanddoctor[3].totalcount == undefined)? 0 : res.data[0].nurseanddoctor[3].totalcount;

      this.totalalram = (res.data[0].alarmdetails.totalalarm == null && res.data[0].alarmdetails.totalalarm == undefined)? 0 : res.data[0].alarmdetails.totalalarm;
      this.activealarm = (res.data[0].alarmdetails.activealarm == null && res.data[0].alarmdetails.activealarm==undefined)? 0: res.data[0].alarmdetails.activealarm;
      this.inactivealarm = (res.data[0].alarmdetails.inactivealarm == null && res.data[0].alarmdetails.inactivealarm == undefined)? 0: res.data[0].alarmdetails.inactivealarm;
      this.totalfeedalarm = (res.data[0].alarmdetails.totalfeedlog == null && res.data[0].alarmdetails.totalfeedlog == undefined)? 0: res.data[0].alarmdetails.totalfeedlog;

      
     }else if(res.status_code == 's_1015'){

     }else if(res.status_code == 's_408'){
       this.msg = "No Record Found";
     }


     }, (err) => {
           console.log(err.error);

   });

  }
}
