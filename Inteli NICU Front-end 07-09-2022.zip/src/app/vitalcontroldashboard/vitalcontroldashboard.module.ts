import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { VitalcontroldashboardRoutingModule } from './vitalcontroldashboard-routing.module';
import { VitalcontroldashboardComponent } from './vitalcontroldashboard.component';


@NgModule({
  declarations: [VitalcontroldashboardComponent],
  imports: [
    CommonModule,
    VitalcontroldashboardRoutingModule
  ]
})
export class VitalcontroldashboardModule { }
