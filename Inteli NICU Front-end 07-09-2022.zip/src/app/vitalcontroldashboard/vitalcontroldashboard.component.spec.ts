import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VitalcontroldashboardComponent } from './vitalcontroldashboard.component';

describe('VitalcontroldashboardComponent', () => {
  let component: VitalcontroldashboardComponent;
  let fixture: ComponentFixture<VitalcontroldashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VitalcontroldashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VitalcontroldashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
