import { Component, OnInit ,NgModule} from '@angular/core';
import { FormGroup, FormArray,FormControl, Validators, RequiredValidator,FormBuilder  } from '@angular/forms';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CustomvalidationService } from '../services/customvalidation.service';
import { NgbPanelChangeEvent } from '@ng-bootstrap/ng-bootstrap';
import {FlatTreeControl} from '@angular/cdk/tree';
import { NgxSpinnerService } from "ngx-spinner";

import {MatTreeFlatDataSource, MatTreeFlattener} from '@angular/material/tree';

import { CollapseModule, WavesModule } from 'angular-bootstrap-md'
import swal from 'sweetalert2';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
interface FoodNode {
  name: string;
  children?: FoodNode[];
}

const TREE_DATA: FoodNode[] = [
  {
    name: 'Fruit',
    children: [
      {name: 'Apple'}
    ]
  }
];

/** Flat node with expandable and level information */
interface ExampleFlatNode {
  expandable: boolean;
  name: string;
  level: number;
}

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.css']
})
export class NotificationComponent implements OnInit {

  machines:any = ['Machine-12','Machine-13','Machine-14'];
  alaram:any = ['acode123','acode312','acode1245'];
 // client: ['Client123', 'Cient124', 'Client125', 'Client126', 'Client127'];
  //medium:any = ['Docter','Nurse']
  ntby:any = ['Sms','Email','Both'];
  sitecodes = ['site123','sit1234','sit2323','site1123'];
  nurses = ['Anjju','Swati','Shrutika','Madhavi','Prachi'];
  doctors = ['Bagesh','Ganesh','Ankit','Rushikesh'];

  selectedntfmethod:string = 'sms';
  isSwitchedOn = false;
  //machineId:String = "Select Machine Name"
  show1:boolean = false;
  show2:boolean = false;
  show3:boolean = false;


  private _transformer = (node: FoodNode, level: number) => {
    return {
      expandable: !!node.children && node.children.length > 0,
      name: node.name,
      level: level,
    };
  }

  treeControl = new FlatTreeControl<ExampleFlatNode>(
      node => node.level, node => node.expandable);

  treeFlattener = new MatTreeFlattener(
      this._transformer, node => node.level, node => node.expandable, node => node.children);

  dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);

  public Nurse: any[] = [
    {
    id: 1,
    nursename:'',
  }];

  public Doctors: any[] = [
    {
      id:1,
      doctorname:''
    }
  ]

  public sms: any[] = [
    {
    id: 1,
    contactno: '',
  }];

  addSms() {
    this.sms.push({
      id: this.sms.length + 1,
      contactno: ''
    });
  }

  public email: any[] = [
    {
    id: 1,
    emailid: '',
  }];

  public sms2: any[] = [
    {
    id: 1,
    contactno: '',
  }];

  public email2: any[] = [
    {
    id: 1,
    emailid: '',
  }];

  addEmail() {
    this.email.push({
      id: this.email.length + 1,
      emailid: ''
    });
  }

  addSms2() {
    this.sms2.push({
      id: this.sms2.length + 1,
      contactno: ''
    });
  }

  addEmail2() {
    this.email2.push({
      id: this.email2.length + 1,
      emailid: ''
    });
  }



  ntfform: ntf= new ntf();
  notificationtriggerby = "sms";

  constructor(private spinner: NgxSpinnerService,private modalService: NgbModal,private fb: FormBuilder,
    private customValidator: CustomvalidationService) {
      this.dataSource.data = TREE_DATA;
      this.spinner.show();

      setTimeout(() => {
        /** spinner ends after 5 seconds */
        this.spinner.hide();
      }, 1000);
     }

    hasChild = (_: number, node: ExampleFlatNode) => node.expandable;

    open1(content1) {
      this.modalService.open(content1, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
        //this.closeResult = `Closed with: ${result}`;
      }, (reason) => {
        //this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      });
    }
    show: boolean = false;
    registerForm: FormGroup;
    submitted = false;
    editnursemaster: FormGroup;

  ngOnInit(): void {
    /*this.registerForm = this.fb.group({
      alaramname:['',Validators.required],
      notification:['',Validators.required],
      machineId:['',Validators.required],
      email: ['', [Validators.required, Validators.email]],
      contactno1: ['', [Validators.required]],


    },
      {
        validator: this.customValidator.MatchPassword('password', 'confirmPassword'),
      }
    );*/
  }


  /*onSave() {
    console.log('register');
  }
  get registerFormControl() {
    return this.registerForm.controls;
  }*/

  openLg(content1) {
    this.modalService.open(content1, { size: 'lg' });
  }

  sitecodechange(){};



  addNurse() {
    this.Nurse.push({
      id: this.Nurse.length + 1,
      nursename: ''
    });
  }

  addDoctor() {
    this.Doctors.push({
      id: this.Doctors.length + 1,
      doctorname: ''
    });
  }


  logValue(flag) {
    console.log(flag);
    console.log(this.Nurse,this.Doctors,this.ntfform);

    let alaramdata = {
      "sitecode":this.ntfform.sitecode,
      "notificationtriggerby":this.ntfform.notificationtriggerby,
      "alarmcode":this.ntfform.alarmcode,
      "nursedetails": this.Nurse,
      "doctordetails":this.Doctors
    }

    /*swal.fire(
      'Good job!',
      'Notification Add Succesfully',
      'success'
    )*/

    console.log(alaramdata);
    //this.closeBtnClick();
  }

  ntfSubmit(){

  }

  openModal(targetModal) {
    this.modalService.open(targetModal, {
        centered: true,
        backdrop: 'static',
        size: 'lg'
    })
    //console.log(nursemaster);
    //this.editnursemaster_details = nursemaster;
  }

  ntf(){
    console.log("Method=>",this.ntfform.notificationtriggerby);
    if(this.ntfform.notificationtriggerby == "Sms"){
      this.show1 = true;
    }else{
      this.show1 = false;

    }
    if(this.ntfform.notificationtriggerby == "Email"){
      this.show2 = true;
    }else{
      this.show2 = false;
    }

    if(this.ntfform.notificationtriggerby == "Both"){
      this.show3 = true;
    }else{
      this.show3 = false;
    }

  }

  /*onSubmit() {
    this.submitted = true;
    if (this.registerForm.valid) {
      //alert('Form Submitted succesfully!!!\n Check the values in browser console.');
      swal.fire(
        'Good job!',
        'Notification Add Succesfully',
        'success'
      )
      console.table(this.registerForm.value);
      this.closeBtnClick();
    }

  }*/


  changemachine($event){}
  changealaramname($event){}
  changealnotification($event){}
  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;

    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }

    if (event.keyCode === 32 ) {
      return false;
    }

  }
  machineid(){
    console.log('change the machine id');
  }
  closeBtnClick() {
    this.modalService.dismissAll()
    this.ngOnInit();
  }


}


class ntf {
  sitecode:String;
  warmerid:String;
  notificationtriggerby:String;
  alarmcode:String;

}


/*




*/
