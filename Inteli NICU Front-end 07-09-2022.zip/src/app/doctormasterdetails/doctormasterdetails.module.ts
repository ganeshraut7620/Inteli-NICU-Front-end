import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DoctormasterdetailsRoutingModule } from './doctormasterdetails-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    DoctormasterdetailsRoutingModule
  ]
})
export class DoctormasterdetailsModule { }
