import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { NgxGaugeModule } from 'ngx-gauge';
import { IndusialwarmerstatusRoutingModule } from './indusialwarmerstatus-routing.module';
import { IndusialwarmerstatusComponent } from './indusialwarmerstatus.component';


@NgModule({
  declarations: [IndusialwarmerstatusComponent],
  imports: [
    CommonModule,
    BrowserModule,
    NgxGaugeModule,
    IndusialwarmerstatusRoutingModule
  ]
})
export class IndusialwarmerstatusModule { }
