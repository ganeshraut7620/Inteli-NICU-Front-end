import { Component, OnInit } from '@angular/core';
import { TrendsComponent } from '../trends/trends.component';

@Component({
  selector: 'app-indusialwarmerstatus',
  templateUrl: './indusialwarmerstatus.component.html',
  styleUrls: ['./indusialwarmerstatus.component.css']
})
export class IndusialwarmerstatusComponent implements OnInit {

  dummyCoponent = TrendsComponent;

  gaugeType = "semi";
  gaugeValue = 28.3;
  gaugeLabel = "Spo2";
  gaugeAppendText = "%";


  gaugeType1 = "semi";
  gaugeValue1 = 22.22;
  gaugeLabel1 = "Pulse Rate";

  gaugeType2 = "semi";
  gaugeValue2 = 2;
  gaugeLabel2 = "Weight";


  constructor() { }

  ngOnInit(): void {
  }

}
