import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { IndusialwarmerstatusComponent } from './indusialwarmerstatus.component';

const routes: Routes = [
  { path: '' , component: IndusialwarmerstatusComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]


})
export class IndusialwarmerstatusRoutingModule { }
