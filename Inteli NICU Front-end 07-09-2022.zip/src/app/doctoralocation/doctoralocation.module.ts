import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { DoctoralocationRoutingModule } from './doctoralocation-routing.module';
import { DoctoralocationComponent } from './doctoralocation.component';


@NgModule({
  declarations: [DoctoralocationComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DoctoralocationRoutingModule
  ]
})
export class DoctoralocationModule { }
