import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DoctoralocationComponent } from './doctoralocation.component';

const routes: Routes = [
  {
    path:'', component:DoctoralocationComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DoctoralocationRoutingModule { }
