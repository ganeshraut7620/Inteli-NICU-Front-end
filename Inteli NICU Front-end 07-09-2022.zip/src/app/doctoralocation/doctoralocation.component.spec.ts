import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DoctoralocationComponent } from './doctoralocation.component';

describe('DoctoralocationComponent', () => {
  let component: DoctoralocationComponent;
  let fixture: ComponentFixture<DoctoralocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DoctoralocationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DoctoralocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
