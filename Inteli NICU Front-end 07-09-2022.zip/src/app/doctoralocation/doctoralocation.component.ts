import { Component, OnInit } from '@angular/core';
import swal from 'sweetalert2';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, Validators, RequiredValidator,FormBuilder  } from '@angular/forms';

import { MainserviceService } from '../mainservice.service';

@Component({
  selector: 'app-doctoralocation',
  templateUrl: './doctoralocation.component.html',
  styleUrls: ['./doctoralocation.component.css']
})
export class DoctoralocationComponent implements OnInit {

  tempsiteList:any;
  sitedetails:any;
  doctorList:any
  nurseList:any;
  doctor_res:any;
  nurse_res:any;

  constructor(private  mainserviceService: MainserviceService,private modalService: NgbModal,private fb: FormBuilder) {
    this.getSiteDetails();
    this.getDutyDoctor();
    this.getNursemaster();
  }

  ngOnInit(): void {
  }

  openModal(targetModal,site) {
    this.modalService.open(targetModal, {
        centered: true,
        backdrop: 'static',
        size: 'lg'
    })
    console.log("site updated Data => ",site);
    this.sitedetails = site;
    // this.editdutyroaster_details = dutyroaster;
  }

  getSiteDetails(){

    // var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    // console.log( "session storage value => ",userData);

    //   let dummy_data ={

    //     "usermasterid": userData.submasterid,
    //     "page": 1,
    //     "pagesize": 10
    //   }

    //   this.mainserviceService.getSitebyuser(dummy_data).subscribe((res) => {
    //     console.log("Site Details =>",res);
    //     // this.filterArray = res.data;
    //     this.tempsiteList = res.data;
    //     // console.log(this.filterArray);
    //   }, (err) => {
    //     console.log(err.error);
    //   });

    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    console.log( "session storage value => ",userData);

    let dummy_data ={
      "siteid": null,
      "locationid": null,
      "sitecode": null,
      "sitename": null,
      "clientid": userData.submasterid,
      "machineid": null,
      "fieldengineerid": null,
      "isactive": true,
      "page": 1,
      "pagesize": 7
    }

    this.mainserviceService.getSite(dummy_data).subscribe((data1) => {
      console.log("Get Site Details =>",data1);
      // this.filterArray = res.data;
      // this.siteList = res.data;
      this.tempsiteList = data1.data;
      console.log("Site Details =>",this.tempsiteList );

    }, (err) => {
      console.log(err.error);
    });

}

onUpdate(){
  console.log("Doctor Allocate  => ",this.sitedetails);

  if((this.sitedetails.doctorid == null && this.sitedetails.doctorid == undefined) && (this.sitedetails.nurseid == null && this.sitedetails.nurseid == undefined)){
    swal.fire(
          'Good job!',
          'Doctorid or Nurseid is Empty!',
          'error'
        );
  }else{

    let obj1 =  {
        "clientmsterid": this.sitedetails.clientid,
        "machineid": this.sitedetails.machineid,
        "sitecode": this.sitedetails.sitecode,
        "doctorid": Number(this.sitedetails.doctorid)
  }

  let obj2 =  {
      "clientmsterid": this.sitedetails.clientid,
      "machineid": this.sitedetails.machineid,
      "sitecode": this.sitedetails.sitecode,
      "nurseid": Number(this.sitedetails.nurseid)
  }

  this.mainserviceService.allocatedoctor(obj1).subscribe((res) => {
    if(res.status_code =="s_438"){
      swal.fire(
        'Install Site',
        'Site does not Install..',
         'error'
       );
    }else if(res.status_code =="s_402"){
      this.mainserviceService.allocatenurse(obj2).subscribe((res) => {
        if(res.status_code =="s_438"){
          swal.fire(
            'Install Site',
            'Site does not Install..',
             'error'
           );
        }else if(res.status_code =="s_402"){
          swal.fire(
            'Good Job',
            'Doctor and Nurse Allocate Succesfully',
             'success'
           );
        }

      }, (err) => {console.log(err.error);});
    }


    }, (err) => {console.log(err.error);});

  //
}
}

getDutyDoctor(){

  var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
  console.log( "session storage value => ",userData);

  let dummy_data ={
    "usercategoryid": 8,
    "usersubcategoryid": 5,
    "submasterid":userData.submasterid,
    "page": 1,
    "pagesize": 7
  }
  this.mainserviceService.getUser(dummy_data).subscribe((res) => {
    console.log("Duty Doctor Details => ",res.data);
    this.doctorList = res.data;

    }, (err) => {
          console.log(err.error);

  });
}

getNursemaster(){
  var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
  console.log( "session storage value => ",userData);

  let dummy_data ={
    "usercategoryid": 9,
    "usersubcategoryid": 5,
    "submasterid":userData.submasterid,
    "page": 1,
    "pagesize": 7
  }

  this.mainserviceService.getUser(dummy_data).subscribe((res) => {
    console.log("Nurse Master Data => ",res.data);
    this.nurseList = res.data;
  }, (err) => {
    console.log(err.error);
  });
}

closeBtnClick() {
  this.modalService.dismissAll()
  this.ngOnInit();
}

}
