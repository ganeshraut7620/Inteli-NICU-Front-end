import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AlarmanalyticsRoutingModule } from './alarmanalytics-routing.module';
import { AlarmanalyticsComponent } from './alarmanalytics.component';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatTabsModule} from '@angular/material/tabs';
import {MatSelectModule} from '@angular/material/select';
import {MatInputModule} from '@angular/material/input';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';

@NgModule({
  declarations: [AlarmanalyticsComponent],
  imports: [
    CommonModule,
    MatExpansionModule,
    MatTabsModule,
    MatSelectModule,
    MatInputModule,
    MatSlideToggleModule,
    AlarmanalyticsRoutingModule,
    FormsModule,ReactiveFormsModule
  ]
})
export class AlarmanalyticsModule { }
