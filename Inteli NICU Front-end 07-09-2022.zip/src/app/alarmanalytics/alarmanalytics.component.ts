import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, RequiredValidator, FormBuilder } from '@angular/forms';

import { MainserviceService } from '../mainservice.service';
import * as moment from 'moment';
import { MatTabChangeEvent } from '@angular/material/tabs';

@Component({
  selector: 'app-alarmanalytics',
  templateUrl: './alarmanalytics.component.html',
  styleUrls: ['./alarmanalytics.component.css']
})
export class AlarmanalyticsComponent implements OnInit {

  trendsform: trends_form = new trends_form();
  msg: any;
  machineList: any;
  displayflag = false;
  alarm_show: any;
  alaramstatusdata: any;
  BabyList: any = [];
  panelOpenState = false;
  babyid: Number;
  pageadmit: number = 1;
  pagedischarge: number = 1;
  viewAlert;

  constructor(private mainserviceService: MainserviceService) {
    this.getbabydetails("admitted");
  }

  ngOnInit(): void {
  }

  getmachinedatareq() {
    console.log("fileter Data => ", this.trendsform)
    if (((this.trendsform.babyid == null) && (this.trendsform.babyid == undefined)) && (this.trendsform.babyid == undefined)) {
      console.log("Filter does not select Properlly => ", this.trendsform);
    } else {
      this.machinealert(this.trendsform.babyid);
    }
  }

  machinealert(babyid) {
    try {
      console.log("Warmer Details => ", babyid);
      this.mainserviceService.getactivealarm({
        "machineid": null,
        'babyid': Number(babyid)
      }).subscribe((res) => {
        console.log("Alarm response =======================", res.data);
        this.alaramstatusdata = res && res.data.length > 0 ? res.data : [];
        console.log("Alarm Data  pass => ", this.alaramstatusdata);

      }, (err) => {
        console.log(err);
      });
    } catch (err) {
      console.log(err);
    }
  }

  getbabydetails(status) {
    try {
      this.mainserviceService.getbabyid({
        "babyno": null,
        "babyname": null,
        "machineid": null,
        "clientid": JSON.parse(sessionStorage.getItem('userInfo1')).clientid,
        "babystatus": status,
        "isactive": true,
        "page": 1,
        "pagesize": 50000
      }).subscribe((res) => {
        console.log("Baby Details => ", res.data);
        this.BabyList = res.data ? res.data : [];
        if(res.data && res.data.length > 0 ){
          this.trendsform.babyid = res.data[0].babyid;
          this.getmachinedatareq();
        }
      }, (err) => {
        console.log(err.error);
      });
    } catch (err) {
      console.log(err);
    }
  }

  selectedBabys = (baby) => {
    try {
      console.log("BABY DETAILS =================", baby);
      this.babyid = Number(baby.babyid);
      // request alerts
      this.machinealert(this.babyid);
    } catch (err) {
      console.log(err);
    }
  }

  changeviewAlert = () => {
    try{
      
      if(this.viewAlert == undefined || this.viewAlert == null){
        this.viewAlert = true;
      }

      console.log("View Flag =============",this.viewAlert);

    }catch(err){
      console.log(err);
    }
  }

  
  trends_submit = () => {
    console.log("trends");
  }

}

class trends_form {
  babyid: Number;
}
