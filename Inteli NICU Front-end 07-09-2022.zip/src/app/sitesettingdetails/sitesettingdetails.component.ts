import { Component, OnInit } from '@angular/core';
import swal from 'sweetalert2';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, Validators, RequiredValidator,FormBuilder  } from '@angular/forms';

import { MainserviceService } from '../mainservice.service';
import { NgxSpinnerService } from "ngx-spinner";
import { site } from '../site/site-data';
//import { SiteService } from './site.service';
//import { Site } from './site';

@Component({
  selector: 'app-sitesettingdetails',
  templateUrl: './sitesettingdetails.component.html',
  styleUrls: ['./sitesettingdetails.component.css']
})
export class SitesettingdetailsComponent implements OnInit {
  page =1;
  filterArray:any;
  siteList:any;
  tempsiteList:any;
  submitted = false;
  pageSize:any;
  registerForm: FormGroup;
  sitedetails:any;

  constructor(private  mainserviceService: MainserviceService,private modalService: NgbModal,private fb: FormBuilder) {
    this.getSiteDetails(this.page);
  }

  ngOnInit(): void {
    this.registerForm = this.fb.group({
      sitecode:['',Validators.required],
    });
  }

  _searchTerm: string;
    get searchTerm(): string {
        return this._searchTerm;
    }
    set searchTerm(val: string) {
        this._searchTerm = val;
        this.filterArray = this.filter(val);
    }

    filter(v: string) {
        return this.tempsiteList.filter(x => x.sitename.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.clientname.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.machinename.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.fieldengineername.toLowerCase().indexOf(v.toLowerCase()) !== -1);
    }
  previous(){
    if(this.page>=2){
    this.page = this.page - 1;
    console.log("decriment => ",this.page);
    this.getSiteDetails(this.page);
    }else{
  
    }
  }
  
  next(){
    this.page = this.page + 1;
    console.log("Incriment => ",this.page);
    this.getSiteDetails(this.page);
  }

  getSiteDetails(page){
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    console.log( "session storage value => ",userData);

      let dummy_data ={
        "siteid": null,
        "locationid": null,
        "sitecode": null,
        "sitename": null,
        "clientid": null,
        "machineid": null,
        "fieldengineerid": userData.usermasterid,
        "isactive": true,
        "page": page,
        "pagesize": 5
      }


    this.mainserviceService.getSite(dummy_data).subscribe((data1) => {
      console.log("Get Site Details =>",data1);
      this.filterArray = data1.data;
      this.tempsiteList = data1.data;
      console.log("Site Details =>",this.tempsiteList );

    }, (err) => {
      console.log(err.error);
    });

}

onSubmit() {
  console.log("Site Install Form Succefully");

}

openModal(targetModal,site) {
  this.modalService.open(targetModal, {
      centered: true,
      backdrop: 'static',
      size: 'lg'
  })
  console.log("site updated Data => ",site);
  this.sitedetails = site;
  // this.editdutyroaster_details = dutyroaster;
}

onUpdate(){
  console.log("Site Update Details => ",this.sitedetails);

  if((this.sitedetails.masterusernameone == null && this.sitedetails.masterusernameone == undefined) && (this.sitedetails.masterpasswordone == null && this.sitedetails.masterpasswordone == undefined)){
    swal.fire(
          'Good job!',
          'Masterusername or Password is Empty!',
          'error'
        );
  }else{
    let obj =  {
    "sitecode": this.sitedetails.sitecode,
    "sitename": this.sitedetails.sitename,
    "address": this.sitedetails.siteaddress,
    "masterusernameone": this.sitedetails.masterusernameone,
    "masterpasswordone": this.sitedetails.masterpasswordone,
    "masterusernametwo": null,
    "masterpasswordtwo": null,
    "sitestatus": "ready to install",
    "isactive": true
  }

  this.mainserviceService.updatesite(obj).subscribe((res) => {
    console.log("site update => ",res);

    if(res.statusCod == 400){
      swal.fire(
        'error',
        res.message,

       );
       this.closeBtnClick();
    }

    if(res.status_code == "s_403"){
      swal.fire(
        'Good job!',
        'Site Updated Succsefully!',
        'success'
      );
      this.getSiteDetails(this.page);
      this.closeBtnClick();


    }else if(res.status_code =="s_1015"){
      swal.fire(
        'Bad Response!',
        'An Error Occured, Please Contact System Administrator!',
         'error'
       );
       this.closeBtnClick();
    }else{
      swal.fire(
        'Something Wrong!',
        'Call System Admin!',
         'error'
       );
       this.closeBtnClick();
    }

    }, (err) => {
          console.log(err.error);

  });
  }
}

  closeBtnClick() {
    this.modalService.dismissAll()
    this.ngOnInit();
  }

}
