import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SitesettingdetailsComponent } from './sitesettingdetails.component';

const routes: Routes = [
  { path: '' , component: SitesettingdetailsComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SitesettingdetailsRoutingModule { }
