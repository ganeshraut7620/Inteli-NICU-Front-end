import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SitesettingdetailsComponent } from './sitesettingdetails.component';

describe('SitesettingdetailsComponent', () => {
  let component: SitesettingdetailsComponent;
  let fixture: ComponentFixture<SitesettingdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SitesettingdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SitesettingdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
