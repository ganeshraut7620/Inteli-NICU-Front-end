import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { SitesettingdetailsRoutingModule } from './sitesettingdetails-routing.module';
import { SitesettingdetailsComponent } from './sitesettingdetails.component';


@NgModule({
  declarations: [SitesettingdetailsComponent],
  imports: [
    CommonModule,
    FormsModule,ReactiveFormsModule,
    SitesettingdetailsRoutingModule
  ]
})
export class SitesettingdetailsModule { }
