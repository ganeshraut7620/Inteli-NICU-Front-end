import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, ObservableInput } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class MainserviceService {

  // baseUrl = 'http://3.109.128.197:8080';
  // baseUrl = 'http://43.205.22.129:8080';
   baseUrl = 'http://localhost:8080';
  constructor(private http: HttpClient) { }

  post(data, url) {
    console.log(data, url);
    return this.http.post(this.baseUrl + url, data);
  }

  getcountry(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/address/getcountry', data);
  }

  getstate(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/address/getstate', data);
  }

  getdist(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/address/getdistrict', data);
  }

  loginUserMaster(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/usermaster/login', data);
  }

  loginUser(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/usermaster/login', data);
  }

  getUser(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/usermaster/get', data);
  }

  getApplog(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/applog/get', data);
  }

  getUserDetails(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/usermaster/getclientbyuser', data);
  }

  getMedicinecategory(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/medicinecategory/get', data);
  }


  createUser(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/usermaster/create', data);
  }

  updateUser(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/usermaster/update', data);
  }

  createMachine(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/machine/create', data);
  }

  updateMachine(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/machine/update', data);
  }

  getMachine(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/machine/get', data);
  }

  deleteMachine(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/machine/delete', data);
  }

  createClientMaster(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/clientmaster/create', data);
  }

  getClientMaster(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/clientmaster/get', data);
  }

  updateClient(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/clientmaster/update', data);
  }

  deleteClient(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/clientmaster/delete', data);
  }

  createDutyDoctor(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/doctormaster/create', data);
  }

  getDutyDoctor(data): Observable<any> {
    return this.http.post(this.baseUrl + "/api/v1/doctormaster/get", data)
  }

  updateDutyDoctor(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/doctormaster/update', data);
  }

  deleteDutyDoctor(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/doctormaster/delete', data);
  }

  createNurseMaster(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/nursemaster/create', data);
  }

  getNurseMaster(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/nursemaster/get', data);
  }

  updateNurseMaster(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/nursemaster/update', data);
  }

  deleteNurseMaster(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/nursemaster/delete', data);
  }


  createSite(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/site/create', data);
  }

  getSite(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/site/get', data);
  }

  getSitebyuser(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/site/getbyuser', data);
  }

  updateSite(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/site/update', data);
  }

  deleteSite(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/site/delete', data);
  }

  getAlarmDetails(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/alarmmaster/get', data);
  }

  createMedicinecategory(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/medicinecategory/create', data);
  }

  createdrugmaster(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/drugmaster/create', data);
  }

  createwhenmedcinemaster(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/medicinedetails/createwhen', data);
  }

  createhowmaster(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/medicinedetails/createhow', data);
  }

  createfrequencymaster(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/medicinedetails/createfrequency', data);
  }

  createdosageunitmaster(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/medicinedetails/createdosageunit', data);
  }

  getdruglist(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/drugmaster/get', data);
  }

  getbabyid(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/babymanager/get', data);
  }

  getwhenmaster(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/medicinedetails/getwhen', data);
  }

  gethowmaster(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/medicinedetails/gethow', data);
  }

  getfrequency(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/medicinedetails/getfrequency', data);
  }

  getdosageunit(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/medicinedetails/getdosageunit', data);
  }

  createmedicinemaster(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/medicinemaster/create', data);
  }

  getmedicine(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/medicinemaster/get', data);
  }

  createdutyroaster(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/dutyroaster/create', data);
  }


  getdutyraoster(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/dutyroaster/get', data);
  }

  deletedutyroaster(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/dutyroaster/delete', data);
  }

  createlocation(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/location/create', data);
  }

  getlocation(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/location/get', data);
  }

  createsite(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/site/create', data);
  }

  getactivealarm(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/alarmlog/getactivealarm', data);
  }
  //POST /api/v1/dashboard/getmachinedashboard
  getmachinedetails(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/dashboard/getmachinedashboard', data);
  }

  gettempdata(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/dashboard/gettemperaturegraph', data);
  }
  ///api/v1/dashboard/getspotwoprgraph
  getspoandpulserate(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/dashboard/getspotwoprgraph', data);
  }


  getspoandpulseratestate(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/dashboard/getspotwoprgraphState', data);
  }


  getalarmanalytic(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/alarmlog/getanalytics', data);
  }

  updatesite(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/site/update', data);
  }

  getamc(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/amcmaster/getamcdetails', data);
  }

  getcomplaint(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/complaint/get', data);
  }

  updatecomplaint(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/complaint/update', data);
  }

  updatecmp(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/complaint/update', data);
  }

  allocatedoctor(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/doctormaster/allocate', data);
  }

  allocatenurse(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/nursemaster/allocate', data);
  }

  getbaby(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/babymanager/get', data);
  }

  getdailybabyreport(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/report/generatebabyvital', data);
  }

  getbbabyhistory(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/report/generatebabyvital', data);
  }

  getdischargereport(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/report/getdischargereport', data);
  }

  getdischargereportclone(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/report/getdischargereportclone', data);
  }
  

  getdischargesummary(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/report/getdischargesummary', data);
  }

  getdeltatdata(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/dashboard/getdeltatgraph', data);
  }

  getweightdata(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/dashboard/getweightgraph', data);
  }

  getapgardata(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/dashboard/getapgartrendgraph', data);
  }

  getmachineclientwise(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/machine/getmachinebyclient', data);
  }

  getdashboarddetails(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/dashboardUpdate/getstatus', data);
  }

  getdashboarddetailsstatus(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/dashboardUpdate/getbabaycondition', data);
  }
  
  getstaticdashboard(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/dashboard/getmachinedashboard', data);
  }

  getdashboardupdate(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/dashboardUpdate/get', data);
  }

  getdasboard(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/dashboard/getmachinedashboard', data);
  }
  //POST /api/v1/dashboard/getapgartrendgraph

  getapgarscore(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/dashboard/getapgartrendgraph', data);
  }

  getmasterdashboard(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/dashboard/getmasterdashboard', data);
  }

  getcustomerservicedashboard(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/dashboard/getcustomerservicedashboard', data);
  }

  getfieldengdashboard(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/dashboard/getfieldengineerdashboard', data);
  }

  getmanagerdashboard(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/dashboard/getmanagerdashboard', data);
  }

  getvitaldashboard(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/dashboard/getvitaldashboard', data);
  }

  getmedcinereport(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/report/getmedicinereport', data);
  }


  createTestReport(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/testreport/create', data);
  }

  getTestReport(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/testreport/get', data);
  }

  createDoctorNotes(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/doctornotes/create', data);
  }

  getDoctorNotes(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/doctornotes/get', data);
  }

  createFluidChart(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/fluidbalancechart/create', data);
  }

  getFluidChart(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/fluidbalancechart/get', data);
  }

  createNurseIntervention(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/nurseintervention/create', data);
  }

  getNureseIntervention(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/nurseintervention/get', data);
  }

  createVitalParameter(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/spoprpi/create', data);
  }

  getVitalParameter(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/spoprpi/get', data);
  }

  creatdrughistorynotes(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/drughistorynotes/create', data);
  }

  getdrugHistory(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/drughistorynotes/get', data);
  }

  getDiseaseFilter(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/doctornotes/getfilter', data);
  }

  createReportlog(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/reportlog/create', data);
  }

  createTratmentSummary(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/diseasemaster/create', data);
  }

  getTratmentSummary(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/diseasemaster/get', data);
  }

  getBabyReport(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/reportlog/get', data);
  }


  createBabyReport(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/babymanagerupdate/create', data);
  }

  getBabyReportData(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/babymanagerupdate/get', data);
  }


  createRecentInvestigation(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/recentInvestigation/create', data);
  }

  getRecentInvestigation(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/recentInvestigation/get', data);
  }

  createImaging(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/imaging/create', data);
  }

  getImaging(data): Observable<any> {
    return this.http.post(this.baseUrl + '/api/v1/imaging/get', data);
  }

}
