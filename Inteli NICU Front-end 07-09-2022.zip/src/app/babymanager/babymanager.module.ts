import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { BabymanagerRoutingModule } from './babymanager-routing.module';
import { BabymanagerComponent } from './babymanager.component';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatTabsModule} from '@angular/material/tabs';
import {MatInputModule} from '@angular/material/input';
import {MatSelectModule} from '@angular/material/select';

@NgModule({
  declarations: [BabymanagerComponent],
  imports: [
    CommonModule,

    FormsModule,ReactiveFormsModule,
    BabymanagerRoutingModule,
    MatExpansionModule,
    MatTabsModule,
    MatSelectModule,
    MatInputModule
  ]
})
export class BabymanagerModule { }
