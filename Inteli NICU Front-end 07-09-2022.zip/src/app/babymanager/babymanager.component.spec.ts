import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BabymanagerComponent } from './babymanager.component';

describe('BabymanagerComponent', () => {
  let component: BabymanagerComponent;
  let fixture: ComponentFixture<BabymanagerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BabymanagerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BabymanagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
