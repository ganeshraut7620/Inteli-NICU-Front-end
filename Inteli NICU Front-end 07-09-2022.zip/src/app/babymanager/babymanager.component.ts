import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MainserviceService } from '../mainservice.service';
import swal from 'sweetalert2';
import { array } from '@amcharts/amcharts4/core';

@Component({
  selector: 'app-babymanager',
  templateUrl: './babymanager.component.html',
  styleUrls: ['./babymanager.component.css']
})
export class BabymanagerComponent implements OnInit {
  BabyList: any;
  page = 1;
  filterArray = [];
  doctorNotesList: any;
  babyid: any;
  treatment: any;
  drughistorynotes = [];
  babyReport: any;
  pageadmit: number = 1;
  pagedischarge: number = 1;
  interval = [1, 5, 10, 20, 30];
  graphinterval = new FormControl(1);
  tableinterval = new FormControl(1);

  //past obstetrics history
  age: any = '';
  gawks: any = '';
  bwgm: any = '';
  sex: any = '';
  significantdetails: any = '';

  //babyinfo 
  mothername: any = null;
  motherage: any = null;
  motheroccupation: any = null;
  mothereducation: any = null;
  fathername: any = null;
  fatherage: any = null;
  fatheroccuation: any = null;
  fathereducation: any = null;
  dateofadmission: any = null;
  timeofadmission: any = null;
  registerno: any = null;
  mrnno: any = null;
  address: any = null;
  pincode: any = null;
  cell: any = null;
  email: any = null;
  referredby: any = null;
  nicuconsultant: any = null;
  o_history_g: any = null;
  o_history_p: any = null;
  o_history_a: any = null;
  o_history_l: any = null;
  o_history_d: any = null;
  o_history_details: any = null;
  currentobstetricshistory: any = null;
  motherbloodgroup: any = null;
  lasthb: any = null;
  hiv: any = null;
  hbsag: any = null;
  vdrl: any = null;
  torch: any = null;
  usg: any = null;
  iugr: any = null;
  uaflow: any = null;
  significantfindings: any = null;
  antenatealsteroids: any = null;
  drug: any = null;
  doses: any = null;
  lmp: any = null;
  edd: any = null;
  maternalriskfactor: any = null;
  babyage: any = null;
  consanguinty: any = null;
  pre_pregnacy_weight: any = null;
  pvleak: any = null;
  pih: any = null;
  ecclampsia: any = null;
  chronicmedicalillness: any = null;
  thyroidstatus: any = null;
  infectiondisease: any = null;
  medicationandduration: any = null;
  nsaids: any = null;
  diabetes: any = null;
  assistedreproduction: any = null;
  anyother: any = null;
  mgso4: any = null;
  obstetrician: any = null;
  hospitalname: any = null;
  dateofdelivery: any = null;
  timeofdelivery: any = null;
  fetaldistress: any = null;
  ruptureofmembranes: any = null;
  modeofdelivery: any = null;
  presentation: any = null;
  liquor: any = null;
  resuscitation: any = null;
  apgaronemin: any = null;
  apgarfivemin: any = null;
  medicationduringresuscitation: any = null;
  deliveryroomcpap: any = null;
  cordclamping: any = null;
  caugeofadmission: any = null;
  transportdetails: any = null;
  transportduration: any = null;
  attendant: any = null;
  otherdetails: any = null;
  causecomment: any = null;

  caugeofadmissionFlag: boolean = false;

  //metrnal risk factor list
  maternalriskfactorList = ["Yes", "No"]
  consanguintyList = ["I", "II", "III", "Not known","No"]
  infectiondiseaseList = ["Malaria", "UTI", "TORCH", "TB", "Jaundice", "fever", "HIV", "HBV", "Covid-19", "Not known","No"]
  diabetesList = ["GDM", "NIDDM", "IDDM", "Not known","No"]
  anyotherList = ["Drug abuse", "APH", "Etc"]
  tempList = ["NSAIDs", "anti-epileptics", "anti-hypertensive", "Not known","No"]
  thyroidList = ["Euthyroid", "Hypothyroidism", "Hyperthyroidism", "Not known","No"];
  ageList = ["Age < 18", "Age > 35","18<Age<35"];
  pvLeakList = ["absent", "present", "blood stained"]

  cause_of_admission = ["prematurity", "respiratory distress", "jaundice", "others"];

  //current obstr history
  clinicalHistory = ["ANC", "NON-ANC"];
  bloodgroupList = ["a positive", "a negative", "b positive", "b negative", "o positive", "o negative", "ab positive", "ab negative", "Not known","No"];
  USGList = ["polyhydramnios", "adequate liquor", "oligohydramnios", "not known","No"]
  IUGRList = ["Yes", "No"]
  UAFlowList = ["normal", "diminished", "absent", "reversed", "not known","No"]
  status = ["Positive", "Negative"]

  // pernatal history
  hospitalnameList = ["KEM Hospital", "Other"];
  fetaldistressList = ["Yes", "No"];
  modList = ["spontaneous vaginal", "induced", "forceps", "vaccum", "caesarian section"];
  positionList = ["vertex", "breech", "other"]
  liquorList = ["clear", "meconium", "foul smelling"];
  resuscitationList = ["baby cried at birth", "required physical stimulation resuscitation", "required bag mask resuscitation", "required intubation resuscitation", "required CPR with ….minute of resuscitation"]
  deliveryroomList = ["given", "not given"];
  cordclampingList = ["early", "delayed"]
  vehicleList = ["Neonatal ambulance", "Ambulance", "Other"]
  attendantList = ["Trained medical", "Untrained medical", "Relatives", "Not known","No"]
  getGPALDFre: any[];
  existingBaby = [];
  dischargeBabyData: any;
  hbRange: any = [];
  assisted_reproduction = ["spontaneously", "via Ovulation induction", "via Intrauterine insemination", "via IVF", "via Other assisted reproduction"];
  antenatealsteroidsList = ["no", "incomplete dexamethasone", "complete dexamethasone", "incomplete betnasol", "complete betnasol"]

  //baby basic details 
  babyGender = ['male', 'female'];
  blood = ['A+', 'B+', 'O+', 'AB+', 'A-', 'B-', 'O-', 'AB-'];
  MOD = ["lscs", "vaginal", "forceps"];
  condition = ["critical", "moderate", "stable"];
  halls = ["hall-1", "hall-2", "hall-3", "hall-4", "hall-5", "hall-6"];
  bedList = [];

  babyDetails = {
    "babyno": "",
    "babyname": "",
    "fathername": "",
    "mothername": "",
    "gender": "male",
    "apgarscore": "",
    "apgarscore5": "",
    "edddate": null,
    "headcircumference": null,
    "babylength": null,
    "bgm": "",
    "bgb": "",
    "MOD": "",
    "dob": "",
    "week": '',
    "days": '',
    "motheraadharcard": "",
    "mothercontactone": null,
    "mothercontacttwo": null,
    "casedoctorname": "",
    "casedoctorcontactno": null,
    "casedoctoremailid": "",
    "bornweight": '',
    "admissiondate": "",
    "hallno": "",
    "bedno": "",
    "babycondition": "",
    "babystatus": "created",
    "remark": "",
    "machineid": 0,
    "clientid": 0,
    "modeofd": ""
  };
  babyManager: any;


  constructor(public mainserviceService: MainserviceService, private modalService: NgbModal) {
    this.getbabydetails(this.page, "admitted");
    this.hbRange = this.gethbrange(20);
    this.generatebed();
  }


  ngOnInit(): void {
    this.getGPALDFre = this.getGPALDRange();
  }

  getGPALDRange = () => {
    let arr = [];
    for (let i = 0; i <= 20; i++) {
      arr.push(i);
    }
    return arr.length > 0 ? arr : [];
  }

  addExistingBaby() {
    try {
      let obj = {
        age: this.age != null && this.age != undefined ? this.age : null,
        gawks: this.gawks != null && this.age != undefined ? this.gawks : null,
        bwgm: this.bwgm != null && this.bwgm != undefined ? this.bwgm : null,
        sex: this.sex != null && this.sex != undefined ? this.sex : null,
        significantdetails: this.significantdetails != null && this.significantdetails != undefined ? this.significantdetails : null
      }
      console.log("obj =======", obj);

      this.existingBaby.push(obj);

    } catch (errAddExistingBaby) {
      console.log("err===", errAddExistingBaby);
    }
  }


  openLg1(content2, row) {
    console.log("view Details ========================", row);
    this.getDrugHistoryNotes(row.babyid, row.doctornoteid)
    this.modalService.open(content2, { size: 'lg' });
  }

  openLg2(content3, row) {
    console.log("treatment order view Details ========================", row);
    this.treatment = row;
    this.modalService.open(content3, { size: 'lg' });
  }

  getbabydetails(pageinc, status) {
    try {
      console.log("Page inc => ", pageinc, 'status =>', status);
      this.mainserviceService.getbabyid({
        "babyno": null,
        "babyname": null,
        "machineid": null,
        "clientid": JSON.parse(sessionStorage.getItem('userInfo1')).clientid,
        "babystatus": status,
        "isactive": true,
        "page": pageinc,
        "pagesize": 5
      }).subscribe((res) => {
        console.log("Baby Details => ", res.data);
        // this.BabyList = res.data;
        if (res && res.data) {
          this.filterArray = res.data;
        } else {
          this.filterArray = [];
        }
      }, (err) => {
        console.log(err.error);
      });

    } catch (err) {
      console.log(err);
    }
  }

  admitprevious() {
    if (this.pageadmit >= 2) {
      this.pageadmit = this.pageadmit - 1;
      console.log("decriment => ", this.pageadmit)
      // this.getbabydetails(this.page);
      this.getbabydetails(this.pageadmit, "admitted");
    }
  }
  admitnext() {
    this.pageadmit = this.pageadmit + 1;
    console.log("Incriment => ", this.pageadmit)
    // this.getbabydetails(this.page);
    this.getbabydetails(this.pageadmit, "admitted");

  }

  dischargeprevious() {
    if (this.pagedischarge >= 2) {
      this.pagedischarge = this.pagedischarge - 1;
      console.log("decriment => ", this.pagedischarge)
      // this.getbabydetails(this.page);
      this.getbabydetails(this.pagedischarge, "admitted");
    }
  }
  dischargenext() {
    this.pagedischarge = this.pagedischarge + 1;
    console.log("Incriment => ", this.pagedischarge)
    // this.getbabydetails(this.page);
    this.getbabydetails(this.pagedischarge, "admitted");

  }

  getReportLog(babyid) {
    try {
      this.babyReport = [];
      this.mainserviceService.getBabyReport({ babyid: babyid }).subscribe((res) => {
        console.log("report Details => ", res.data);
        if (res && res.data) {
          this.babyReport = res.data;
        } else {
          this.babyReport = []
        }

      }, (err) => {
        console.log(err);
      });
    } catch (err) {
      console.log(err);
    }
  }
  //discharge


  onChange(event: MatTabChangeEvent) {
    try {
      const tab = event.tab.textLabel;
      console.log(tab);
      this.filterArray = [];
      if (tab === 'Created') {
        this.getbabydetails(1, "created");
      } else if (tab === "Admited") {
        this.getbabydetails(1, "admitted");
      } else if (tab == "Discharged") {
        this.getbabydetails(1, "discharge");
      }
    } catch (err) {
      console.log(err)
    }
  }

  getDoctorNotes(babyid) {
    try {
      this.doctorNotesList = [];
      let dummy_data = {
        "babyid": babyid,
      }
      this.mainserviceService.getDoctorNotes(dummy_data).subscribe((res) => {
        console.log("Doctor notes details ============ =>", res.data);
        if (res) {
          this.doctorNotesList = res.data ? res.data : [];
        }
      }, (err) => {
        console.log(err.error);
      });
    } catch (errNotes) {
      console.log("errNotes ==========", errNotes);
    }

  }

  selectedBabys = (baby) => {
    console.log("BABY DETAILS =================", baby);
    this.babyid = baby.babyid;
    this.babyManager = baby;
    console.log("BABY Manager details =================", this.babyManager);

    this.getBabyData(baby);
    this.afterGetBabyBasic(baby)
    //this.resetDoctorForm();
    this.getDoctorNotes(baby.babyid);
    this.getReportLog(baby.babyid);

  }

  generatebed = () => {
    try {
      for (let i = 1; i <= 50; i++) {
        this.bedList.push("bed-" + i);
      }

      console.log("Bed list ===============", this.bedList);
    } catch (errBed) {
      console.log("err==========================", errBed);
    }
  }

  getDrugHistoryNotes = (babyid, doctornotesid) => {
    try {
      this.drughistorynotes = [];
      console.log("")
      this.mainserviceService.getdrugHistory({ babyid: babyid, doctornotesid: doctornotesid }).subscribe((res) => {
        console.log("Drug history res===============", res);
        if (res && res.data) {
          this.drughistorynotes = res.data;
        }
      });

    } catch (errDrugNotes) {
      console.log("err =====================", errDrugNotes);
    }
  }

  updateBabyDeatils() {
    try {
      let data: any = {};
      console.log("update get data ", data);
      data.babyid = this.babyid;
      data.mothername = this.mothername;
      data.motherage = this.motherage;
      data.motheroccupation = this.motheroccupation;
      data.mothereducation = this.mothereducation;
      data.fathername = this.fathername;
      data.fatherage = this.fatherage;
      data.fatheroccuation = this.fatheroccuation;
      data.fathereducation = this.fathereducation;
      data.dateofadmission = this.dateofadmission;
      data.timeofadmission = this.timeofadmission;
      data.registerno = this.registerno;
      data.mrnno = this.mrnno;
      data.address = this.address;
      data.hospitalname = this.hospitalname;
      data.cell = this.cell;
      data.email = this.email;
      data.referredby = this.referredby;
      data.nicuconsultant = this.nicuconsultant;
      data.o_history_g = this.o_history_g;
      data.o_history_p = this.o_history_p;
      data.o_history_a = this.o_history_a;
      data.o_history_l = this.o_history_l;
      data.o_history_d = this.o_history_d;
      data.motherbloodgroup = this.motherbloodgroup;
      data.lasthb = this.lasthb;
      data.hiv = this.hiv;
      data.hbsag = this.hbsag;
      data.vdrl = this.vdrl;
      data.torch = this.torch;
      data.usg = this.usg;
      data.iugr = this.iugr;
      data.uaflow = this.uaflow;
      data.significantfindings = this.significantfindings;
      data.antenatealsteroids = this.antenatealsteroids;
      data.drug = this.drug;
      data.doses = this.doses;
      data.lmp = this.lmp;
      data.maternalriskfactor = this.maternalriskfactor;
      data.babyage = this.babyage;
      data.ecclampsia = this.ecclampsia;
      data.chronicmedicalillness = this.chronicmedicalillness;
      data.thyroidstatus = this.thyroidstatus;
      data.infectiondisease = this.infectiondisease;
      data.medicationandduration = this.medicationandduration;
      data.nsaids = this.nsaids;
      data.diabetes = this.diabetes;
      data.assistedreproduction = this.assistedreproduction;
      data.anyother = this.anyother;
      data.mgso = this.mgso4 ? this.mgso4.length > 0 ? this.mgso4 : ' ' : null;
      data.obstetrician = this.obstetrician;
      data.hospitalname = this.hospitalname;
      data.dateofdelivery = this.dateofdelivery;
      data.timeofdelivery = this.timeofdelivery;
      data.fetaldistress = this.fetaldistress;
      data.ruptureofmembranes = this.ruptureofmembranes;
      data.modeofdelivery = this.modeofdelivery;
      data.presentation = this.presentation;
      data.liquor = this.liquor;
      data.resuscitation = this.resuscitation;
      data.apgaronemin = this.apgaronemin;
      data.apgarfivemin = this.apgarfivemin;
      data.medicationduringresuscitation = this.medicationduringresuscitation;
      data.deliveryroomcpap = this.deliveryroomcpap;
      data.cordclamping = this.cordclamping;
      data.caugeofadmission = this.caugeofadmission;
      data.transportdetails = this.transportdetails;
      data.transportduration = this.transportduration;
      data.attendant = this.attendant;
      data.otherdetails = this.otherdetails;

      //NEW DATA 
      data.consanguinty = this.consanguinty;
      data.pre_pregnacy_weight = this.pre_pregnacy_weight;
      data.pvleak = this.pvleak;
      data.pih = this.pih;
      data.edd = this.edd;
      data.currentobstetricshistory = this.currentobstetricshistory;
      data.pincode = this.pincode;
      data.causecomment = this.causecomment;

      console.log("Baby Update details =============", data);

      this.mainserviceService.createBabyReport(data).subscribe((res) => {
        console.log("Baby Report response => ", res);

        if (res && res.status) {

          this.updateBabyManager(this.babyDetails,data);
          swal.fire(
            'Good job!',
            'Baby Details Succsefully!',
            'success'
          )
        } else {
          //error
          swal.fire(
            'Bad Response!',
            'Baby Details not updated!',
            'error'
          );
        }
      }, (err) => {
        console.log(err);
        swal.fire(
          'Bad Response!',
          'Something Wrong,Kindly Contact System Adminstrator!',
          'error'
        );
      });

    } catch (errBabyDetails) {
      console.log("err============", errBabyDetails);
      swal.fire(
        'Bad Response!',
        'Something Wrong,Kindly Contact System Adminstrator!',
        'error'
      );
    }
  }

  getBabyData = (baby) => {
    try {
      console.log("Get baby data ===", this.babyid);

      this.mainserviceService.getBabyReportData({ 'babyid': this.babyid }).subscribe((res) => {
        console.log("Get Baby Report response => ", res);

        this.dischargeBabyData = res ? res.data : [];

        if (this.dischargeBabyData) {
          // this.babyid = this.babyid;
          this.mrnno = baby.babyno;
          this.mothername = this.dischargeBabyData.mothername;
          this.motherage = this.dischargeBabyData.motherage;
          this.motheroccupation = this.dischargeBabyData.motheroccupation;
          this.mothereducation = this.dischargeBabyData.mothereducation;
          this.fathername = this.dischargeBabyData.fathername;
          this.fatherage = this.dischargeBabyData.fatherage;
          this.fatheroccuation = this.dischargeBabyData.fatheroccuation;
          this.fathereducation = this.dischargeBabyData.fathereducation;
          this.dateofadmission = this.dischargeBabyData.dateofadmission;
          this.timeofadmission = this.dischargeBabyData.timeofadmission;
          this.registerno = this.dischargeBabyData.registerno;
          // this.mrnno = this.dischargeBabyData.mrnno;
          this.address = this.dischargeBabyData.address;
          this.hospitalname = this.dischargeBabyData.hospitalname;
          this.cell = this.dischargeBabyData.cell;
          this.email = this.dischargeBabyData.email;
          this.referredby = this.dischargeBabyData.referredby;
          this.nicuconsultant = this.dischargeBabyData.nicuconsultant;
          this.o_history_g = this.dischargeBabyData.o_history_g;
          this.o_history_p = this.dischargeBabyData.o_history_p;
          this.o_history_a = this.dischargeBabyData.o_history_a;
          this.o_history_l = this.dischargeBabyData.o_history_l;
          this.o_history_d = this.dischargeBabyData.o_history_d;
          this.motherbloodgroup = this.dischargeBabyData.motherbloodgroup;
          this.lasthb = this.dischargeBabyData.lasthb;
          this.hiv = this.dischargeBabyData.hiv;
          this.hbsag = this.dischargeBabyData.hbsag;
          this.vdrl = this.dischargeBabyData.vdrl;
          this.torch = this.dischargeBabyData.torch;
          this.usg = this.dischargeBabyData.usg;
          this.iugr = this.dischargeBabyData.iugr;
          this.uaflow = this.dischargeBabyData.uaflow;
          this.significantfindings = this.dischargeBabyData.significantfindings;
          this.antenatealsteroids = this.dischargeBabyData.antenatealsteroids;
          this.drug = this.dischargeBabyData.drug;
          this.doses = this.dischargeBabyData.doses;
          this.lmp = this.dischargeBabyData.lmp;
          this.maternalriskfactor = this.dischargeBabyData.maternalriskfactor;
          this.babyage = this.dischargeBabyData.babyage;
          this.ecclampsia = this.dischargeBabyData.ecclampsia;
          this.chronicmedicalillness = this.dischargeBabyData.chronicmedicalillness;
          this.thyroidstatus = this.dischargeBabyData.thyroidstatus;
          this.infectiondisease = this.dischargeBabyData.infectiondisease;
          this.medicationandduration = this.dischargeBabyData.medicationandduration;
          this.nsaids = this.dischargeBabyData.nsaids;
          this.diabetes = this.dischargeBabyData.diabetes;
          this.assistedreproduction = this.dischargeBabyData.assistedreproduction;
          this.anyother = this.dischargeBabyData.anyother;
          this.mgso4 = this.dischargeBabyData.mgso;
          this.obstetrician = this.dischargeBabyData.obstetrician;
          this.hospitalname = this.dischargeBabyData.hospitalname;
          this.dateofdelivery = this.dischargeBabyData.dateofdelivery;
          this.timeofdelivery = this.dischargeBabyData.timeofdelivery;
          this.fetaldistress = this.dischargeBabyData.fetaldistress;
          this.ruptureofmembranes = this.dischargeBabyData.ruptureofmembranes;
          this.modeofdelivery = this.dischargeBabyData.modeofdelivery;
          this.presentation = this.dischargeBabyData.presentation;
          this.liquor = this.dischargeBabyData.liquor;
          this.resuscitation = this.dischargeBabyData.resuscitation;
          this.apgaronemin = this.dischargeBabyData.apgaronemin;
          this.apgarfivemin = this.dischargeBabyData.apgarfivemin;
          this.medicationduringresuscitation = this.dischargeBabyData.medicationduringresuscitation;
          this.deliveryroomcpap = this.dischargeBabyData.deliveryroomcpap;
          this.cordclamping = this.dischargeBabyData.cordclamping;
          this.caugeofadmission = this.dischargeBabyData.caugeofadmission;
          this.transportdetails = this.dischargeBabyData.transportdetails;
          this.transportduration = this.dischargeBabyData.transportduration;
          this.attendant = this.dischargeBabyData.attendant;
          this.otherdetails = this.dischargeBabyData.otherdetails;

          //NEW DATA 
          this.consanguinty = this.dischargeBabyData.consanguinty;
          this.pre_pregnacy_weight = this.dischargeBabyData.pre_pregnacy_weight;
          this.pvleak = this.dischargeBabyData.pvleak;
          this.pih = this.dischargeBabyData.pih;
          this.edd = this.dischargeBabyData.edd;
          this.pincode = this.dischargeBabyData.pincode;
          this.currentobstetricshistory = this.dischargeBabyData.currentobstetricshistory;
          this.causecomment = this.dischargeBabyData.causecomment
        }
      }, (err) => {
        console.log(err);
      });

    } catch (err) {
      console.log(err);
    }
  }

  afterSelectedCusge() {
    try {
      this.caugeofadmissionFlag = true;
    } catch (err) {
      console.log("err======", err);
    }
  }


  gethbrange(range) {
    try {
      let arr = [];
      for (let i = 1; i <= range; i++) {
        arr.push(String(i));
      }

      return arr;

    } catch (err) {
      console.log(err);
    }
  }

  afterGetBabyBasic = (baby) => {
    try {
      console.log("BabyDetails ========================", baby);
      this.babyDetails.babyname = baby ? baby.babyname : null;
      this.babyDetails.admissiondate = baby ? baby.admissiondate : null;
      this.babyDetails.apgarscore = baby ? baby.apgarscore : null;
      this.babyDetails.apgarscore5 = baby ? baby.apgarscore5 : null;
      this.babyDetails.babycondition = baby ? baby.babycondition : null;
      this.babyDetails.babylength = baby ? baby.babylength : null;
      // this.babyDetails.babyname = baby? baby.babyname : null;
      this.babyDetails.babyno = baby ? baby.babyno : null;
      this.babyDetails.babystatus = baby ? baby.babystatus : null;
      this.babyDetails.bedno = baby ? baby.bedno : null;
      this.babyDetails.bgb = baby ? baby.bgb : null;
      this.babyDetails.bgm = baby ? baby.bgm : null;
      this.babyDetails.bornweight = baby ? baby.bornweight : null;
      this.babyDetails.casedoctorcontactno = baby ? baby.casedoctorcontactno : null;
      this.babyDetails.casedoctoremailid = baby ? baby.casedoctoremailid : null;
      this.babyDetails.casedoctorname = baby ? baby.casedoctorname : null;
      //this.babyDetails.dateofdischarge = baby? baby.babyname : null;
      this.babyDetails.days = baby ? baby.days : null;
      // thies.babyDetails.dischargegestationage = baby? baby.babyname : null;
      // this.babyDetails.dischargegestationagedays = baby? baby.babyname : null;
      // this.babyDetails.dischargeweight = baby? baby.babyname : null;
      this.babyDetails.dob = baby ? baby.dob : null;
      this.babyDetails.edddate = baby ? baby.edddate : null;
      this.babyDetails.fathername = baby ? baby.fathername : null;
      this.babyDetails.gender = baby ? baby.gender : null;
      this.babyDetails.hallno = baby ? baby.hallno : null;
      this.babyDetails.headcircumference = baby ? baby.headcircumference : null;
      this.babyDetails.modeofd = baby ? baby.modeofd : null;
      this.babyDetails.motheraadharcard = baby ? baby.motheraadharcard : null;
      this.babyDetails.mothercontactone = baby ? baby.mothercontactone : null;
      this.babyDetails.mothercontacttwo = 7620920290
      this.babyDetails.mothername = baby ? baby.mothername : null;
      this.babyDetails.remark = baby ? baby.remark : null;
      this.babyDetails.week = baby ? baby.week : null;
    } catch (err) {
      console.log(err);
    }
  }

  updateBabyManager = (Baby,updateBaby) => {
    try {
      console.log("Baby detais ==========", Baby);
      let obj = {
        admissiondate: Baby ? Baby.admissiondate : null,
        apgarscore:  Baby ? Baby.apgarscore : null,
        apgarscore5:  Baby ? Baby.apgarscore5 : null,
        babycondition:  Baby ? Baby.babycondition : null,
        babyid:  Baby ? Baby.babyid : null,
        babylength:  Baby ? Baby.babylength : null,
        babyname:  Baby ? Baby.babyname : null,
        babyno:  Baby ? Baby.babyno : null,
        babystatus:  Baby ? Baby.babystatus : null,
        bedno:  Baby ? Baby.bedno : null,
        bgb:  Baby ? Baby.bgb : null,
        bgm:  Baby ? Baby.bgm : null,
        bornweight:  Baby ? Baby.bornweight : null,
        casedoctorcontactno:  Baby ? Baby.casedoctorcontactno : null,
        casedoctoremailid:  Baby ? Baby.casedoctoremailid : null,
        casedoctorname:  Baby ? Baby.casedoctorname : null,
        clientid:  Baby ? Baby.clientid : null,
        days:  Baby ? Baby.days : null,
        dob:  Baby ? Baby.dob : null,
        edddate:  Baby ? Baby.edddate : null,
        fathername: updateBaby ? updateBaby.fathername : null,
        gender:  Baby ? Baby.gender : null,
        hallno:  Baby ? Baby.hallno : null,
        headcircumference:  Baby ? Baby.headcircumference : null,
        machineid:  Baby ? Baby.machineid : null,
        modeofd: Baby ? Baby.modeofd : null,
        motheraadharcard:  Baby ? Baby.motheraadharcard : null,
        mothercontactone:  Baby ? Baby.mothercontactone : null,
        mothercontacttwo:  Baby ? Baby.mothercontacttwo : null,
        mothername:  updateBaby ? updateBaby.mothername : null,
        remark:  Baby ? Baby.remark : null,
        week : Baby ? Baby.week : null
      }

      console.log("")
    } catch (err) {
      console.log("Babymanager err ==============", err);
    }
  }

}

