import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fieldengdash',
  templateUrl: './fieldengdash.component.html',
  styleUrls: ['./fieldengdash.component.css']
})
export class FieldengdashComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
