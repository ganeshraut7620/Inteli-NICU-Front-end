import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FieldengdashComponent } from './fieldengdash.component';

describe('FieldengdashComponent', () => {
  let component: FieldengdashComponent;
  let fixture: ComponentFixture<FieldengdashComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FieldengdashComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FieldengdashComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
