import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FieldengdashRoutingModule } from './fieldengdash-routing.module';
import { FieldengdashComponent } from './fieldengdash.component';


@NgModule({
  declarations: [FieldengdashComponent],
  imports: [
    CommonModule,
    FieldengdashRoutingModule
  ]
})
export class FieldengdashModule { }
