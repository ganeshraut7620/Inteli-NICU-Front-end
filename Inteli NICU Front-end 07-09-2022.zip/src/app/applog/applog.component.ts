import { Component, OnInit } from '@angular/core';
import { MainserviceService } from '../mainservice.service';
@Component({
  selector: 'app-applog',
  templateUrl: './applog.component.html',
  styleUrls: ['./applog.component.css']
})
export class ApplogComponent implements OnInit {
  applogData: any;

  constructor(public mainserviceService:MainserviceService) {
    this.getAppLogData();
   }

  ngOnInit(): void {
  }

  getAppLogData() {
    let dummy_data ={
      "page": 1,
      "pagesize": 10000000000
    }
    this.mainserviceService.getApplog(dummy_data).subscribe((res) => {
      console.log(res.data);
      this.applogData = res.data.rows;
     
      }, (err) => {
            console.log(err.error);

    });
  }

}
