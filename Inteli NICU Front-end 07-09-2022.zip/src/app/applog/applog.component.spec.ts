import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplogComponent } from './applog.component';

describe('ApplogComponent', () => {
  let component: ApplogComponent;
  let fixture: ComponentFixture<ApplogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
