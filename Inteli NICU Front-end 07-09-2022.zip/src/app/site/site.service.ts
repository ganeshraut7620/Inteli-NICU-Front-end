import { Injectable } from '@angular/core';
import { Site } from './site';
import { site } from './site-data'

@Injectable({
  providedIn: 'root'
})
export class SiteService {

  public site: Site[] = site;

    public getsite() {
        return this.site;
    }
}
