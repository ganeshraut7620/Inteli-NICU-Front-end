import { Component, OnInit } from '@angular/core';
import swal from 'sweetalert2';
import { FormGroup, FormControl, Validators, RequiredValidator,FormBuilder  } from '@angular/forms';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CustomvalidationService } from '../services/customvalidation.service';
import { MachinemasterService } from '.././machinemaster/machinemaster.service';
import { MainserviceService } from '../mainservice.service';
import { NgxSpinnerService } from "ngx-spinner";
import { SiteService } from './site.service';
import { Site } from './site';

@Component({
  selector: 'app-site',
  templateUrl: './site.component.html',
  styleUrls: ['./site.component.css']
})
export class SiteComponent implements OnInit {

  page = 1;
  pageSize = 7;

  machine:any = ['Machine-12','Machine-13','Machine-13'];
  clients:any =  ['Client-1','Client-2','Client-3'];
  fieldengids = ['Rushikesh','Aniket','Ankit'];
  sites = ['testsite1','testsit2'];

  machineList:any;
  siteList: Site[] = this.siteservice.getsite();
  filterArray:any;
  clientList: any;
  fieldengList:any;
  LocationDetails:any;
  respose_catch: any;
  countrys:any;
  states:any;
  citys:any;


  constructor(private spinner: NgxSpinnerService,private mainserviceService:MainserviceService,private machinemasterservice : MachinemasterService,private siteservice:SiteService,private modalService: NgbModal,private fb: FormBuilder,private customValidator: CustomvalidationService) {
   // this.filterArray = this.siteList;
    this.spinner.show();
    this.getmachine();
    this.getClientMasterDetails(this.page);
    this.getfieldengdetails();

    this.getlocationdetails();
    this.getSiteDetails()
    this.getcountry();

    setTimeout(() => {
      /** spinner ends after 5 seconds */
      this.spinner.hide();
    }, 1000);

    //this.getSiteDetails();
  }

  show: boolean = false;
  registerForm: FormGroup;
  submitted = false;
  editsite:any;

 
  _searchTerm: string;
  get searchTerm(): string {
    return this._searchTerm;
  }
  set searchTerm(val: string) {
    this._searchTerm = val;
    this.filterArray = this.filter(val);
  }

  filter(v: string) {
    return this.siteList.filter(x => x.sitename.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.clientname.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.machinename.toLowerCase().indexOf(v.toLowerCase()) !== -1);
  }

  open1(content1) {
		this.modalService.open(content1, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
			//this.closeResult = `Closed with: ${result}`;
		}, (reason) => {
			//this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
		});
  }

  ngOnInit(): void {
    this.commonform();
  }

  commonform = () => {
    this.registerForm = this.fb.group({
      sitename: new FormControl(null,[Validators.required]),
      clientid: new FormControl(null,[Validators.required]),
      machineid:new FormControl(null,[Validators.required]),
      countryid:new FormControl(null,[Validators.required]),
      stateid:new FormControl(null,[Validators.required]),
      city:new FormControl(null,[Validators.required]),
      pincode:new FormControl(null,[Validators.required]),
      address: new FormControl(null,[Validators.required]),
      fieldengineerid: new FormControl(null,[Validators.required]),
    }
    );
  }

  get registerFormControl() {
    return this.registerForm.controls;
  }

  openLg(content1) {
    this.commonform();
		this.modalService.open(content1, { size: 'lg' });
  }

  openModal(targetModal,site) {
    this.modalService.open(targetModal, {
        centered: true,
        backdrop: 'static',
        size: 'lg'
    })
    console.log(site);
    this.editsite= site;
}

keyPress(event: any) {
  const pattern = /[0-9\+\-\ ]/;

  let inputChar = String.fromCharCode(event.charCode);
  if (event.keyCode != 8 && !pattern.test(inputChar)) {
    event.preventDefault();
  }

  if (event.keyCode === 32 ) {
    return false;
  }
}

changecity(){

  console.log(this.registerForm.value.stateid);
  let data = {
    "districtid": null,
    "stateid": this.registerForm.value.stateid,
    "page": 1,
    "pagesize": 100000
  }

  this.mainserviceService.getdist(data).subscribe((res) => {
    console.log("District res =>",res);
    this.citys = res.data;
    console.log("District detals => ",this.citys);

    }, (err) => {
          console.log(err.error);

  });

}

changestate(){
  console.log(this.registerForm.value.country);
  let data = {
    "countryid": this.registerForm.value.countryid,
    "stateid": null,
    "page": 1,
    "pagesize": 10000
  }

  this.mainserviceService.getstate(data).subscribe((res) => {
    console.log("statre res =>",res);
    this.states = res.data;
    console.log("state detals => ",this.states);

    }, (err) => {
          console.log(err.error);

  });
}

getcountry(){
  let data = {
    "countryid": null,
    "page": 1,
    "pagesize": 10000
  }

  this.mainserviceService.getcountry(data).subscribe((res) => {
    console.log("country res =>",res);
    this.countrys = res.data;
    console.log("country detals => ",this.countrys);

    }, (err) => {
          console.log(err.error);

  });
}


getmachine(){
  var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
  console.log( "session storage value => ",userData);
  let dummy_data ={
    "machineid": null,
    "machinemodelno": null,
    "machineno": null,
    "machineserialno": null,
    "usermasterid":userData.usermasterid,
    "isactive": true,
    "requiresite": "yes",
    "submasterid":null,
    "page": 1,
    "pagesize": 10000
    }
  this.mainserviceService.getMachine(dummy_data).subscribe((res) => {
    console.log("Get Machine Details =>",res)
    this.machineList = res.data;
  }, (err) => {
    console.log(err.error);
  });
}

getClientMasterDetails(page){
  let dummy_data ={
    "usercategoryid":5,
    "usersubcategoryid": 2,
    "page": page,
    "pagesize": 5
  }

  this.mainserviceService.getUser(dummy_data).subscribe((res) => {
    // this.filterArray = res.data;
    this.clientList = res.data;

    console.log("Get Client =>",res);
      }, (err) => {
    console.log(err.error);
  });

}

getfieldengdetails(){
  let dummy_data ={
    "usercategoryid":4,
    "usersubcategoryid":null,
    "page": 1,
    "pagesize": 10000
  }

  this.mainserviceService.getUser(dummy_data).subscribe((res) => {
    console.log("Get Field Eng Details =>",res.data);
    // this.filterArray = res.data;
    this.fieldengList = res.data;
      }, (err) => {
    console.log(err.error);
  });

}

getlocationdetails(){

  let obj = {
    "clientid": null,
    "locationid": null,
    "usercategoryid": null,
    "page": 1,
    "pagesize": 10000
  }

  this.mainserviceService.getlocation(obj).subscribe((res) => {
    console.log("Location Details Res => ",res);
    if(res.status_code == "s_407"){
      this.LocationDetails = res.data[0].location;
      console.log("Location Details =>",this.LocationDetails);

    }
  });

}


onSubmit() {
    this.submitted = true;

    console.log("Site Form Data =>",this.registerForm.value);

    if(this.registerForm.valid){
      var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
      console.log( "session storage value => ",userData);
      this.registerForm.value.usermasterid = userData.usermasterid;
      this.registerForm.value.locationid = null;
      this.registerForm.value.isactive = true;

      this.mainserviceService.createsite(this.registerForm.value).subscribe((data) => {
        console.log("Site Response => ",data);
        this.respose_catch = data;

        console.log(this.respose_catch.status_code);


        if(this.respose_catch.status_code == "s_405"){
          swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Something wrong!',
          })
          }else if(this.respose_catch.status_code == "s_405"){
          swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'site already exist!',

          })

        }else if(this.respose_catch.status_code == "s_402"){
          swal.fire(
                  'Good job!',
                  'site Added Succsefully!',
                  'success'
                );
            // this.getClientMasterDetails();
            this.getSiteDetails();
            this.closeBtnClick();
            this.registerForm = this.fb.group({
                  sitename: new FormControl(null,[Validators.required]),
                  clientid: new FormControl(null,[Validators.required]),
                  machineid:new FormControl(null,[Validators.required]),
                  countryid:new FormControl(null,[Validators.required]),
                  stateid:new FormControl(null,[Validators.required]),
                  city:new FormControl(null,[Validators.required]),
                  pincode:new FormControl(null,[Validators.required]),
                  address: new FormControl(null,[Validators.required]),
                  fieldengineerid: new FormControl(null,[Validators.required]),
                });
        }

            }, (err) => {
              console.log(err.error);
              swal.fire(
                'Server Request Time Out!',
                err.error,
                'error'

              )
              this.closeBtnClick();
            });

    }

    
  }

  getSiteDetails(){
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    console.log( "session storage value => ",userData);

      let dummy_data ={

        "usermasterid": userData.usermasterid,
        "page": 1,
        "pagesize": 10
      }

      this.mainserviceService.getSitebyuser(dummy_data).subscribe((res) => {
        console.log("Get Site Details =>",res);
        this.filterArray = res.data;
        this.siteList = res.data;
        console.log(this.filterArray);
      }, (err) => {
        console.log(err.error);
      });

  }

  openModal1(targetModal) {
    this.modalService.open(targetModal, {
        centered: true,
        backdrop: 'static',
        size: 'lg'
    })
   // console.log(machinemaster);
    //this.editmachinemaster = machinemaster;
  }

  closeBtnClick() {
    this.modalService.dismissAll()
    this.ngOnInit();
  }

  previous(){
    if(this.page>=2){
    this.page = this.page - 1;
    console.log("decriment => ",this.page)
    this.getClientMasterDetails(this.page)
    }else{
  
    }
  }
  
  next(){
    this.page = this.page + 1;
    console.log("Incriment => ",this.page)
    this.getClientMasterDetails(this.page)
  }

}
