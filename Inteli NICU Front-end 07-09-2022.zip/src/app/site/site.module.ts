import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { SiteRoutingModule } from './site-routing.module';
import { SiteComponent } from './site.component';
import { NgxSpinnerModule } from "ngx-spinner";

@NgModule({
  declarations: [SiteComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SiteRoutingModule,
    NgxSpinnerModule
  ]
})
export class SiteModule { }
