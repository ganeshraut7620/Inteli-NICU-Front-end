export class Site {
 public siteid:Number;
 public address:String;
 public machineid:String;
 public clientid:String;
 public location:String;
 public fieldengid:String;
  sitename: any;
  clientname: any;
  machinename: any;
}
