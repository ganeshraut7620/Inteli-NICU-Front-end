import { Component, AfterViewInit } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner";
@Component({
  templateUrl: './starter.component.html'
})
export class StarterComponent implements AfterViewInit {
  subtitle: string;
  userInfo:any;

  sites = [
    { "sitename": "site1" , "machinename":"machine1" , "clientname":"client1"},
    { "sitename": "site2" , "machinename":"machine2" , "clientname":"client2"},
    { "sitename": "site3" , "machinename":"machine3" , "clientname":"client3"}
  ]
  limites = [1,2,3];

  constructor(private spinner: NgxSpinnerService,) {
    //this.refresh();
    if(sessionStorage.getItem('flag') == "true"){
      window.location.reload(true);
      sessionStorage.setItem('flag','false');
    }


    this.spinner.show();

    setTimeout(() => {
        /** spinner ends after 5 seconds */
        this.spinner.hide();
    }, 1000);

    this.userInfo = sessionStorage.getItem("userInfo1");
    console.log("User Information => ",this.userInfo);
  }

  refresh(): void {

  }

  ngAfterViewInit() {}
}
