import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { TrendsRoutingModule } from './trends-routing.module';
import { TrendsComponent } from './trends.component';
import { NgxSpinnerModule } from "ngx-spinner";
import { DatePipe } from '@angular/common';

@NgModule({
  declarations: [TrendsComponent],
  imports: [
    CommonModule,
    TrendsRoutingModule,
    FormsModule,
    NgxSpinnerModule,
    ReactiveFormsModule
  ],
  providers: [DatePipe]
})
export class TrendsModule { }
