import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, RequiredValidator,FormBuilder  } from '@angular/forms';

import { CustomvalidationService } from '../services/customvalidation.service';

@Component({
  selector: 'app-formtest',
  templateUrl: './formtest.component.html',
  styleUrls: ['./formtest.component.css']
})
export class FormtestComponent implements OnInit {

  show: boolean = false;
  registerForm: FormGroup;
  submitted = false;

  form = new FormGroup({
    //companyid: new FormControl('', Validators.required),
    clientid: new FormControl('', Validators.required),
    pwd: new FormControl('', Validators.required)
  });

  registerform = new FormGroup({
    fname: new FormControl('',Validators.required),
    lname:new FormControl('',Validators.required)
  })

  constructor(private fb: FormBuilder,
    private customValidator: CustomvalidationService) { }

    ngOnInit() {
      this.registerForm = this.fb.group({
        name: ['', Validators.required],
        email: ['', [Validators.required, Validators.email]],
        username: ['', [Validators.required], this.customValidator.userNameValidator.bind(this.customValidator)],
        password: ['', Validators.compose([Validators.required, this.customValidator.patternValidator()])],
        confirmPassword: ['', [Validators.required]],
      },
        {
          validator: this.customValidator.MatchPassword('password', 'confirmPassword'),
        }
      );
    }

    get registerFormControl() {
      return this.registerForm.controls;
    }

    onSubmit() {
      this.submitted = true;
      if (this.registerForm.valid) {
        alert('Form Submitted succesfully!!!\n Check the values in browser console.');
        console.table(this.registerForm.value);
      }
    }
  /*onSubmit () {
    //alert(JSON.stringify(this.form.value))
   if (this.form.value.clientid == "test" && this.form.value.pwd == "test")
    {
      console.log('Clientid and password is correct');
    } else {
      alert("Your Company ID Does NOt mach");
      this.show = true;

    }
    //console.log('Username :: ',this.form.value.fname);
  }*/

  onSubmit1(){
    console.log('Register data ');
  }
}

