import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { FormtestRoutingModule } from './formtest-routing.module';
import { FormtestComponent } from './formtest.component';


@NgModule({
  declarations: [FormtestComponent],
  imports: [
    CommonModule,
    FormtestRoutingModule,
    FormsModule,
    ReactiveFormsModule

  ]
})
export class FormtestModule { }
