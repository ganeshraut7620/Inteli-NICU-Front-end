import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AmcstatusComponent } from './amcstatus.component';

const routes: Routes = [
  {
    path:'' ,
    component:AmcstatusComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AmcstatusRoutingModule { }
