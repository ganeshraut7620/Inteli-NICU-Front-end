import { Component, OnInit } from '@angular/core';
import { MainserviceService } from '../mainservice.service';
import swal from 'sweetalert2';
import { FormGroup, FormControl, Validators, RequiredValidator,FormBuilder  } from '@angular/forms';
@Component({
  selector: 'app-amcstatus',
  templateUrl: './amcstatus.component.html',
  styleUrls: ['./amcstatus.component.css']
})
export class AmcstatusComponent implements OnInit {
  page = 1;
  filterArray:any;
  amc_details:any;
  msg: string;


  constructor(private mainserviceService: MainserviceService) {
    this.amcstatusdetails();
   }

  ngOnInit(): void {
  }

  _searchTerm: string;
    get searchTerm(): string {
        return this._searchTerm;
    }
    set searchTerm(val: string) {
        this._searchTerm = val;
        this.filterArray = this.filter(val);
    }

    filter(v: string) {
        return this.amc_details.filter(x =>  x.machinename.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.clientname.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.sitecode.toLowerCase().indexOf(v.toLowerCase()) !== -1);
    }



  amcstatusdetails() {
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    console.log("userdata=>",userData)
    let data = {
      "amcmasterid": null,
      "clientid": userData.clientid ? userData.clientid : null,
      "machineid": null
    }
    this.mainserviceService.getamc(data).subscribe((res) => {
      if(res.status_code == 's_407') {
        this.filterArray = res.data;
        this.amc_details = res.data;
        console.log("amc details => ",this.amc_details)
      } else if(res.status_code == 's_1015'){
        swal.fire(
          'Bad Job!',
          'An Error Occured Please Contact System Administrator!',
          'error'
        );
      }else if(res.status_code == 's_408'){
        this.msg = "No Record Found";
      }


      }, (err) => {
            console.log(err.error);

    });

  }



}
