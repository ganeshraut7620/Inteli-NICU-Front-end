import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AmcstatusComponent } from './amcstatus.component';

describe('AmcstatusComponent', () => {
  let component: AmcstatusComponent;
  let fixture: ComponentFixture<AmcstatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AmcstatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AmcstatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
