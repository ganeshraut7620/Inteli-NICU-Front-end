import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AmcstatusRoutingModule } from './amcstatus-routing.module';
import { AmcstatusComponent } from './amcstatus.component';


@NgModule({
  declarations: [AmcstatusComponent],
  imports: [
    CommonModule,
    AmcstatusRoutingModule,
    FormsModule,ReactiveFormsModule
  ]
})
export class AmcstatusModule { }
