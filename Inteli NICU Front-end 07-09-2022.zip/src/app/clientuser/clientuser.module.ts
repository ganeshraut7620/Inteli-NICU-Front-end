import {  CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClientuserRoutingModule } from './clientuser-routing.module';
import { ClientuserComponent } from './clientuser.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxSpinnerModule } from "ngx-spinner";


@NgModule({
  declarations: [ClientuserComponent],
  imports: [
    CommonModule,
    ClientuserRoutingModule, FormsModule, ReactiveFormsModule, NgxSpinnerModule
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
})
export class ClientuserModule { }
