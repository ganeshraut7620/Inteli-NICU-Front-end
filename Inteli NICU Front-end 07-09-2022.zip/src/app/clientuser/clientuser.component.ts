import { Component, OnInit } from '@angular/core';
import { Usermaster } from '../mastermanagement/usermaster';
import { FormGroup, FormControl, Validators, RequiredValidator, FormBuilder } from '@angular/forms';

import swal from 'sweetalert2';
import { NgxSpinnerService } from "ngx-spinner";
import { MastermanagementService } from '../mastermanagement/mastermanagement.service';
import { MainserviceService } from '../mainservice.service';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CustomvalidationService } from '../services/customvalidation.service';

@Component({
  selector: 'app-clientuser',
  templateUrl: './clientuser.component.html',
  styleUrls: ['./clientuser.component.css']
})
export class ClientuserComponent implements OnInit {

  page = 1;
  editUser_Details: any = {};
  registerForm: FormGroup;
  submitted = false;
  countrys: any = [];
  states: any = [];
  citys: any = [];
  dummy_country: any;
  categorys: any = { 6: "Location Admin Master", 7: "Control Room Manager Master", 8: "Doctor Master", 9: "Nurse Master" }

  userList: Usermaster[] = this.mastermanagementService.getUsermaster();
  filterArray: any;



  constructor(private mastermanagementService: MastermanagementService, public mainserviceService: MainserviceService, private modalService: NgbModal, private spinner: NgxSpinnerService, private fb: FormBuilder, private customValidator: CustomvalidationService) {

    this.getcountry();
    this.spinner.show();

    // this.filterArray = this.userList;
    setTimeout(() => {
      /** spinner ends after 5 seconds */
      this.spinner.hide();
    }, 1000);

    this.getUserDetails(this.page);
  }

  _searchTerm: string;
  get searchTerm(): string {
    return this._searchTerm;
  }
  set searchTerm(val: string) {
    this._searchTerm = val;
    this.filterArray = this.filter(val);
  }

  filter(v: string) {
    return this.userList.filter(x => x.usermastername.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.emailid.toLowerCase().indexOf(v.toLowerCase()) !== -1);
  }


  ngOnInit(): void {
    this.fromset();
  }

  fromset() {
    this.registerForm = new FormGroup({
      usercategoryid: new FormControl(null, [Validators.required]),
      usermastername: new FormControl(null, [Validators.required]),
      country: new FormControl(null),
      state: new FormControl(null, [Validators.required]),
      city: new FormControl(null, [Validators.required]),
      pincode: new FormControl(null, [Validators.required]),
      emailid: new FormControl(null, [Validators.required, Validators.pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$")]),
      mobilenumber: new FormControl(null, [Validators.required]),
      username: new FormControl(null, [Validators.required]),
      password: new FormControl(null, [Validators.compose([Validators.required, this.customValidator.patternValidator()])])
    });
  }

  changecat($event) { }

  changecity(id) {

    return new Promise((resolve, reject) => {
      let data = {
        "districtid": null,
        "stateid": id,
        "page": 1,
        "pagesize": 10000
      }
      this.mainserviceService.getdist(data).subscribe((res) => {
        this.citys = res.data;
        resolve(true);
      }, (err) => {

      });
    });
  }

  changestate() {
    return new Promise((resolve, reject) => {
      let data = {
        "countryid": this.registerForm.value.country,
        "stateid": null,
        "page": 1,
        "pagesize": 10000
      }

      if (this.states.length > 0) {
        resolve(true);
      } else {
        this.mainserviceService.getstate(data).subscribe((res) => {
          this.states = res.data;
          resolve(true);
        }, (err) => {

        });
      }
    })
  }

  getcountry() {
    return new Promise((resolve, reject) => {
      let data = {
        "countryid": null,
        "page": 1,
        "pagesize": 10000
      }

      if (this.countrys.length > 0) {
        this.changestate().then((res) => {
          resolve(true);
        });
      } else {
        this.mainserviceService.getcountry(data).subscribe((res) => {
          this.countrys = res.data;
          this.registerForm.value.country = res.data[0].countryid;
          this.dummy_country = res.data[0].countryid;
          this.changestate().then((res) => {
            resolve(true);
          });

        }, (err) => {

        });
      }
    })
  }



  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;

    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }

    if (event.keyCode === 32) {
      return false;
    }
  }


  get registerFormControl() {
    return this.registerForm.controls;
  }

  openLg(content1) {
    this.submitted = false;

    this.getcountry();
    this.fromset();

    this.modalService.open(content1, { size: 'lg' });
  }

  //
  onSubmit() {
    try {
      if (this.registerForm.valid) {
        this.submitted = false;
        var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
        this.registerForm.value.usercategoryid = Number(this.registerForm.value.usercategoryid);

        this.registerForm.value.usersubcategoryid = 5;
        this.registerForm.value.country = this.dummy_country;
        this.registerForm.value.submasterid = userData.usermasterid;
        this.registerForm.value.clientid = userData.prefix.toUpperCase().trim() == 'CMA' ? userData.usermasterid : null;
        this.registerForm.value.address = "---";
        this.registerForm.value.logo = "---";
        this.registerForm.value.hallsrange = 1;
        this.registerForm.value.roomsrange =  9;

        console.log("client register form value===============",this.registerForm.value);


        this.mainserviceService.createUser(this.registerForm.value).subscribe((res) => {
          if (res.statusCod == 400) {
            swal.fire(
              'error',
              res.message,

            );
          }

          if (res.status_code == "s_402") {
            swal.fire(
              'Good job!',
              'User Added Succsefully!',
              'success'
            );
            this.getUserDetails(this.page);
          } else if (res.status_code == "s_430") {
            swal.fire(
              'Bad Response!',
              'Username or Password Already in System!',
              'error'
            );
          } else if (res.status_code == "s_1015") {
            swal.fire(
              'Bad Response!',
              'An Error Occured, Please Contact System Administrator!',
              'error'
            );
          }

          this.fromset();

        }, (err) => {
          console.log("err=========================",err);
        });
      } else {
        this.submitted = true;
      }
    } catch (onsubimitErr) {
      console.log("err=========================",onsubimitErr);
    }

  }


  onUpdate() {

    this.editUser_Details.country = null;
    this.editUser_Details.state = null;
    this.editUser_Details.city = null;

    this.editUser_Details.password = null;
    this.editUser_Details.usersubcategoryid = null;
    this.editUser_Details.submasterid = null;

    delete this.editUser_Details['countryid'];
    delete this.editUser_Details['countryname'];
    delete this.editUser_Details['stateid'];
    delete this.editUser_Details['statename'];
    delete this.editUser_Details['cityid'];
    delete this.editUser_Details['cityname'];
    delete this.editUser_Details['usercategoryid'];
    delete this.editUser_Details['usercategoryname'];
    delete this.editUser_Details['prefix'];

    this.editUser_Details.isactive = true;


    this.mainserviceService.updateUser(this.editUser_Details).subscribe((res) => {

      if (res.statusCod == 400) {
        swal.fire(
          'error',
          res.message,

        );
      }
      if (res.status_code == "s_403") {
        swal.fire(
          'Good job!',
          'User Updated Succsefully!',
          'success'
        );
        this.getUserDetails(this.page);

      } else if (res.status_code == "s_1015") {
        swal.fire(
          'Bad Response!',
          'An Error Occured, Please Contact System Administrator!',
          'error'
        );
      } else {
        swal.fire(
          'Something Wrong!',
          'Call System Admin!',
          'error'
        );
      }
      this.getUserDetails(this.page)

    }, (err) => {

    });
    this.closeBtnClick();
  }


  openModal(targetModal, usermaster) {
    this.modalService.open(targetModal, {
      centered: true,
      backdrop: 'static',
      size: 'lg'
    })
    this.getcountry().then((res) => {
      this.changecity(usermaster.stateid).then((res) => {
        this.editUser_Details = usermaster;
      });
    });
    // this.changestate();


  }

  closeBtnClick() {

    this.modalService.dismissAll()

  }

  getUserDetails(page) {
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));

    let dummy_data = {
      "usercategoryid": null,
      "usersubcategoryid": 5,
      "submasterid": userData.usermasterid,
      "page": 1,
      "pagesize": 7
    }
    this.mainserviceService.getUser(dummy_data).subscribe((res) => {
      this.filterArray = res.data;
      this.userList = res.data;
    }, (err) => {

    });
  }

  previous() {
    if (this.page >= 2) {
      this.page = this.page - 1;
      this.getUserDetails(this.page);
    } else {

    }
  }

  next() {
    this.page = this.page + 1;
    this.getUserDetails(this.page)
  }



}
