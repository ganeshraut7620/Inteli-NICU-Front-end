import { Component, OnInit } from '@angular/core';
import swal from 'sweetalert2';
import { FormGroup, FormControl, Validators, RequiredValidator,FormBuilder  } from '@angular/forms';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { MainserviceService } from '../mainservice.service';
@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.css']
})
export class LocationComponent implements OnInit {
  registerForm: FormGroup;
  submitted: boolean;
  LocationDetails:any;

  constructor(private mainserviceService: MainserviceService ,private modalService: NgbModal,private fb: FormBuilder) {
    this.getlocationdetails();
  }

  _searchTerm: string;
  get searchTerm(): string {
      return this._searchTerm;
  }
  set searchTerm(val: string) {
      this._searchTerm = val;
      // this.filterArray = this.filter(val);
  }

  filter(v: string) {
      // return this.machineList.filter(x => x.machinename.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.machinemodelno.toLowerCase().indexOf(v.toLowerCase()) !== -1);
  }

  get registerFormControl() {
    return this.registerForm.controls;
  }

  openLg(content1) {
		this.modalService.open(content1, { size: 'lg' });
  }


  open1(content1) {
		this.modalService.open(content1, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
			//this.closeResult = `Closed with: ${result}`;
		}, (reason) => {
			//this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
		});
  }

  ngOnInit(): void {

    this.registerForm = this.fb.group({
      locationname:['',Validators.required],

    }
    );
  }

  onSubmit() {
    this.submitted = true;

    if (this.registerForm.valid) {
     console.log("Location Details =>",this.registerForm.value);

     var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
     console.log( "session storage value => ",userData);

     let location = {
        "clientid": userData.usermasterid ,
        "location": [
          {
            "locationname": this.registerForm.value.locationname
          }
        ],
        "usercategoryid": userData.usercategoryid
      }

      this.mainserviceService.createlocation(location).subscribe((res) => {
        // console.log("Location added Succesfully ? ",res);

        if(res.status_code == "s_435"){
          swal.fire(
            'Good job!',
            'Location Added Succsefully!',
            'success'
          );
        }else if(res.status_code == "s_1015"){
          swal.fire(
            'Something Wrong In Server Side?',
            'unsuccessfully'
          );
        }



      }, (err) => {
        console.log(err.error);
        swal.fire(
          // 'Good job!',
          err.error,
          'error'
        )
      });

     this.closeBtnClick();



    }

  }

  getlocationdetails(){
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
     console.log( "session storage value => ",userData);

    let obj = {
      "clientid": userData.usermasterid,
      "locationid": null,
      "usercategoryid": null,
      "page": 1,
      "pagesize": 7
    }

    this.mainserviceService.getlocation(obj).subscribe((res) => {
      console.log("Location Details Res => ",res);
      if(res.status_code == "s_407"){
        this.LocationDetails = res.data[0].location;
        console.log("Location Details =>",this.LocationDetails);

      }
    });

  }

  closeBtnClick() {
    this.modalService.dismissAll()
    this.ngOnInit();

}

}
