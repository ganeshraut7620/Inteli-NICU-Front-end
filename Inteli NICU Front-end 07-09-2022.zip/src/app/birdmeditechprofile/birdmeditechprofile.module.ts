import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BirdmeditechprofileRoutingModule } from './birdmeditechprofile-routing.module';
import { BirdmeditechprofileComponent } from './birdmeditechprofile.component';


@NgModule({
  declarations: [BirdmeditechprofileComponent],
  imports: [
    CommonModule,
    BirdmeditechprofileRoutingModule
  ]
})
export class BirdmeditechprofileModule { }
