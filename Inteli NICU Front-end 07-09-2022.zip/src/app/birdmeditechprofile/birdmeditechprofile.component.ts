import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-birdmeditechprofile',
  templateUrl: './birdmeditechprofile.component.html',
  styleUrls: ['./birdmeditechprofile.component.css']
})
export class BirdmeditechprofileComponent implements OnInit {
  userData:any;
  constructor() {
    this.userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    console.log( "session storage value => ",this.userData);
   }

  ngOnInit(): void {
  }

}
