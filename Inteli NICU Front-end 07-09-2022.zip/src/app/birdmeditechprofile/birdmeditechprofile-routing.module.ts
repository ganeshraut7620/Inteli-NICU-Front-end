import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BirdmeditechprofileComponent } from './birdmeditechprofile.component';

const routes: Routes = [
  {
    path: '' , component:BirdmeditechprofileComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BirdmeditechprofileRoutingModule { }
