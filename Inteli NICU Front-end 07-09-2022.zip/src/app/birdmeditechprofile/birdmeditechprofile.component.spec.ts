import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BirdmeditechprofileComponent } from './birdmeditechprofile.component';

describe('BirdmeditechprofileComponent', () => {
  let component: BirdmeditechprofileComponent;
  let fixture: ComponentFixture<BirdmeditechprofileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BirdmeditechprofileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BirdmeditechprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
