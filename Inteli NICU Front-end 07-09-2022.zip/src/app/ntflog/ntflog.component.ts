import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ntflog',
  templateUrl: './ntflog.component.html',
  styleUrls: ['./ntflog.component.css']
})
export class NtflogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
