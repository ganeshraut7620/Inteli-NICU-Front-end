import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NtflogRoutingModule } from './ntflog-routing.module';
import { NtflogComponent } from './ntflog.component';


@NgModule({
  declarations: [NtflogComponent],
  imports: [
    CommonModule,
    NtflogRoutingModule
  ]
})
export class NtflogModule { }
