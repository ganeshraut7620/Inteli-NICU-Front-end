export class Clientmaster {
  public usermasterid:Number;
  public usermastername:String;
  public prefix:String;
  public emailid:String;
  public hospitalname:String;
  public city:String;
  public state:String;
  public clientcode:String;
  public clientid:Number;
  public machineid:Number;
  }

/*
 "hospitalname": "string",
  "city": "string",
  "state": "string",
  "clientcode": "string",
  "clientid": 0,
  "machineid": 0,
  "isactive": true,
*/
