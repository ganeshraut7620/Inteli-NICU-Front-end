import { Clientmaster } from './clientmaster';

export const clientmaster:Clientmaster[] = [
]
