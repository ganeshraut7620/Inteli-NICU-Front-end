import { Component, OnInit } from '@angular/core';
import swal from 'sweetalert2';
import { FormGroup, FormControl, Validators, RequiredValidator, FormBuilder } from '@angular/forms';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CustomvalidationService } from '../services/customvalidation.service';
import { MainserviceService } from '../mainservice.service';
import { ClientmasterService } from './clientmaster.service';
import { Clientmaster } from './clientmaster';
import { NgxSpinnerService } from "ngx-spinner";
// import * as AWS from 'aws-sdk';
// import * as AWS from 'aws-sdk';

@Component({
  selector: 'app-clientmaster',
  templateUrl: './clientmaster.component.html',
  styleUrls: ['./clientmaster.component.css']
})
export class ClientmasterComponent implements OnInit {

  page = 1;
  pageSize = 7;
  hallsrange = 1;
  roomsrange = 1;

  countrys: any;
  states: any;
  citys: any;
  machineList: any;

  //machineList: Machinemaster[] = this.machinemasterservice.getMachinemaster();
  clientList: Clientmaster[] = this.clientmasterservice.getClientmaster();


  filterArray: Clientmaster[];
  respose_catch: any;

  selectedFiles: FileList;
  image_path1 = '';
  file;
  uploadflag: boolean;

  constructor(private spinner: NgxSpinnerService, private mainserviceService: MainserviceService, private clientmasterservice: ClientmasterService, private modalService: NgbModal, private fb: FormBuilder, private customValidator: CustomvalidationService) {
    //this.filterArray = this.clientList;
    this.spinner.show();

    setTimeout(() => {
      /** spinner ends after 5 seconds */
      this.spinner.hide();
    }, 1000);
    this.getcountry();
    this.getClientMasterDetails(this.page);
  }

  registerForm: FormGroup;
  show: boolean = false;
  submitted = false;
  editclientmaster: any;

  ngOnInit(): void {
    this.commonform();
  }

  commonform = () => {
    this.registerForm = new FormGroup({

      usermastername: new FormControl(null, [Validators.required]),
      country: new FormControl(null, [Validators.required]),
      state: new FormControl(null, [Validators.required]),
      city: new FormControl(null, [Validators.required]),
      pincode: new FormControl(null, [Validators.required]),
      address: new FormControl(null, [Validators.required]),
      hallsrange: new FormControl(1, [Validators.required]),
      roomsrange: new FormControl(9, [Validators.required]),
      logo: new FormControl(null, [Validators.required]),
      emailid: new FormControl(null, [Validators.required, Validators.pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$")]),
      contactpersonname: new FormControl(null, [Validators.required]),
      landlineno: new FormControl(null, [Validators.required]),
      mobilenumber: new FormControl(null, [Validators.required]),
      username: new FormControl(null, [Validators.required]),
      password: new FormControl(null, [Validators.compose([Validators.required, this.customValidator.patternValidator()])])
    });
  }

  selecthallrange() {
    try {
      console.log("range", this.registerForm.value.hallsrange);
      this.hallsrange = this.registerForm.value.hallsrange
    } catch (err) {
      console.log("err=============================", err)
    }
  }

  selectroomrange() {
    try {
      console.log("range", this.registerForm.value.roomsrange);
      this.roomsrange = this.registerForm.value.roomsrange
    } catch (err) {
      console.log("err=============================", err)
    }
  }

  changecity() {

    console.log(this.registerForm.value.state);
    let data = {
      "districtid": null,
      "stateid": this.registerForm.value.state,
      "page": 1,
      "pagesize": 100000
    }

    this.mainserviceService.getdist(data).subscribe((res) => {
      console.log("District res =>", res);
      this.citys = res.data;
      console.log("District detals => ", this.citys);

    }, (err) => {
      console.log(err.error);

    });

  }

  changestate() {
    console.log(this.registerForm.value.country);
    let data = {
      "countryid": this.registerForm.value.country,
      "stateid": null,
      "page": 1,
      "pagesize": 10000
    }

    this.mainserviceService.getstate(data).subscribe((res) => {
      console.log("statre res =>", res);
      this.states = res.data;
      console.log("state detals => ", this.states);

    }, (err) => {
      console.log(err.error);

    });
  }

  getcountry() {
    let data = {
      "countryid": null,
      "page": 1,
      "pagesize": 100000
    }

    this.mainserviceService.getcountry(data).subscribe((res) => {
      console.log("country res =>", res);

      if (res.status_code = "s_407") {
        this.countrys = res.data;
        this.changestate();
        console.log("country detals => ", this.countrys);
        //return res.data;
      }


    }, (err) => {
      console.log(err.error);

    });
  }

  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;

    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }

    if (event.keyCode === 32) {
      return false;
    }
  }



  _searchTerm: string;
  get searchTerm(): string {
    return this._searchTerm;
  }
  set searchTerm(val: string) {
    this._searchTerm = val;
    this.filterArray = this.filter(val);
  }

  filter(v: string) {
    return this.clientList.filter(x => x.usermastername.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.emailid.toLowerCase().indexOf(v.toLowerCase()) !== -1);
  }

  open1(content1) {
    this.modalService.open(content1, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      //this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      //this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }




  get registerFormControl() {
    return this.registerForm.controls;
  }

  openLg(content1) {
    this.commonform();
    this.modalService.open(content1, { size: 'lg' });
  }

  changecountry($event) { }

  openModal(targetModal, clientmaster) {
    this.modalService.open(targetModal, {
      centered: true,
      backdrop: 'static',
      size: 'lg'
    })
    console.log(clientmaster);
    this.editclientmaster = clientmaster;
  }
  openModal1(targetModal, clientmaster) {
    this.modalService.open(targetModal, {
      centered: true,
      backdrop: 'static',
      size: 'lg'
    })
    //console.log(machinemaster);
    //this.editmachinemaster = machinemaster;
  }

  previous() {
    if (this.page >= 2) {
      this.page = this.page - 1;
      console.log("decriment => ", this.page)

    } else {

    }
  }

  next() {
    this.page = this.page + 1;
    console.log("Incriment => ", this.page)

  }


  onUpdate() {
    console.log("Client Master Details =>", this.editclientmaster);
    this.editclientmaster.country = null;
    this.editclientmaster.state = null;
    this.editclientmaster.city = null;

    this.editclientmaster.password = null;
    this.editclientmaster.usersubcategoryid = null;
    this.editclientmaster.submasterid = null;

    delete this.editclientmaster['countryid'];
    delete this.editclientmaster['countryname'];
    delete this.editclientmaster['stateid'];
    delete this.editclientmaster['statename'];
    delete this.editclientmaster['cityid'];
    delete this.editclientmaster['cityname'];
    delete this.editclientmaster['usercategoryid'];
    delete this.editclientmaster['usercategoryname'];
    delete this.editclientmaster['prefix'];

    this.editclientmaster.isactive = true;


    this.mainserviceService.updateUser(this.editclientmaster).subscribe((res) => {
      console.log("Update Response => ", res);

      if (res.status_code == "s_403") {

        this.getClientMasterDetails(this.page);

      } else {
        swal.fire(
          // 'Good job!',
          'Something Wrong?',
          'error'
        )
      }

      this.getClientMasterDetails(this.page);

    }, (err) => {
      console.log(err.error);

    });
    this.closeBtnClick();


    // this.editclientmaster.isactive =true;
    // delete this.editclientmaster['clientcode'];
    // delete this.editclientmaster['createdby'];
    // delete this.editclientmaster['createddate'];
    // delete this.editclientmaster['lastmodifiedby'];
    // delete this.editclientmaster['lastmodifieddate'];
    // this.mainserviceService.updateClient(this.editclientmaster).subscribe((data) => {
    //     console.log(data);
    //     this.respose_catch = data;
    //     console.log(this.respose_catch.status_code);
    //     if(this.respose_catch.status_code == "s_403"){
    //       swal.fire(
    //               'Good job!',
    //               'Client Updated Succsefully!',
    //               'success'
    //             );
    //         this.getClientMasterDetails();
    //     }

    //   }, (err) => {
    //     console.log(err.error);
    //     swal.fire(
    //       // 'Good job!',
    //       err.error,
    //       'error'
    //     )
    //   });
    //   this.closeBtnClick();
  }

  onDelete(clientid) {
    console.log(clientid);
    let data = {
      "clientid": clientid
    }
    const swalWithBootstrapButtons = swal.mixin({
      customClass: {
        confirmButton: 'btn btn-success',
        cancelButton: 'btn btn-danger'
      },
      buttonsStyling: false
    })

    swalWithBootstrapButtons.fire({
      title: 'Are you sure,you want to delete it?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, cancel!',
      reverseButtons: true
    }).then((result) => {
      if (result.isConfirmed) {
        this.mainserviceService.deleteClient(data).subscribe((data) => {
          console.log(data);
          this.getClientMasterDetails(this.page);
          swalWithBootstrapButtons.fire(
            'Deleted!',
            'Client has been deleted.',
            'success'
          )


        }, (err) => {
          console.log(err.error);
          swal.fire(
            // 'Good job!',
            err.error,
            'error'
          )
        })



      } else if (
        /* Read more about handling dismissals below */
        result.dismiss === swal.DismissReason.cancel
      ) {
        swalWithBootstrapButtons.fire(
          'Cancelled',
          'Client is safe.',
          'error'
        )
      }
    })
  }

  getClientMasterDetails(page) {
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    console.log("session storage value => ", userData);

    let dummy_data = {
      "usercategoryid": 5,
      "usersubcategoryid": 2,
      "submasterid": userData.usermasterid,
      "page": page,
      "pagesize": 5
    }

    this.mainserviceService.getUser(dummy_data).subscribe((res) => {
      this.filterArray = res.data;
      this.clientList = res.data;

      console.log("Get Client =>", res);
    }, (err) => {
      console.log(err.error);
    });

  }


  onSubmit() {
    try {
      if (this.registerForm.valid) {
        this.submitted = false;
        var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
        // console.log("session storage value => ", userData);
        this.registerForm.value.usercategoryid = 5;
        this.registerForm.value.location = null;
        this.registerForm.value.usersubcategoryid = 2;
        this.registerForm.value.submasterid = userData.usermasterid;

        // console.log("Register Form => ", this.registerForm.value,this.hallsrange,this.roomsrange);
        this.mainserviceService.createUser(this.registerForm.value).subscribe((data) => {
          console.log("client master response  => ", data);
          this.respose_catch = data;
          console.log(this.respose_catch.status_code);

          if (this.respose_catch.status_code == "s_405") {
            swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: 'Record already exist!',

            })

          } else if (this.respose_catch.status_code == "s_402") {
            swal.fire(
              'Good job!',
              'Client Added Succsefully!',
              'success'
            );
            this.getClientMasterDetails(this.page);

            this.closeBtnClick();

          } else if (this.respose_catch.status_code == "s_414") {
            swal.fire(
              'Something Wrong!',
              'error'

            )
          } else if (this.respose_catch.status_code == "s_430") {
            swal.fire(
              'Bad Response!',
              'Username or Password Already in System!',
              'error'
            );
          } else if (this.respose_catch.status_code == "s_1015") {
            swal.fire(
              'Bad Response!',
              'An Error Occured, Please Contact System Administrator!',
              'error'
            );
          }

        }, (err) => {
          console.log(err.error);
          swal.fire(
            'Server Request Time Out!',
            err.error,
            'error'

          )
        });
        this.commonform();
      }

    } catch (err) {

    }

  }

  closeBtnClick() {
    this.modalService.dismissAll()
    this.ngOnInit();
  }


  // uploadFile = (file) => {

  //   const contentType = file.type;
  //   const bucket = new AWS.S3(
  //     {
  //       accessKeyId: 'AKIA4BIJFGWNBHZZTWEU',
  //       secretAccessKey: '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',
  //       region: 'ap-south-1'
  //     }
  //   );

  //   const params = {
  //     Bucket: 'app-udrproduct',
  //     Key: file.name,
  //     Body: file,
  //     ACL: 'public-read',
  //     ContentType: contentType
  //   };
  //   bucket.upload(params, function (err, data) {
  //     if (err) {
  //       console.log('There was an error uploading your file: ', err);
  //       return data;
  //     }

  //     console.log("data => ", data);

  //   });

  //   // setTimeout(() => {
  //   //   this.registerflag = false;
  //   // }, 10000)


  // }

  // upload() {
  //   const file = this.selectedFiles.item(0);
  //   this.file = file;
  //   console.log("File details => ", file);
  //   this.uploadFile(file)
  // }

  // selectFile(event) {
  //   this.selectedFiles = event.target.files;
  //   this.uploadflag = true;
  // }

}
