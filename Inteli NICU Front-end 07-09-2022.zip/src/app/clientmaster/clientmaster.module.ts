import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { ClientmasterRoutingModule } from './clientmaster-routing.module';
import { ClientmasterComponent } from './clientmaster.component';
import { NgxSpinnerModule } from "ngx-spinner";

@NgModule({
  declarations: [ClientmasterComponent],
  imports: [
    CommonModule,
    ClientmasterRoutingModule,
    FormsModule,
    NgxSpinnerModule,
    ReactiveFormsModule
  ]
})
export class ClientmasterModule { }
