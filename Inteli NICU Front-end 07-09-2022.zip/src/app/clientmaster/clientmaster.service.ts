import { Injectable } from '@angular/core';
import { Clientmaster } from './clientmaster';
import { clientmaster } from './clientmaster-data';

@Injectable({
  providedIn: 'root'
})
export class ClientmasterService {

  public clientmaster: Clientmaster[] = clientmaster;

    public getClientmaster() {
        return this.clientmaster;
    }
}
