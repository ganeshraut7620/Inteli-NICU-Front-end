import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, RequiredValidator, FormBuilder } from '@angular/forms';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import swal from 'sweetalert2';
import { MainserviceService } from '../mainservice.service';
import { MedicinemasterService } from './medicinemaster.service';
import { Medicinemaster } from './medicinemaster';
import * as moment from 'moment';
@Component({
  selector: 'app-medicinemaster',
  templateUrl: './medicinemaster.component.html',
  styleUrls: ['./medicinemaster.component.css']
})
export class MedicinemasterComponent implements OnInit {
  registerForm: FormGroup;
  // machine:any = ['Machine-12','Machine-13','Machine-14'];
  categorys: any = [];
  drugs: any = [];
  whens: any = [];
  hows: any = [];
  frequencys: any = [];
  dosgaeunits: any;
  babys: any;
  submitted = false;
  page = 1;

  babyid: any = 'Babay-12';
  cat: any;
  drugname: any = 'Adenosine (3 mg/ml';
  when: any = "Po";
  how: any = "BID";
  fre: any = 'Ac';
  dosage: any = 1;
  dosageunit: any = 'cc - cubic centimeter';
  formdate: any;
  todate: any;

  medicineList: Medicinemaster[] = this.medicinemasterService.getMedicinemaster();
  filterArray: any;
  medicinefilter: medicinefilter = new medicinefilter();
  g_report: generate_report = new generate_report();
  babyList: any = [];
  doctorList: any = [];
  downloadbtnvisible:boolean = false;
  generatereportbtn:boolean = true;
  medicinereportawspath:String = '';


  constructor(private medicinemasterService: MedicinemasterService, private fb: FormBuilder, private modalService: NgbModal, private mainserviceService: MainserviceService) {
    // this.getbabaydetails();
    this.getDutyDoctor();
    this.getcategory();
    this.getbabyid();
    this.getwhenmasterdetails();
    this.gethowmasterdetails();
    this.getfreqdetails();
    this.getdosageunitdetails();
    this.getmedicinemasterdetails();
  }

  medicinefilter_submit() {

  }


  _searchTerm: string;

  get searchTerm(): string {
    return this._searchTerm;
  }

  set searchTerm(val: string) {
    this._searchTerm = val;
    this.filterArray = this.filter(val);
  }

  filter(v: string) {
    return this.medicineList.filter(x => x.babyname.toLowerCase().indexOf(v.toLowerCase()) !== -1);
  }

  closeBtnClick() {
    this.modalService.dismissAll()
    this.ngOnInit();
  }

  get registerFormControl() {
    return this.registerForm.controls;
  }



  openModal(targetModal) {
    this.modalService.open(targetModal, {
      centered: true,
      backdrop: 'static',
      size: 'lg'
    })
    // console.log(medicine);
    // this.editdutydocter_details = dutydocter;
  }

  ngOnInit(): void {
    this.formset();
    
  }

  formset() {
    this.registerForm = new FormGroup({
      babyid: new FormControl(null, [Validators.required]),
      doctorid: new FormControl(null, [Validators.required]),
      medicinedate: new FormControl(null, [Validators.required]),
      categoryid: new FormControl(null, [Validators.required]),
      drugid: new FormControl(null, [Validators.required]),
      when: new FormControl(null, [Validators.required]),
      how: new FormControl(null, [Validators.required]),
      frequency: new FormControl(null, [Validators.required]),
      dosage: new FormControl(null, [Validators.required]),
      dosageunit: new FormControl(null, [Validators.required]),
    });
  }

  openLg(content1) {
    this.formset();
    this.modalService.open(content1, { size: 'lg' });
  }

  openLg1(content2) {
    this.g_report.babyid = null;
    this.generatereportbtn = false;
    this.downloadbtnvisible =false
    this.medicinereportawspath = '';
    this.modalService.open(content2, { size: 'lg' });
  }
  onSubmit = () => {

    console.log("Medicine Master Form Value => ", this.registerForm.value);
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    if (this.registerForm.valid) {
      this.submitted = false;
      this.registerForm.value.clientid = userData.clientid;
      this.mainserviceService.createmedicinemaster(this.registerForm.value).subscribe((res) => {

        console.log("Medicine Master res =>", res);

        if (res.status_code == "s_405") {
          swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Record already exist!'
          });

        } else if (res.status_code == "s_402") {
          swal.fire(
            'Good job!',
            'Medicine Added Succsefully!',
            'success'
          );

          this.getmedicinemasterdetails()
          this.closeBtnClick()
        } else if (res.status_code == "s_1015") {
          swal.fire(
            'Bad Response!',
            'An Error Occured, Please Contact System Administrator!',
            'error'
          );
        }

      }, (err) => {
        console.log(err.error);

      });


    } else {
      this.submitted = true;
    }
    this.drugs = '';
    this.formset();
    // this.closeBtnClick();
  }

  // getbabaydetails() {


  //   var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
  //   console.log("session storage value => ", userData);

  //   let dummy_data = {
  //     "babyno": null,
  //     "babyname": null,
  //     "machineid": null,
  //     "clientid": userData.clientid,
  //     "isactive": true,
  //     "page": 1,
  //     "pagesize": 100000
  //   }

  //   this.mainserviceService.getbaby(dummy_data).subscribe((res) => {
  //     console.log("Baby Details => ", res.data);
  //     this.babyList = res.data;

  //   }, (err) => {
  //     console.log(err.error);

  //   });

  // }


  onGenerate_report() {
    console.log("Geneate Report => ", this.g_report.babyid);
    this.generatereportbtn = false;

    try{

      if(this.g_report.babyid == null && this.g_report.babyid == undefined){

      }else{

        this.babyid = (this.g_report.babyid == null)? 0: this.g_report.babyid; 
        let dummy_data = {
          "babyid":  Number(this.babyid)
        }
    
        console.log("Baby Id Pass =>",dummy_data);


        this.mainserviceService.getmedcinereport(dummy_data).subscribe((res) => {
          console.log("Medicine Report => ",res,res.data)
          if(res.status){
            this.downloadbtnvisible = true;
            this.medicinereportawspath = res.data[0].awspath;
          }else{
            this.downloadbtnvisible = false;
            this.medicinereportawspath = 'Report is not available';
          }
          //this.BabyList[i].push()

          // if(res.status){
          //     this.BabyList[i].awspath = res.data[0].awspath
          //     this.BabyList[i].awspathfalg = "Download";
          //     console.log("Updated Aws Key=>",this.BabyList);
          // }else{
          //   this.BabyList[i].awspath = null;
          //     this.BabyList[i].awspathfalg = "Report Not available";
          // }
    
        });
      }

    }catch(err){
      console.log(err);
    }
    
    
  }

  btnshow = () =>{
    this.generatereportbtn = true;
    this.medicinereportawspath = '';
  }
  hidedownload(){
    this.downloadbtnvisible = false;
    this.medicinereportawspath = '';
    //this.generatereportbtn = true;
  }
  medfilterchange() {
    console.log("After Value change", this.formdate, this.todate);
    let obj = {
      "medicineid": null,
      "fromdate": this.formdate,
      "todate": this.todate
    }

    this.mainserviceService.getmedicine(obj).subscribe((res) => {

      console.log("Medicine Details =>", res);

      if (res.status_code == "s_407") {
        //this.dosgaeunits = res.data;
        this.medicineList = res.data;
        this.filterArray = res.data;
      }
    }, (err) => {
      console.log(err.error);

    });


  }

  onUpdate = () => {

    swal.fire(
      'Good job!',
      'Medicine Updated Succsefully!',
      'success'
    );

    this.closeBtnClick();
  }

  onchangedrugs() {
    console.log("change value =>", this.registerForm.value.category);
  }

  getcategory() {
    let obj = {
      "medicinecategoryid": null
    }

    this.mainserviceService.getMedicinecategory(obj).subscribe((res) => {
      console.log("Categorys =>", res);
      if (res.status_code == "s_407") {
        this.categorys = res.data;
        this.cat = res.data[0].medicinecategory;
        console.log("Category => ", this.cat);
      }

    }, (err) => {
      console.log(err.error);

    });

  }


  changecatid() {

    console.log("Medicine cat id => ", this.registerForm.value.categoryid)
    let changecategoryid = {
      "drugid": null,
      "medicinecategoryid": this.registerForm.value.categoryid
    }

    this.mainserviceService.getdruglist(changecategoryid).subscribe((res) => {

      console.log("Getdruglist =>", res);

      if (res.status_code == "s_407") {
        this.drugs = res.data;
        //this.cat = res.data[0].medicinecategory;
        console.log("Druglist => ", this.drugs);
      }

    }, (err) => {
      console.log(err.error);

    });

  }


  getbabyid() {
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    let obj = {
      "babyno": null,
      "babyname": null,
      "machineid": null,
      "clientid": userData.clientid,
      "isactive": true,
      "page": 1,
      "pagesize": 100000
    }

    this.mainserviceService.getbabyid(obj).subscribe((res) => {

      console.log("Get baby details =>", res);

      if (res.status_code == "s_402") {
        this.babys = res.data;
        console.log("Get Baby Details => ", res.data);
      }

    }, (err) => {
      console.log(err.error);

    });
  }

  getDutyDoctor() {
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    let dummy_data = {
      "usercategoryid": 8,
      "usersubcategoryid": null,
      "clientid": userData.clientid, 
      "page": 1,
      "pagesize": 100000
    }
    this.mainserviceService.getUser(dummy_data).subscribe((res) => {
      console.log("Duty Doctor Details => ", res.data);
      this.doctorList = res.data;

    }, (err) => {
      console.log(err.error);

    });
  }

  getwhenmasterdetails() {

    let obj = {
      "whenmedicineid": null
    }

    this.mainserviceService.getwhenmaster(obj).subscribe((res) => {

      console.log("Get when data =>", res);

      if (res.status_code == "s_407") {
        this.whens = res.data;

      }

    }, (err) => {
      console.log(err.error);

    });

  }

  gethowmasterdetails() {

    let obj = {
      "howmedicineid": null
    }

    this.mainserviceService.gethowmaster(obj).subscribe((res) => {

      console.log("Get how data =>", res);

      if (res.status_code == "s_407") {
        this.hows = res.data;
      }
    }, (err) => {
      console.log(err.error);

    });

  }

  getfreqdetails() {

    let obj = {
      "frquencymedicineid": null
    }

    this.mainserviceService.getfrequency(obj).subscribe((res) => {

      console.log("Get freq data =>", res);

      if (res.status_code == "s_407") {
        this.frequencys = res.data;
      }
    }, (err) => {
      console.log(err.error);

    });

  }

  getdosageunitdetails() {

    let obj = {
      "dosageunitid": null
    }

    this.mainserviceService.getdosageunit(obj).subscribe((res) => {

      console.log("Get Dosage data =>", res);

      if (res.status_code == "s_407") {
        this.dosgaeunits = res.data;
      }
    }, (err) => {
      console.log(err.error);

    });

  }

  getmedicinemasterdetails() {
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    let obj = {
      "medicineid": null,
      "babyid":null,
      "fromdate": moment(new Date()).subtract(30, 'd').format('YYYY-MM-DD'),
      "todate": moment(new Date()).format('YYYY-MM-DD'),
      "clientid": userData.clientid 
    }
   

    this.mainserviceService.getmedicine(obj).subscribe((res) => {

      console.log("Medicine Details =>", res);

      if (res.status_code == "s_407") {
        //this.dosgaeunits = res.data;
        this.medicineList = res.data;
        this.filterArray = res.data;
      }
    }, (err) => {
      console.log(err.error);

    });
  }

}

class medicinefilter {
  fromdate: String;
  todate: String;
}

class generate_report {
  babyid: Number
}
