import { Medicinemaster } from './medicinemaster';


export const medicinemaster:Medicinemaster[] = [

];
