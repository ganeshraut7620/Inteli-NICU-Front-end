import { Injectable } from '@angular/core';

import { Medicinemaster } from './medicinemaster';
import { medicinemaster } from './medicinemaster-data';

@Injectable({
  providedIn: 'root'
})
export class MedicinemasterService {

  public medicinemaster: Medicinemaster[] = medicinemaster;

  public getMedicinemaster() {
      return this.medicinemaster;
  }

}
