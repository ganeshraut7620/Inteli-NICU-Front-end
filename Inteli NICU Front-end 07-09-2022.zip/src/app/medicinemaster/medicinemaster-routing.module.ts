import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MedicinemasterComponent } from './medicinemaster.component';

const routes: Routes = [
  {
    path:'',component:MedicinemasterComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MedicinemasterRoutingModule { }
