import { TestBed } from '@angular/core/testing';

import { MedicinemasterService } from './medicinemaster.service';

describe('MedicinemasterService', () => {
  let service: MedicinemasterService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MedicinemasterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
