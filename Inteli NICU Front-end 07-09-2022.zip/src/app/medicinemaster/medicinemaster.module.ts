import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { MedicinemasterRoutingModule } from './medicinemaster-routing.module';
import { MedicinemasterComponent } from './medicinemaster.component';


@NgModule({
  declarations: [MedicinemasterComponent],
  imports: [
    CommonModule,FormsModule,ReactiveFormsModule,
    MedicinemasterRoutingModule
  ]
})
export class MedicinemasterModule { }
