export class Medicinemaster {
  public babyname:String;
  public category:String;
  public drugname:String;
  public frequency:String;
  public when:String;
  public how:String;
  public dosage:Number;
  public dosageunit:String;
}
