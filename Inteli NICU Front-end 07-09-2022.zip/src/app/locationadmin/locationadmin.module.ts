import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LocationadminRoutingModule } from './locationadmin-routing.module';
import { LocationadminComponent } from './locationadmin.component';

import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { NgxSpinnerModule } from "ngx-spinner";

@NgModule({
  declarations: [LocationadminComponent],
  imports: [
    CommonModule,
    LocationadminRoutingModule,
    FormsModule,ReactiveFormsModule,
    NgxSpinnerModule
  ]
})
export class LocationadminModule { }
