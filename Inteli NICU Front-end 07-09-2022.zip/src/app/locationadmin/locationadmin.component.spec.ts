import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LocationadminComponent } from './locationadmin.component';

describe('LocationadminComponent', () => {
  let component: LocationadminComponent;
  let fixture: ComponentFixture<LocationadminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LocationadminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LocationadminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
