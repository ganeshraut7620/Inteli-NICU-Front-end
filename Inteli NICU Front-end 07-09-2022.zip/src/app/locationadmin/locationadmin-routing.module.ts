import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LocationadminComponent } from './locationadmin.component';

const routes: Routes = [
  { path: '' , component: LocationadminComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LocationadminRoutingModule { }
