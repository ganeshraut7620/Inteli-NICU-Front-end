import { Component, OnInit } from '@angular/core';
import { Usermaster } from '../mastermanagement/usermaster';
import { FormGroup, FormControl, Validators, RequiredValidator,FormBuilder  } from '@angular/forms';

import swal from 'sweetalert2';
import { NgxSpinnerService } from "ngx-spinner";
import { MastermanagementService } from '../mastermanagement/mastermanagement.service';
import { MainserviceService } from '../mainservice.service';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CustomvalidationService } from '../services/customvalidation.service';
import { usermaster } from '../mastermanagement/usermaster-data';

@Component({
  selector: 'app-locationadmin',
  templateUrl: './locationadmin.component.html',
  styleUrls: ['./locationadmin.component.css']
})
export class LocationadminComponent implements OnInit {
  page = 1;
  
  editUser_Details:any;
  registerForm: FormGroup;
  submitted = false;
  countrys:any;
  states:any;
  citys:any;

  categorys:any = {  7:"Control Room Manager Master",8:"Doctor Master",9:"Nurse Master"}

  userList : Usermaster[] = this.mastermanagementService.getUsermaster();
  filterArray: any;
  dummy_country: any;


  constructor(private mastermanagementService:MastermanagementService,public mainserviceService:MainserviceService ,private modalService: NgbModal,private spinner: NgxSpinnerService,private fb: FormBuilder,private customValidator: CustomvalidationService) {
    //this.filterArray = this.userList;
    if(sessionStorage.getItem('flag') == "true"){
      window.location.reload(true);
      sessionStorage.setItem('flag','false');
    }

    this.spinner.show();
    this.getcountry();

    setTimeout(() => {
      /** spinner ends after 5 seconds */
      this.spinner.hide();
    }, 1000);

    this.getUserDetails(this.page);
   }

   _searchTerm: string;
   get searchTerm(): string {
       return this._searchTerm;
   }
   set searchTerm(val: string) {
       this._searchTerm = val;
       this.filterArray = this.filter(val);
   }

   filter(v: string) {
       return this.userList.filter(x => x.usermastername.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.emailid.toLowerCase().indexOf(v.toLowerCase()) !== -1);
   }



  ngOnInit(): void {
    this.fromset();

  }

  fromset(){
    this.registerForm =  new FormGroup({
      usercategoryid:new FormControl(null,[Validators.required]),
      usermastername:new FormControl(null,[Validators.required]),
      country:new FormControl(null),
      state:new FormControl(null,[Validators.required]),
      city:new FormControl(null,[Validators.required]),
      pincode:new FormControl(null,[Validators.required]),
      emailid:new FormControl(null,[Validators.required, Validators.pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$")]),
      mobilenumber:new FormControl(null,[Validators.required]),
      username:new FormControl(null,[Validators.required]),
      password:new FormControl(null,[Validators.compose([Validators.required, this.customValidator.patternValidator()])])
    });
  }

 

  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;

    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }

    if (event.keyCode === 32 ) {
      return false;
    }
  }


  get registerFormControl() {
    return this.registerForm.controls;
  }

  
  openLg(content1) {
    this.submitted= false;
    
    this.getcountry();
    this.fromset();
		this.modalService.open(content1, { size: 'lg' });
  }

  onSubmit() {

    console.log("Country ID => ",this.registerForm.value.Country);

    if (this.registerForm.valid) {
      this.submitted = false;
      var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
      console.log( "session storage value => ",userData);
      this.registerForm.value.usercategoryid = Number(this.registerForm.value.usercategoryid);

      console.log("user Register Form Details => ", this.registerForm.value);
      this.registerForm.value.usersubcategoryid = 6;
      this.registerForm.value.country = this.dummy_country;
      this.registerForm.value.submasterid = userData.usermasterid;
      this.registerForm.value.clientid = userData && userData.prefix.toUpperCase().trim() == 'CMA' || userData.prefix.toUpperCase().trim() == 'BMA' || userData.prefix.toUpperCase().trim() == 'BCS' || userData.prefix.toUpperCase().trim() == 'BMG' || userData.prefix.toUpperCase().trim() == 'BFE' ? userData.prefix.toUpperCase().trim() == 'CMA' ? userData.usermasterid : null : userData.clientid;

      this.mainserviceService.createUser(this.registerForm.value).subscribe((res) => {
        console.log("User Master Res => ",res);

        if(res.statusCod == 400){
          swal.fire(
            'error',
            res.message,

           );
        }

        if(res.status_code =="s_402"){
          swal.fire(
           'Good job!',
           'User Added Succsefully!',
            'success'
          );
        }else if(res.status_code =="s_430"){
          swal.fire(
            'Bad Response!',
            'Username or Password Already in System!',
             'error'
           );
        }else if(res.status_code =="s_1015"){
          swal.fire(
            'Bad Response!',
            'An Error Occured, Please Contact System Administrator!',
             'error'
           );
        }

       this.getUserDetails(this.page)
        this.closeBtnClick();
        this.registerForm =  new FormGroup({
          usercategoryid:new FormControl(null,[Validators.required]),
          usermastername:new FormControl(null,[Validators.required]),
          country:new FormControl(null,[Validators.required]),
          state:new FormControl(null,[Validators.required]),
          city:new FormControl(null,[Validators.required]),
          pincode:new FormControl(null,[Validators.required]),
          emailid:new FormControl(null,[Validators.required, Validators.pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$")]),
          mobilenumber:new FormControl(null,[Validators.required]),
          username:new FormControl(null,[Validators.required]),
          password:new FormControl(null,[Validators.compose([Validators.required, this.customValidator.patternValidator()])])
        });

        }, (err) => {
              console.log(err.error);

      });
    }else{
      this.submitted = true;
    }
  }

  onUpdate(){

    console.log(this.editUser_Details);

    this.editUser_Details.country = null;
    this.editUser_Details.state = null;
    this.editUser_Details.city = null;

    this.editUser_Details.password =null;
    this.editUser_Details.usersubcategoryid = null;
    this.editUser_Details.submasterid = null;

    delete this.editUser_Details['countryid'];
    delete this.editUser_Details['countryname'];
    delete this.editUser_Details['stateid'];
    delete this.editUser_Details['statename'];
    delete this.editUser_Details['cityid'];
    delete this.editUser_Details['cityname'];
    delete this.editUser_Details['usercategoryid'];
    delete this.editUser_Details['usercategoryname'];
    delete this.editUser_Details['prefix'];

    this.editUser_Details.isactive = true;


   this.mainserviceService.updateUser(this.editUser_Details).subscribe((res) => {
     console.log("Update Response => ",res);

     if(res.status_code == 400){
       swal.fire(
         'error',
         res.message,

        );
     }

     if(res.status_code == "s_403"){
       swal.fire(
         'Good job!',
         'User Updated Succsefully!',
         'success'
       );
       this.getUserDetails(this.page);

     }else if(res.status_code =="s_1015"){
       swal.fire(
         'Bad Response!',
         'An Error Occured, Please Contact System Administrator!',
          'error'
        );
     }else{
       swal.fire(
         'Something Wrong!',
         'Call System Admin!',
          'error'
        );
     }

     this.getUserDetails(this.page);

   }, (err) => {
     console.log(err.error);

   });
   this.closeBtnClick();

  }

  openModal(targetModal, usermaster) {
    this.modalService.open(targetModal, {
        centered: true,
        backdrop: 'static',
        size: 'lg'
    });
    this.getcountry();
    this.changestate();
    this.changecity();
    console.log(usermaster);
    this.editUser_Details = usermaster;

  }

  changecity(){

    console.log(this.registerForm.value.state);
    let data = {
      "districtid": null,
      "stateid": this.registerForm.value.state,
      "page": 1,
      "pagesize": 10000
    }

    this.mainserviceService.getdist(data).subscribe((res) => {
      console.log("District res =>",res);
      this.citys = res.data;
      console.log("District detals => ",this.citys);

      }, (err) => {
            console.log(err.error);

    });

  }

  changestate(){
    console.log(this.registerForm.value.country);
    let data = {
      "countryid": this.registerForm.value.country,
      "stateid": null,
      "page": 1,
      "pagesize": 10000
    }

    this.mainserviceService.getstate(data).subscribe((res) => {
      console.log("statre res =>",res);
      this.states = res.data;
      console.log("state detals => ",this.states);

      }, (err) => {
            console.log(err.error);

    });
  }

  getcountry(){
    let data = {
      "countryid": null,
      "page": 1,
      "pagesize": 10000
    }

    this.mainserviceService.getcountry(data).subscribe((res) => {
      console.log("country res =>",res);
      this.countrys = res.data;
      this.registerForm.value.country = res.data[0].countryid;
      this.dummy_country = res.data[0].countryid;
      this.changestate()
      console.log("country detals => ",this.countrys);

      }, (err) => {
            console.log(err.error);

    });
  }
  closeBtnClick() {
    this.modalService.dismissAll()
    this.ngOnInit();
  }

  getUserDetails(page) {
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    let dummy_data ={
      "usercategoryid": null,
      "usersubcategoryid": null,
      "submasterid": userData.usermasterid,
      "page": page,
      "pagesize": 5
    }
    this.mainserviceService.getUser(dummy_data).subscribe((res) => {
      console.log(res.data);
      this.filterArray = res.data;
      this.userList = res.data;
      }, (err) => {
            console.log(err.error);

    });
  }

  previous(){
    if(this.page>=2){
    this.page = this.page - 1;
    console.log("decriment => ",this.page)
    this.getUserDetails(this.page);
    }else{
  
    }
  }
  
  next(){
    this.page = this.page + 1;
    console.log("Incriment => ",this.page)
    this.getUserDetails(this.page)
  }
}
