import { Component, OnInit } from '@angular/core';
import { MainserviceService } from '../mainservice.service';
@Component({
  selector: 'app-birdmeditechdashboard',
  templateUrl: './birdmeditechdashboard.component.html',
  styleUrls: ['./birdmeditechdashboard.component.css']
})
export class BirdmeditechdashboardComponent implements OnInit {
  msg: string;
  totalcustomerservice:any = '-';
  totalgeneralmanager:any = '-';
  totalfield:any = '-';
  totalclient:any = '-';
  totallocationadmin:any = '';
  totalcontrol:any ='';
  totaldoctor:any ='';
  totalnurse:any = '';

  constructor(public mainserviceService:MainserviceService) {
    if(sessionStorage.getItem('flag') == "true"){
      window.location.reload(true);
      sessionStorage.setItem('flag','false');
    }
    this.getmasterdashboardanalytics();
  }

  ngOnInit(): void {
  }

  getmasterdashboardanalytics(){

    let data = {}

    this.mainserviceService.getmasterdashboard(data).subscribe((res) => {
      console.log("Master Data  =>",res);

      if(res.status_code == 's_407'){
       console.log("data => ",res.data);
       this.totalcustomerservice = res.data[0].totalcount;
       this.totalgeneralmanager = res.data[1].totalcount;
       this.totalfield = res.data[2].totalcount;
       this.totalclient = res.data[3].totalcount;
       this.totallocationadmin = res.data[3].totalcount;
       this.totalcontrol = res.data[3].totalcount;
       this.totaldoctor = res.data[3].totalcount;
       this.totalnurse = res.data[3].totalcount;


      }else if(res.status_code == 's_1015'){

      }else if(res.status_code == 's_408'){
        this.msg = "No Record Found";
      }


      }, (err) => {
            console.log(err.error);

    });
  }

}
