import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BirdmeditechdashboardRoutingModule } from './birdmeditechdashboard-routing.module';
import { BirdmeditechdashboardComponent } from './birdmeditechdashboard.component';


@NgModule({
  declarations: [BirdmeditechdashboardComponent],
  imports: [
    CommonModule,
    BirdmeditechdashboardRoutingModule
  ]
})
export class BirdmeditechdashboardModule { }
