import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BirdmeditechdashboardComponent } from './birdmeditechdashboard.component';

const routes: Routes = [{ path: '',component:BirdmeditechdashboardComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BirdmeditechdashboardRoutingModule { }
