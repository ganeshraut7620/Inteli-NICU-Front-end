import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BirdmeditechdashboardComponent } from './birdmeditechdashboard.component';

describe('BirdmeditechdashboardComponent', () => {
  let component: BirdmeditechdashboardComponent;
  let fixture: ComponentFixture<BirdmeditechdashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BirdmeditechdashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BirdmeditechdashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
