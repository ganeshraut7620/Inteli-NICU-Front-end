import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DutydocterComponent } from './dutydocter.component';

const routes: Routes = [
  { path:'' , component:DutydocterComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DutydocterRoutingModule { }
