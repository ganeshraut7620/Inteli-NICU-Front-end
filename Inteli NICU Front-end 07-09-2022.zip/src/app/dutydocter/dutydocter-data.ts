import { Dutydocter } from './dutydocter';

export const dutydocter: Dutydocter[] = [
   {
     "roasterdate":"2020-11-24 05:30:00",
     "shift":'a',
     "machinename":'warmer second',
     "doctorname":"ganesh",
     "nursename":'nisha'
   }
]

