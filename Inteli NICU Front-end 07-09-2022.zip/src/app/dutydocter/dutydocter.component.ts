import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, RequiredValidator,FormBuilder  } from '@angular/forms';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CustomvalidationService } from '../services/customvalidation.service';
import { DutydocterService } from './dutydocter.service';
import { Dutydocter } from './dutydocter';
import { MainserviceService } from '../mainservice.service';
import * as moment from 'moment';
import { NgxSpinnerService } from "ngx-spinner";

import swal from 'sweetalert2';
import { usermaster } from '../mastermanagement/usermaster-data';

@Component({
  selector: 'app-dutydocter',
  templateUrl: './dutydocter.component.html',
  styleUrls: ['./dutydocter.component.css']
})


export class DutydocterComponent implements OnInit {
  [x: string]: any;

  page = 1;
  machine:any = ['Machine-12','Machine-13','Machine-14'];
  shifts:any = ['A','B','C'];
  clients:any = [1,2,3,4,6,7,8,9,10,11];
  dutydocters:any;
  config: any;
  editnursemaster_details:any;
  filterArray:any;
  respose_catch: any;
  filterdate:any;
  machineList: any;
  doctorList: any;
  nurseList: any;
  nursedata:any;
  DutyRoasterList: Dutydocter[] = this.dutydocterservice.getdutyroaster();
  dutyroster : dutyroster_form = new dutyroster_form();
  fromdate:any;
  todate:any;
  editdutyroaster_details:any;
  validate_date:boolean = false;
  validate_shift:boolean =false;
  validate_doctor:boolean =false;
  validate_nurse:boolean = false;

  constructor(private spinner: NgxSpinnerService,private  mainserviceService: MainserviceService,private modalService: NgbModal,private fb: FormBuilder,
    private customValidator: CustomvalidationService ,private dutydocterservice:DutydocterService) {
      //this.filterArray = this.DutyRoasterList
      //console.log("Duty Roaster Data => ",this.filterArray);
      this.spinner.show();
      this.getmachine();
      this.getNursemaster()
      this.getDutyDoctor();
      this.getdutyroaster()

      setTimeout(() => {
        /** spinner ends after 5 seconds */
        this.spinner.hide();
      }, 1000);

    }




    open1(content1) {
      this.modalService.open(content1, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
        //this.closeResult = `Closed with: ${result}`;
      }, (reason) => {
        //this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      });
    }

    openLg(content1) {
      this.modalService.open(content1, { size: 'lg' });
    }

    show: boolean = false;
    registerForm: FormGroup;
    submitted = false;
    //editdutydocter_details: any;
    _searchTerm: string;

    get searchTerm(): string {
        return this._searchTerm;
    }

    set searchTerm(val: string) {
        this._searchTerm = val;
        this.filterArray = this.filter(val);
    }

    filter(v: string) {
        return this.DutyRoasterList.filter(x => x.shift.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.machinename.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.doctorname.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.nursename.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.machinename.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.doctorname.toLowerCase().indexOf(v.toLowerCase()) !== -1);
    }

  ngOnInit(): void {
    this.registerForm = this.fb.group({
      machineid:[,Validators.required],
      shift:['',Validators.required],
      roasterdate:['',Validators.required],
      doctorid:[,Validators.required],
      nurseid:[,Validators.required],
    });

    //this.sms = this.registerForm.value.sms;
  }

  public machines: any[] = [
    {
    id: 1,
    machineid:Number,
  }];

  addmachines() {
    this.machines.push({
      id: this.machines.length + 1,
      machineid:Number
    });
  }

  get registerFormControl() {
    return this.registerForm.controls;
  }

  openModal(targetModal,dutyroaster) {
    this.modalService.open(targetModal, {
        centered: true,
        backdrop: 'static',
        size: 'lg'
    })
    console.log(dutyroaster);
    this.editdutyroaster_details = dutyroaster;
  }

  openModal1(targetModal,dutydocter) {
    this.modalService.open(targetModal, {
        centered: true,
        backdrop: 'static',
        size: 'lg'
  })

   // console.log(machinemaster);
   //this.editmachinemaster = machinemaster;
  }

deletedutyroaster(dutyroasterid){
  console.log("Roaster Id => ",dutyroasterid )
  let data  ={
     "dutyroasterid":dutyroasterid
  }

 const swalWithBootstrapButtons = swal.mixin({
        customClass: {
          confirmButton: 'btn btn-success',
          cancelButton: 'btn btn-danger'
        },
        buttonsStyling: false
      })

      swalWithBootstrapButtons.fire({
        title: 'Are you sure,you want delete it?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'No, cancel!',
        reverseButtons: true
      }).then((result) => {
        if (result.isConfirmed) {
          this.mainserviceService.deletedutyroaster(data).subscribe((data) => {
            console.log("dutyroaster Delete Succesfuuly");
            this.getdutyroaster()
            swalWithBootstrapButtons.fire(
              'Deleted!',
              'Duty Roaster has been deleted.',
              'success'
            )
          }, (err) => {
            console.log(err.error);
            swal.fire(
              // 'Good job!',
              err.error,
              'error'
            )
          })

        } else if (
          /* Read more about handling dismissals below */
          result.dismiss === swal.DismissReason.cancel
        ) {
          swalWithBootstrapButtons.fire(
            'Cancelled',
            'Duty Roaster is safe.',
            'error'
          )
        }
      })

}
onUpdate(){
  console.log(this.editdutydocter_details);
  this.editdutydocter_details.isactive =true;
  //this.editdutydocter_details.siteid = null;
  delete this.editdutydocter_details['createdby'];
  delete this.editdutydocter_details['createddate'];
  delete this.editdutydocter_details['lastmodifiedby'];
  delete this.editdutydocter_details['lastmodifieddate'];
  this.mainserviceService.updateDutyDoctor(this.editdutydocter_details).subscribe((data) => {
          console.log(data);
          swal.fire(
            'Good job!',
            'Duty Doctor Updated Succsefully!',
            'success'
          );

        }, (err) => {
          console.log(err.error);
          swal.fire(
            // 'Good job!',
            err.error,
            'error'
          )
        });
   // console.log(this.editdutydocter_details);
    this.closeBtnClick();
}

changemachine($event){}
changeclient($event){}



onSubmit() {
    this.submitted = true;

    console.log("Before Register => ",this.dutyroster,this.machines);
    let machine_ids =[];
    machine_ids = [...new Set(this.machines.map(x=>Number(x.machineid)))];


    console.log("Machine Details => ",machine_ids,typeof(machine_ids));

    this.validate_date = (this.dutyroster.date == null || this.dutyroster.date ==undefined )? true :false;
    this.validate_shift = (this.dutyroster.shift == null || this.dutyroster.shift ==undefined )? true :false;
    this.validate_nurse = (this.dutyroster.nurseid == null || this.dutyroster.nurseid ==undefined )? true :false;
    this.validate_doctor = (this.dutyroster.doctorid == null || this.dutyroster.doctorid ==undefined )? true :false;
    if(!this.validate_date && !this.validate_shift && !this.validate_nurse && !this.validate_doctor){
     var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
     console.log( "session storage value => ",userData);
      let obj = {
        "usermasterid":userData.usermasterid,
        "machineid": machine_ids,
        "nurseid": Number(this.dutyroster.nurseid),
        "doctorid": Number(this.dutyroster.doctorid),
        "roasterdate": this.dutyroster.date,
        "shift": this.dutyroster.shift
      }

      console.log("Duty Roaster Form Value => ",obj);
      this.mainserviceService.createdutyroaster(obj).subscribe((data) => {
        console.log("Server Response => ",data);
        this.respose_catch = data;
          console.log(this.respose_catch.status_code);
          if(this.respose_catch.status_code == "s_405"){
            swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: 'Record already exist!'

            })

          }else if(this.respose_catch.status_code == "s_402"){
            swal.fire(
                    'Good job!',
                    'Duty Roaster Added Succsefully!',
                    'success'
                  );

             this.getdutyroaster();
             this.closeBtnClick()
          }else if(this.respose_catch.status_code =="s_1015"){
            swal.fire(
              'Bad Response!',
              'An Error Occured, Please Contact System Administrator!',
               'error'
             );
          }


        }, (err) => {
              console.log(err.error);
              swal.fire(
                // 'Good job!',
                err.error,
                'error'
              )
            });
    }

    // if (this.registerForm.valid) {
    //   console.table("After Data  Validation => ",this.registerForm.value);



    //   //this.dutydocterList.push(this.registerForm.value);
    //   //console.table(this.registerForm.value);
    //   this.closeBtnClick();
    // }

  }


  changedutyroasterdetails(){
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
     console.log( "session storage value => ",userData);
    console.log(this.fromdate,this.todate);
    if((this.fromdate== null || this.fromdate == undefined) || (this.todate== null || this.todate == undefined)){
      console.log("Something wrong!");
    }else{
      let dummy_data ={
        "usermasterid": userData.usermasterid,
        "machineid": null,
        "nurseid": null,
        "doctorid": null,
        "fromdate": this.fromdate,
        "todate": this.todate

      }
      this.mainserviceService.getdutyraoster(dummy_data).subscribe((res) => {
        console.log("After Add Fromdate and Todate => ",res);
        console.log("After Add Fromdate and Todate   =>",res.data);
        this.filterArray = res.data;
        this.DutyRoasterList = res.data;
      }, (err) => {
        console.log(err.error);
      });
    }

    this.fromdate = this.todate = '';

  }

  getdutyroaster(){
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
     console.log( "session storage value => ",userData);

    let dummy_data ={
      "usermasterid": userData.usermasterid,
      "machineid": null,
      "nurseid": null,
      "doctorid": null,
      "fromdate": null,
      "todate": null

    }
    this.mainserviceService.getdutyraoster(dummy_data).subscribe((res) => {
      console.log("Duty roaster Res => ",res);
      console.log("Duty Roaster Details   =>",res.data);
      this.filterArray = res.data;
      this.DutyRoasterList = res.data;

    }, (err) => {
      console.log(err.error);
    });
  }

  getmachine() {
    
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
  console.log( "session storage value => ",userData);

  let dummy_data ={
    "clientid":userData.clientid
  }

  this.mainserviceService.getmachineclientwise(dummy_data).subscribe((res) => {
    this.machineList  =res.data;

  }, (err) => {
    console.log(err.error);
  });
}

  getDutyDoctor() {
  var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
  let dummy_data ={
    "usercategoryid": 8,
    "usersubcategoryid":null,
    "clientid": userData.clientid,
    "page": 1,
    "pagesize": 100000
  }
  this.mainserviceService.getUser(dummy_data).subscribe((res) => {
    console.log("Duty Doctor Details => ",res.data);
    this.doctorList = res.data;

    }, (err) => {
          console.log(err.error);

  });
}
  getNursemaster() {
  var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
  let dummy_data ={
    "usercategoryid": 9,
    "usersubcategoryid": null,
    "clientid": userData.clientid,
    "page": 1,
    "pagesize": 100000
  }

  this.mainserviceService.getUser(dummy_data).subscribe((res) => {
    console.log("Nurse Master Data => ",res.data);
    this.nurseList = res.data;
  }, (err) => {
    console.log(err.error);
  });
}

closeBtnClick() {
    this.modalService.dismissAll()
    this.ngOnInit();
}

keyPress(event: any) {
  const pattern = /[0-9\+\-\ ]/;

  let inputChar = String.fromCharCode(event.charCode);
  if (event.keyCode != 8 && !pattern.test(inputChar)) {
    event.preventDefault();
  }

  if (event.keyCode === 32 ) {
    return false;
  }
}

}

class dutyroster_form {
  machineid:Number;
  date:String;
  shift:String;
  nurseid:Number;
  doctorid:Number;

}

