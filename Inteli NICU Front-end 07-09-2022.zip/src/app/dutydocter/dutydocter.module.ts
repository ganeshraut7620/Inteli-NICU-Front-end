import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {NgbPaginationModule, NgbAlertModule} from '@ng-bootstrap/ng-bootstrap';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { DutydocterRoutingModule } from './dutydocter-routing.module';
import { DutydocterComponent } from './dutydocter.component';
import { NgxSpinnerModule } from "ngx-spinner";

@NgModule({
  declarations: [DutydocterComponent],
  imports: [
    CommonModule,
    DutydocterRoutingModule,
    FormsModule,
    NgxSpinnerModule,
    ReactiveFormsModule,
    NgbPaginationModule,
    NgbAlertModule
  ]
})
export class DutydocterModule { }
