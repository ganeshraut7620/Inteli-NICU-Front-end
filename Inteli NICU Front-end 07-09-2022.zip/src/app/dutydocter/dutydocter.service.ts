import { Injectable } from '@angular/core';

import { Dutydocter } from './dutydocter';
import { dutydocter } from './dutydocter-data';

@Injectable({
  providedIn: 'root'
})
export class DutydocterService {

  public dutydocter: Dutydocter[] = dutydocter;

  public getdutyroaster() {
      return this.dutydocter;
  }
}
