export class Dutydocter {
    public roasterdate:String;
    public shift: String;
    public machinename:String;
    public doctorname:String;
    public nursename:String;
}
