import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DutydocterComponent } from './dutydocter.component';

describe('DutydocterComponent', () => {
  let component: DutydocterComponent;
  let fixture: ComponentFixture<DutydocterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DutydocterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DutydocterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
