import { TestBed } from '@angular/core/testing';

import { DutydocterService } from './dutydocter.service';

describe('DutydocterService', () => {
  let service: DutydocterService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DutydocterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
