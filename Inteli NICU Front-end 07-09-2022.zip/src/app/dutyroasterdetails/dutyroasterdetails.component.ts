import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dutyroasterdetails',
  templateUrl: './dutyroasterdetails.component.html',
  styleUrls: ['./dutyroasterdetails.component.css']
})
export class DutyroasterdetailsComponent implements OnInit {

  machines = ['Machine-12',"Machine-13","Machine14"];
  doctors = ['Ankit','Swapnil','Akshay'];
  nurses = ['Pooja','Nileam','Gita'];
  durations  = ["This Month","This Week","Yesterday","Todays"]
  trendsform : trends_form = new trends_form();

  constructor() { }

  ngOnInit(): void {
  }

  trends_submit(){
    console.log(this.trendsform);
  }

}

class trends_form {
  machinename:String;
  perametername:String;
  duration:String
}
