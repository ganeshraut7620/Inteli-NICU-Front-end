import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DutyroasterdetailsComponent } from './dutyroasterdetails.component';

describe('DutyroasterdetailsComponent', () => {
  let component: DutyroasterdetailsComponent;
  let fixture: ComponentFixture<DutyroasterdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DutyroasterdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DutyroasterdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
