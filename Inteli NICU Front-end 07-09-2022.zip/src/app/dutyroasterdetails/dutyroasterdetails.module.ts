import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { DutyroasterdetailsRoutingModule } from './dutyroasterdetails-routing.module';
import { DutyroasterdetailsComponent } from './dutyroasterdetails.component';


@NgModule({
  declarations: [DutyroasterdetailsComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DutyroasterdetailsRoutingModule
  ]
})
export class DutyroasterdetailsModule { }
