import { Component, OnInit } from '@angular/core';
import { MainserviceService } from '../mainservice.service';
import * as moment from 'moment';
import { ActivatedRoute } from '@angular/router';
import { filter } from 'rxjs/operators';


@Component({
  selector: 'app-dailybabyreport',
  templateUrl: './dailybabyreport.component.html',
  styleUrls: ['./dailybabyreport.component.css']
})
export class DailybabyreportComponent implements OnInit {

  BabyList: any;
  BabyListprint: any;
  myfilename: any;
  fileUrl: any;
  folder_name: any;
  status_flag = false;
  page = 1;
  page_incr = 1;
  filterArray: any;


  constructor(public mainserviceService: MainserviceService, private activatedRoute: ActivatedRoute) {
    //  this.getdailybabyreport();
    this.babyreport();

  }

  _searchTerm: string;
  get searchTerm(): string {
    return this._searchTerm;
  }
  set searchTerm(val: string) {
    this._searchTerm = val;
    this.filterArray = this.filter(val);
  }

  filter(v: string) {
    return this.BabyList.filter(x => x.mothername.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.babyname.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.gender.toLowerCase().indexOf(v.toLowerCase()) !== -1);
  }


  ngOnInit(): void {
    let id = this.activatedRoute.snapshot.params['id'];
    console.log('id==>', id);
    id ? this.getbabydetails(1, id) : this.getbabydetails(1);
  }
  //getbabyid



  getbabydetails(page_incr, id?) {

    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    console.log("session storage value => ", userData);

    let dummy_data = {
      "babyno": null,
      "babyname": null,
      "machineid": null,
      "clientid": userData.clientid,
      "isactive": true,
      "page": 1,
      "pagesize": 40
    }

    this.mainserviceService.getbabyid(dummy_data).subscribe((res) => {
      console.log("Baby Details => ", res.data);
      this.BabyList = res.data;
      this.filterArray = res.data;
      // this.userList = res.data;

      this.BabyListprint = this.genarte_report();
      console.log("Daily Baby Updated Report => ", this.BabyListprint);
      if (id) {
        this.filterArray = this.filterArray.filter(x => x.babyid == id);
      }
    }, (err) => {
      console.log(err.error);

    });


  }

  previous() {
    if (this.page >= 2) {
      this.page = this.page - 1;
      console.log("decriment => ", this.page)
      this.getbabydetails(this.page);
    } else {

    }
  }

  next() {
    this.page = this.page + 1;
    console.log("Incriment => ", this.page)
    this.getbabydetails(this.page);
  }

  genarte_report() {

    for (let i = 0; i < this.BabyList.length; i++) {
      let dummy_data = {
        "machineid": this.BabyList[i].machineid,
        "babyid": this.BabyList[i].babyid,
        "fromdate": moment(new Date()).format('YYYY-MM-DD'),
        "todate": moment(new Date()).format('YYYY-MM-DD')
      }
      console.log("Baby Id Pass =>", dummy_data);
      this.mainserviceService.getdailybabyreport(dummy_data).subscribe((res) => {
        console.log("Dialy Baby Report => ", res, res.data)
        //this.BabyList[i].push()
        if (res.status) {
          this.BabyList[i].awspath = res.data[0].awspath
          this.BabyList[i].awspathfalg = "Download";
          console.log("Updated Aws Key=>", this.BabyList);
        } else {
          this.BabyList[i].awspath = null;
          this.BabyList[i].awspathfalg = "Report Not available";
        }

      });


    }
    return this.BabyList;
  }

  babyreport = () => {
    try {
      let dummy_data = {
        "machineid": 28,
        "babyid": 109,
        "fromdate": moment(new Date()).format('YYYY-MM-DD'),
        "todate": moment(new Date()).format('YYYY-MM-DD')
      }
      console.log("Baby Id Pass =>", dummy_data);
      this.mainserviceService.getdailybabyreport(dummy_data).subscribe((res) => {
        console.log("Dialy Baby Report => ", res, res.data)
      });

    } catch (err) {

    }
  }
}
