import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DailybabyreportComponent } from './dailybabyreport.component';

const routes: Routes = [
  { path: '' ,component:DailybabyreportComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DailybabyreportRoutingModule { }
