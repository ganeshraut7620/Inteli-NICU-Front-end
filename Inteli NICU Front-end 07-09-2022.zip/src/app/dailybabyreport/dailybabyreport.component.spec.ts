import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DailybabyreportComponent } from './dailybabyreport.component';

describe('DailybabyreportComponent', () => {
  let component: DailybabyreportComponent;
  let fixture: ComponentFixture<DailybabyreportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DailybabyreportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DailybabyreportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
