import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { DailybabyreportRoutingModule } from './dailybabyreport-routing.module';
import { DailybabyreportComponent } from './dailybabyreport.component';


@NgModule({
  declarations: [DailybabyreportComponent],
  imports: [
    CommonModule,FormsModule,ReactiveFormsModule,
    DailybabyreportRoutingModule
  ]
})
export class DailybabyreportModule { }
