import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FluidbalancechartComponent} from './fluidbalancechart.component'
const routes: Routes = [
  { path: '', component: FluidbalancechartComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FluidbalancechartRoutingModule { }
