import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, RequiredValidator, FormBuilder } from '@angular/forms';
import swal from 'sweetalert2';
import { MainserviceService } from '../mainservice.service';
import * as moment from 'moment';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { truncateWithEllipsis } from '@amcharts/amcharts4/.internal/core/utils/Utils';
import { MatTabChangeEvent } from '@angular/material/tabs';


@Component({
  selector: 'app-fluidbalancechart',
  templateUrl: './fluidbalancechart.component.html',
  styleUrls: ['./fluidbalancechart.component.css']
})
export class FluidbalancechartComponent implements OnInit {

  view = false;
  BabayList: any[];
  selectedBaby: string = "";
  FeedList = ['EBM', 'Dexolac', 'Enfamil'];
  additiveList = ['Vitamin D', 'Calcium Syrup', 'Iron', 'Vitamin A', 'Others'];
  intervenousList = ['IV Fluid', 'Others'];
  bloodList = ['Whole blood', 'Platelet', 'Packed Cell', 'Plasma']
  NurseList: any[];
  selectedNurse: string = "";
  panelOpenState = false;
  feedtype = "";
  feedvalue;
  additivetype = "";
  additivevalue;
  intervenoustype = "";
  intervenousvalue;
  bloodtype = "";
  bloodvalue;
  vomittype = "";
  vomitvalue;
  urinetype = "";
  urinevalue;

  ivfluidtype ="";
  ivfluidvalue ="";
  inputtotal="";

  gastrictype="";
  stooltype="";
  draintype="";
  gastricvalue="";
  stoolvalue="";
  drainvalue="";
  outputvalue ="";


  date;
  time;

  fluidBalanceList = [];
  range_1;
  fluidBalanceChartList = [];
  
  filterView: boolean = false;
  nurseList: any;
  BabyList: any;
  babyId: number = 0;
  pagedischarge: number = 1;
  pageadmit: number = 1;

  constructor(private mainserviceService: MainserviceService, private modalService: NgbModal) {
    // this.fluidBalanceChartList[0] = [];
    this.range_1 = this.genrateIndexes(0, 100);
    this.date = moment().format('L');
    this.time = moment().format('LTS');
    console.log("user info ==========", JSON.parse(sessionStorage.getItem('userInfo1')));
  }

  resetDateandtime() {
    this.date = moment().format('L');
    this.time = moment().format('LTS');
  }

  ngOnInit(): void {
    this.getbabydetails(1, "admitted");
    this.getNursemaster();


  }

  genrateIndexes = (start, end) => {
    try {
      let arr = [];
      for (let i = start; i <= end; i++) {
        arr.push(i);
      }

      return arr;

    } catch (err) {

    }
  }

  addRow() {
    console.log("row => ", this.feedtype, this.feedvalue, " - ", this.additivetype,
      this.additivevalue, " - ", this.intervenoustype, this.intervenousvalue, " - ", this.bloodtype, this.bloodvalue);
    let obj = {
      ivfluidtype : this.ivfluidtype == undefined ? "-": this.ivfluidtype,
      ivfluidvalue : this.ivfluidvalue == undefined ? "-" : this.ivfluidvalue,
      feedtype: this.feedtype == undefined ? "-" : this.feedtype,
      feedvalue: this.feedvalue == undefined ? "-" : this.feedvalue,

      // additivetype: this.additivetype == undefined ? "-" : this.additivetype,
      // additivevalue: this.additivevalue == undefined ? "-" : this.additivevalue,
      // intervenoustype: this.intervenoustype == undefined ? "-" : this.intervenoustype,
      // intervenousvalue: this.intervenousvalue == undefined ? "-" : this.intervenousvalue,
      bloodtype: this.bloodtype == undefined ? "-" : this.bloodtype,
      bloodvalue: this.bloodvalue == undefined ? "-" : this.bloodvalue,
      // vomittype: this.vomittype == undefined ? "-" : this.vomittype,
      // vomitvalue: this.vomitvalue == undefined ? "-" : this.vomitvalue,
      urinetype: this.urinetype == undefined ? "-" : this.urinetype,
      urinevalue: this.urinevalue == undefined ? "-" : this.urinevalue,
      gastrictype : this.gastrictype ==undefined ? "-" : this.gastrictype,
      gastricvalue: this.gastricvalue== undefined ? "-" : this.gastricvalue,
      stooltype: this.stooltype == undefined ? "-" : this.stooltype,
      stoolvalue: this.stoolvalue == undefined ? "-" : this.stoolvalue,
      draintype: this.draintype ==undefined ? "-" : this.draintype,
      drainvalue: this.drainvalue ==undefined ? "-" : this.drainvalue,
      outputvalue: this.outputvalue ==undefined ? "-": this.outputvalue,
      inputtotal : this.inputtotal ==undefined ? "-" : this.inputtotal

    }


    this.fluidBalanceList.push(obj);
    console.log("fluid row", obj, "list =>", this.fluidBalanceList);

    console.log("Fluid chart master create =====", {
      babyid: this.babyId,
      nurseid: this.selectedNurse,
      clientid: JSON.parse(sessionStorage.getItem('userInfo1')).usermasterid,
      date: moment().format(),
      time: moment().format(),
      fluidBalanceList: { "data": JSON.stringify(this.fluidBalanceList) }
    })


    // this.fluidBalanceChartList.push(obj);
    console.log("fluid details => ", obj, "fluid details", this.fluidBalanceChartList);
    this.mainserviceService.createFluidChart({
      babyid: this.babyId,
      nurseid: this.selectedNurse,
      clientid: JSON.parse(sessionStorage.getItem('userInfo1')).usermasterid,
      date: moment().format(),
      time: moment().format(),
      fluidBalanceList: { "data": JSON.stringify(this.fluidBalanceList) }
    }).subscribe((res) => {
      console.log("res fluid balance chart ====", res);
      if (res) {
        if (res.status_code == "s_405") {
          swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Record already exist!'
          });

        } else if (res.status_code == "s_444") {
          swal.fire(
            'Good job!',
            'Fluid Balance Chart Add Succsefully!',
            'success'
          );

          this.getFluidChart(this.babyId);
          this.panelOpenState  = true;
          // this.getmedicinemasterdetails()
          this.closeBtnClick()
        } else if (res.status_code == "s_1015") {
          swal.fire(
            'Bad Response!',
            'An Error Occured, Please Contact System Administrator!',
            'error'
          );
        }
      }
    });


    this.reset()
    this.resetfluidaddform();
  }

  closeBtnClick() {
    this.modalService.dismissAll()
    this.ngOnInit();
  }


  resetfluidaddform = () => {
    try {
      this.ivfluidtype = undefined;
      this.ivfluidvalue =undefined;
      this.feedtype = undefined;
      this.feedvalue = undefined;
      // this.additivetype = undefined;
      // this.additivevalue = undefined;
      // this.intervenoustype = undefined;
      // this.intervenousvalue = undefined;
      this.bloodtype = undefined;
      this.bloodvalue = undefined;
      // this.vomittype = undefined;
      // this.vomitvalue = undefined;
      this.urinetype = undefined;
      this.urinevalue = undefined;
      this.gastrictype= undefined;
      this.gastricvalue= undefined;
      this.stooltype= undefined;
      this.stoolvalue= undefined;
      this.draintype= undefined;
      this.drainvalue= undefined;
      
    } catch (err) {
      console.log("err", err);
    }
  }

  reset() {
    try {
      this.selectedBaby = null
      this.selectedNurse = null;
      this.babyId = null,
      this.fluidBalanceList = [];

    } catch (err) {

    }
  }

  createFluidTemplate() {
    try {

      this.view = true;
      let obj = {
        babyid: this.selectedBaby,
        nurseid: this.selectedNurse,
        clientid: JSON.parse(sessionStorage.getItem('userInfo1')).usermasterid,
        date: moment().format(),
        time: moment().format(),
        fluidBalanceList: { "data": JSON.stringify(this.fluidBalanceList) }
      }


      // this.fluidBalanceChartList.push(obj);
      console.log("fluid details => ", obj, "fluid details", this.fluidBalanceChartList);
      this.mainserviceService.createFluidChart(obj).subscribe((data) => {
        console.log("res fluid balance chart ====", data);
        if (data) {
        //  this.getFluidChart()
          swal.fire(
            'Good job!',
            'Fluid Balance Chart Create Succsefully!',
            'success'
          );
        }
      });

      this.reset()

    } catch (err) {
      console.log("err===================", err);
    }
  }

  getFluidChart(babyId) {
    try {
      this.mainserviceService.getFluidChart({
        "babyid": babyId,
        "nurseid": null,
        "clientid": JSON.parse(sessionStorage.getItem('userInfo1')).usermasterid
      }).subscribe((res) => {
        if (res) {
          console.log("fluid res ======",res.data);
          this.fluidBalanceChartList = this.getData(res.data);
          console.log("Get fluid balance chart =>", this.fluidBalanceChartList);
        }
        
      }, (err) => {
        console.log(err.error);
      });
    } catch (errFluidBalanceChart) {
      console.log("err=======", this.fluidBalanceChartList);
    }
  }

  getbabydetails(pageinc, status) {
    try {
      this.mainserviceService.getbabyid({
        "babyno": null,
        "babyname": null,
        "machineid": null,
        "clientid": JSON.parse(sessionStorage.getItem('userInfo1')).clientid,
        "babystatus": status,
        "isactive": true,
        "page": pageinc,
        "pagesize": 5
      }).subscribe((res) => {
        console.log("Baby Details => ", res.data);
        this.BabyList = res.data;
      }, (err) => {
        console.log(err.error);
      });

    } catch (err) {
      console.log(err);
    }
  }

  updateBaby =(row)=> {
    try{
      console.log("row===",row);
      this.babyId = row? row.babyid:null;
      this.getFluidChart(this.babyId);
    }catch(errUpdateBaby){
      console.log("err ======",errUpdateBaby);
    }
  }

  openLg1(content3, row) {
    this.babyId = row ? row.babyid : 0;
    console.log("view Details ========================", row, "baby id =======", this.babyId);
    this.modalService.open(content3, { size: 'xl' });
    // this.modalService.open(content3, { fullscreen: true });
  }

  getNursemaster() {
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
    let dummy_data = {
      "usercategoryid": 9,
      "usersubcategoryid": null,
      "clientid": userData.clientid,
      "page": 1,
      "pagesize": 100000
    }

    this.mainserviceService.getUser(dummy_data).subscribe((res) => {
      console.log("Nurse Master Data => ", res.data);
      this.nurseList = res.data;
    }, (err) => {
      console.log(err.error);
    });
  }

  getData = (data) => {
    try {
      // let returnData = data.map(x => {
      //   let objTemp = JSON.parse(x.fluidBalanceList);
      //   let objtempcopy = JSON.parse(objTemp.data);
      //   let obj = {
      //     babyid: x.babyid,
      //     date: x.date,
      //     fluidBalanceList: objtempcopy,
      //     nurseid: x.nurseid,
      //     time: x.time,
      //   }
      //   return obj;
      // })

      let Outputdata = [];
      data?.map(x => {
        let objTemp = JSON.parse(x.fluidBalanceList);
        let objtempcopy = JSON.parse(objTemp.data);
        objtempcopy[0].date = x.time;
        Outputdata.push(objtempcopy[0]);
      })
      console.log("return data obj = ", Outputdata);
      return Outputdata;


    } catch (errData) {
      console.log("ErrData => ", errData)
    }
  }

  viewHistory() {
    try {
      this.view = true;

    } catch (err) {

    }
  }

  backview() {
    this.view = false;
    this.filterView = false;
    this.reset();

  }

  createFilter() {
    try {
      this.filterView = true;

    } catch (errCreateFilter) {

    }
  }

  filterRecord() {
    try {
      console.log("Baby => ", this.selectedBaby, this.selectedNurse);
      this.selectedBaby = null;
      this.selectedNurse = null;
    } catch (filterrecordError) {

    }
  }

  onChange(event: MatTabChangeEvent) {
    try {
      const tab = event.tab.textLabel;
      console.log(tab);

      if (tab === "Admited") {
        this.getbabydetails(1, "admitted");
      } else if (tab == "Discharged") {
        this.getbabydetails(1, "discharge");

      }
    } catch (err) {
      console.log(err)
    }
  }

  admitprevious() {
    if (this.pageadmit >= 2) {
      this.pageadmit = this.pageadmit - 1;
      console.log("decriment => ", this.pageadmit)
      // this.getbabydetails(this.page);
      this.getbabydetails(this.pageadmit, "admitted");
    }
  }

  admitnext() {
    this.pageadmit = this.pageadmit + 1;
    console.log("Incriment => ", this.pageadmit)
    // this.getbabydetails(this.page);
    this.getbabydetails(this.pageadmit, "admitted");

  }


  dischargeprevious() {
    if (this.pagedischarge >= 2) {
      this.pagedischarge = this.pagedischarge - 1;
      console.log("decriment => ", this.pagedischarge)
      // this.getbabydetails(this.page);
      this.getbabydetails(this.pagedischarge, "discharge");
    }
  }
  dischargenext() {
    this.pagedischarge = this.pagedischarge + 1;
    console.log("Incriment => ", this.pagedischarge)
    // this.getbabydetails(this.page);
    this.getbabydetails(this.pagedischarge, "discharge");

  }

}
