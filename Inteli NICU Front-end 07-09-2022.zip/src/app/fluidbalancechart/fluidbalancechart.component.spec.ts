import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FluidbalancechartComponent } from './fluidbalancechart.component';

describe('FluidbalancechartComponent', () => {
  let component: FluidbalancechartComponent;
  let fixture: ComponentFixture<FluidbalancechartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FluidbalancechartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FluidbalancechartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
