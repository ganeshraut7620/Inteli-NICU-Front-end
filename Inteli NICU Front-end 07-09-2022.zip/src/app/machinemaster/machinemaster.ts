export class Machinemaster {
public machineid:Number;
public machinename:String;
public machinemodelno:String;
public softwareversion:String;
public machineserialno:String;
public macid:String;
}
