import { TestBed } from '@angular/core/testing';

import { MachinemasterService } from './machinemaster.service';

describe('MachinemasterService', () => {
  let service: MachinemasterService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MachinemasterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
