import { Machinemaster } from './machinemaster';

export const machinemaster:Machinemaster[] = [

]
