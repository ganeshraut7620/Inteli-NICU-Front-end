import { Component, OnInit } from '@angular/core';
import swal from 'sweetalert2';
import { FormGroup, FormControl, Validators, RequiredValidator,FormBuilder  } from '@angular/forms';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CustomvalidationService } from '../services/customvalidation.service';

import { AuthinterceptorService } from '../authinterceptor.service';
import { NgxSpinnerService } from "ngx-spinner";

import { MachinemasterService } from './machinemaster.service';
import { Machinemaster } from './machinemaster';
import { MainserviceService } from '../mainservice.service';

@Component({
  selector: 'app-machinemaster',
  templateUrl: './machinemaster.component.html',
  styleUrls: ['./machinemaster.component.css']
})
export class MachinemasterComponent implements OnInit {

  page = 1;
  pageSize = 7;

  machineList: Machinemaster[] = this.machinemasterservice.getMachinemaster();


  filterArray:Machinemaster[];
  filterMachine: any;
  tableService: any;
  cfilterMachine: any;
  totalLengthOfCollection: any;

  page_incr =1;

  constructor(private mainserviceService: MainserviceService ,private authinterceptorService:AuthinterceptorService,private machinemasterservice : MachinemasterService,private modalService: NgbModal,private fb: FormBuilder,private customValidator: CustomvalidationService,private spinner: NgxSpinnerService) {
   this.filterArray = this.machineList;

  //  if(sessionStorage.getItem('flag') == "true"){
  //   window.location.reload(true);
  //   sessionStorage.setItem('flag','false');
  // }

    this.spinner.show();

    setTimeout(() => {
        /** spinner ends after 5 seconds */
        this.spinner.hide();
    }, 1000);

    this.getmachine(this.page);

  }


  show: boolean = false;
  registerForm: FormGroup;
  submitted = false;
  editmachinemaster:any;


  open1(content1) {
		this.modalService.open(content1, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
			//this.closeResult = `Closed with: ${result}`;
		}, (reason) => {
			//this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
		});
  }


  ngOnInit(): void {
    this.registerForm = new FormGroup({
      machinename:new FormControl(null,[Validators.required]),
      machinemodelno:new FormControl(null,[Validators.required]),
      softwareversion:new FormControl(null,[Validators.required]),
      machineserialno:new FormControl(null,[Validators.required]),
      macid:new FormControl(null,[Validators.required])
    });
  }

   _searchTerm: string;
    get searchTerm(): string {
        return this._searchTerm;
    }
    set searchTerm(val: string) {
        this._searchTerm = val;
        this.filterArray = this.filter(val);
    }

    filter(v: string) {
        return this.machineList.filter(x => x.machinename.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.machinemodelno.toLowerCase().indexOf(v.toLowerCase()) !== -1);
    }

  get registerFormControl() {
    return this.registerForm.controls;
  }

  openLg(content1) {
		this.modalService.open(content1, { size: 'lg' });
  }

  openModal(targetModal,machinemaster) {
    this.modalService.open(targetModal, {
        centered: true,
        backdrop: 'static',
        size: 'lg'
    })
    console.log(machinemaster);
    this.editmachinemaster = machinemaster;
  }

  openModal1(targetModal,machinemaster) {
    this.modalService.open(targetModal, {
        centered: true,
        backdrop: 'static',
        size: 'lg'
    })
    console.log(machinemaster);
    this.editmachinemaster = machinemaster;
  }
getmachine(page_incr){
  var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
 console.log( "session storage value => ",userData);
    let dummy_data ={
      "machineid": null,
      "machinemodelno": null,
      "machineno": null,
      "machineserialno": null,
      "usermasterid":userData.usermasterid,
      "isactive": true,
      "requiresite": "NO",
      "submasterid":null,
      "page": page_incr,
      "pagesize": 5
    }
    this.mainserviceService.getMachine(dummy_data).subscribe((res) => {
      console.log(res);
      this.filterArray = res.data;
      this.machineList = res.data;
      console.log(this.filterArray);
    }, (err) => {
      console.log(err.error);
    });
}
ondelete(machineid){
 console.log(machineid);
  let data = {
    "machineid":machineid
  }

  const swalWithBootstrapButtons = swal.mixin({
    customClass: {
      confirmButton: 'btn btn-success',
      cancelButton: 'btn btn-danger'
    },
    buttonsStyling: false
  })

  swalWithBootstrapButtons.fire({
    title: 'Are you sure,you want to delete it?',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Yes, delete it!',
    cancelButtonText: 'No, cancel!',
    reverseButtons: true
  }).then((result) => {
    if (result.isConfirmed) {
      this.mainserviceService.deleteMachine(data).subscribe((data) => {
        console.log(data);

        this.getmachine(this.page)

      }, (err) => {
        console.log(err.error);
        swal.fire(
          // 'Good job!',
          err.error,
          'error'
        )
      });

      swalWithBootstrapButtons.fire(
        'Deleted!',
        'Machine has been deleted.',
        'success'
      )
    } else if (
      /* Read more about handling dismissals below */
      result.dismiss === swal.DismissReason.cancel
    ) {
      swalWithBootstrapButtons.fire(
        'Cancelled',
        'Your Machine is safe.',
        'error'
      )
    }
  })

 /**/
}
onUpdate(){
  console.log(this.editmachinemaster);
  this.editmachinemaster.isactive =true;
  this.editmachinemaster.siteid = null;
  delete this.editmachinemaster['machineno'];
  this.mainserviceService.updateMachine(this.editmachinemaster).subscribe((res) => {
      console.log("Machine Updated Response => ",res);

      if(res.status_code == 400){
        swal.fire(
          'error',
          res.message,

         );
      }

      if(res.status_code =="s_403"){
        swal.fire(
         'Good job!',
         'Machine Updated Succsefully!',
          'success'
        );

        this.getmachine(this.page);
        this.closeBtnClick();

      }else if(res.status_code =="s_1015"){
        swal.fire(
          'Bad Response!',
          'An Error Occured, Please Contact System Administrator!',
           'error'
         );
      }

    }, (err) => {
      console.log(err.error);
      swal.fire(
        // 'Good job!',
        err.error,
        'error'
      )
    });

  this.closeBtnClick();
}

onSubmit() {
    

    if (this.registerForm.valid) {
      this.submitted = false;
      //alert('Form Submitted succesfully!!!\n Check the values in browser console.');
      console.table(this.registerForm.value);
      //let url = "/api/v1/adminmaster/login"
      var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
      console.log( "session storage value => ",userData);
      this.registerForm.value.usermasterid = userData.usermasterid;
      this.registerForm.value.isactive = true;
      this.mainserviceService.createMachine(this.registerForm.value).subscribe((res) => {
        console.log("Machine Res => ",res);

        if(res.status_code == 400){
          swal.fire(
            'error',
            res.message,

           );
        }

        if(res.status_code =="s_402"){
          swal.fire(
           'Good job!',
           'Machine Added Succsefully!',
            'success'
          );

          this.getmachine(this.page);
          this.closeBtnClick();

        }else if(res.status_code =="s_405"){
          swal.fire(
            'Bad Response!',
            'Machine Already Exists!',
             'error'
           );
        }else if(res.status_code =="s_432"){
          swal.fire(
            'Bad Response!',
            'Macid Already Exists in the System!',
             'error'
           );
        }else if(res.status_code =="s_1015"){
          swal.fire(
            'Bad Response!',
            'An Error Occured, Please Contact System Administrator!',
             'error'
           );
        }

      }, (err) => {
        console.log(err.error);
        swal.fire(
          // 'Good job!',
          err.error,
          'error'
        )
        this.closeBtnClick();
      });


    }
    
    this.registerForm = new FormGroup({
      machinename:new FormControl(null,[Validators.required]),
      machinemodelno:new FormControl(null,[Validators.required]),
      softwareversion:new FormControl(null,[Validators.required]),
      machineserialno:new FormControl(null,[Validators.required]),
      macid:new FormControl(null,[Validators.required])
    });

  }

  closeBtnClick() {
    this.modalService.dismissAll()
    this.ngOnInit();

 }


previous(){
  if(this.page>=2){
  this.page = this.page - 1;
  console.log("decriment => ",this.page)
  this.getmachine(this.page);
  }else{

  }
}

next(){
  this.page = this.page + 1;
  console.log("Incriment => ",this.page)
  this.getmachine(this.page);
}

}
