import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { MachinemasterRoutingModule } from './machinemaster-routing.module';
import { MachinemasterComponent } from './machinemaster.component';
import { NgxSpinnerModule } from "ngx-spinner";

@NgModule({
  declarations: [MachinemasterComponent],
  imports: [
    CommonModule,
    MachinemasterRoutingModule,
    FormsModule,
    NgxSpinnerModule,
    ReactiveFormsModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class MachinemasterModule { }
