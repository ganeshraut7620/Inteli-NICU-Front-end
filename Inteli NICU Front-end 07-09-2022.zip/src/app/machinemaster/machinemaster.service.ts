import { Injectable } from '@angular/core';

import { Machinemaster } from './machinemaster';
import { machinemaster } from './machinemaster-data';

@Injectable({
  providedIn: 'root'
})
export class MachinemasterService {
  getTable() {
    throw new Error("Method not implemented.");
  }


  public machinemaster: Machinemaster[] = machinemaster;

    public getMachinemaster() {
        return this.machinemaster;
    }
}
