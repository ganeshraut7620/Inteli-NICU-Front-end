import { Component, OnInit } from '@angular/core';
import { MainserviceService } from '../mainservice.service';
@Component({
  selector: 'app-managerdashboard',
  templateUrl: './managerdashboard.component.html',
  styleUrls: ['./managerdashboard.component.css']
})
export class ManagerdashboardComponent implements OnInit {

  msg: string;
  totalsite:any = '';
  installsites:any = '';
  pendingsites:any = '';
  ready:any = '';

  totalmachines:any = '';
  installmachines:any =  '';
  activemachine:any = '';
  inactivemachines:any = '';
  totalcomplaint: any = '';
  opencomplaint: any = '';
  closecomplaint: any = '';
  totalamc: any = '';
  activeamc: any = '';
  inactiveamc_data: any = '';
  expire: any;
  totalclient: any;

  constructor(public mainserviceService:MainserviceService) { 
    if(sessionStorage.getItem('flag') == "true"){
      window.location.reload(true);
      sessionStorage.setItem('flag','false');
    }
    this.getmanagerdashboardanalytics();
  }

  ngOnInit(): void {
  }

  getmanagerdashboardanalytics(){
    var userData = JSON.parse(sessionStorage.getItem('userInfo1'));
     console.log( "session storage value => ",userData);
    let data = {}

    this.mainserviceService.getmanagerdashboard(data).subscribe((res) => {
      console.log("get manager Dashboard Data  =>",res);

      if(res.status_code == 's_407'){
       console.log("data => ",res.data);
       this.totalsite = res.data[0].siteandmachinedetails.totalsites;
       this.pendingsites = res.data[0].siteandmachinedetails.pendingsites;
       this.installsites = res.data[0].siteandmachinedetails.installedsites;
       this.ready = res.data[0].siteandmachinedetails.readytoinstallsites;

       this.totalmachines = this.totalsite;
       this.installmachines = this.installsites;
       this.activemachine = this.installsites;
       this.inactivemachines = this.pendingsites + this.ready;

       this.totalcomplaint = res.data[0].complaintdetails[0].totalcomplaint;
       this.opencomplaint = res.data[0].complaintdetails[0].opencomplaint;
       this.closecomplaint = res.data[0].complaintdetails[0].closecomplaint;

       this.totalamc = res.data[0].siteandmachinedetails.totalamc;
       this.activeamc = res.data[0].siteandmachinedetails.activeamc;
       this.expire =  res.data[0].siteandmachinedetails.expeiredamc;
       this.totalclient =  res.data[0].clientdetails[0].totalcount;

      }else if(res.status_code == 's_1015'){

      }else if(res.status_code == 's_408'){
        this.msg = "No Record Found";
      }


      }, (err) => {
            console.log(err.error);

    });
  }
}
