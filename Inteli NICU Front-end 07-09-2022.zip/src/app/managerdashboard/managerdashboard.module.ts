import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ManagerdashboardRoutingModule } from './managerdashboard-routing.module';
import { ManagerdashboardComponent } from './managerdashboard.component';


@NgModule({
  declarations: [ManagerdashboardComponent],
  imports: [
    CommonModule,
    ManagerdashboardRoutingModule
  ]
})
export class ManagerdashboardModule { }
