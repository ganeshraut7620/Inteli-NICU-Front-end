import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ManagerdashboardComponent } from './managerdashboard.component';

const routes: Routes = [{path: '' ,component:ManagerdashboardComponent}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ManagerdashboardRoutingModule { }
