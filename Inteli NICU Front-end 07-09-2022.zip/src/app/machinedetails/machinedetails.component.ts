import { Component, OnInit } from '@angular/core';
import { MachinemasterService } from '../machinemaster/machinemaster.service';
import { Machinemaster } from '../machinemaster/machinemaster';
import { MainserviceService } from '../mainservice.service';
import { FormGroup, FormControl, Validators, RequiredValidator,FormBuilder  } from '@angular/forms';
@Component({
  selector: 'app-machinedetails',
  templateUrl: './machinedetails.component.html',
  styleUrls: ['./machinedetails.component.css']
})
export class MachinedetailsComponent implements OnInit {

  page = 1;

  machineList: Machinemaster[] = this.machinemasterService.getMachinemaster();


  filterArray:Machinemaster[];

  constructor(public machinemasterService:MachinemasterService,public mainserviceService:MainserviceService) {
    this.getmachine(this.page);
   }

  ngOnInit(): void {

  }

  _searchTerm: string;
    get searchTerm(): string {
        return this._searchTerm;
    }
    set searchTerm(val: string) {
        this._searchTerm = val;
        this.filterArray = this.filter(val);
    }

    filter(v: string) {
        return this.machineList.filter(x => x.machinename.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.machinemodelno.toLowerCase().indexOf(v.toLowerCase()) !== -1);
    }

  getmachine(page){
    let dummy_data ={
      "machineid": null,
      "machinemodelno": null,
      "machineno": null,
      "machineserialno": null,
      "usermasterid":null,
      "submasterid":null,
      "isactive": true,
      "requiresite": "NO",
      "page":page,
      "pagesize": 5
    }
    this.mainserviceService.getMachine(dummy_data).subscribe((res) => {
      console.log(res);
      this.filterArray = res.data;
      this.machineList = res.data;
      console.log(this.filterArray);
    }, (err) => {
      console.log(err.error);
    });
}

previous(){
  if(this.page>=2){
  this.page = this.page - 1;
  console.log("decriment => ",this.page);
  this.getmachine(this.page);
  }else{

  }
}

next(){
  this.page = this.page + 1;
  console.log("Incriment => ",this.page);
  this.getmachine(this.page);
}

}
