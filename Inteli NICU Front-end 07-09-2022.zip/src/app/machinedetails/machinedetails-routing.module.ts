import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MachinedetailsComponent } from './machinedetails.component';

const routes: Routes = [
  { path:'', component:MachinedetailsComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MachinedetailsRoutingModule { }
