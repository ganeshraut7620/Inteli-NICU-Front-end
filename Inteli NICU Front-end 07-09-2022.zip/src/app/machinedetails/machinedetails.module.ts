import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { MachinedetailsRoutingModule } from './machinedetails-routing.module';
import { MachinedetailsComponent } from './machinedetails.component';


@NgModule({
  declarations: [MachinedetailsComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MachinedetailsRoutingModule
  ]
})
export class MachinedetailsModule { }
