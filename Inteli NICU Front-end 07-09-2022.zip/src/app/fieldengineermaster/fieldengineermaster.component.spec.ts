import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FieldengineermasterComponent } from './fieldengineermaster.component';

describe('FieldengineermasterComponent', () => {
  let component: FieldengineermasterComponent;
  let fixture: ComponentFixture<FieldengineermasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FieldengineermasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FieldengineermasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
