import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { FieldengineermasterRoutingModule } from './fieldengineermaster-routing.module';
import { FieldengineermasterComponent } from './fieldengineermaster.component';
import { NgxSpinnerModule } from "ngx-spinner";

@NgModule({
  declarations: [FieldengineermasterComponent],
  imports: [
    CommonModule,
    FormsModule,ReactiveFormsModule,
    FieldengineermasterRoutingModule,NgxSpinnerModule
  ]
})
export class FieldengineermasterModule { }
