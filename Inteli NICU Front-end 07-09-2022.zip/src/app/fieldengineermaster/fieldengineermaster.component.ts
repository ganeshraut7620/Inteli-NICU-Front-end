import { Component, OnInit } from '@angular/core';
import swal from 'sweetalert2';
import { FormGroup, FormControl, Validators, RequiredValidator,FormBuilder  } from '@angular/forms';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CustomvalidationService } from '../services/customvalidation.service';
import { MainserviceService } from '../mainservice.service';
import { ClientmasterService } from '../clientmaster/clientmaster.service';
import { Clientmaster } from '../clientmaster/clientmaster';

import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-fieldengineermaster',
  templateUrl: './fieldengineermaster.component.html',
  styleUrls: ['./fieldengineermaster.component.css']
})
export class FieldengineermasterComponent implements OnInit {

  page = 1;
  
   registerForm: FormGroup;
   submitted = false;
   editfielengineer:any;
   clientList: Clientmaster[] = this.clientmasterService.getClientmaster();


  filterArray:Clientmaster[];
  respose_catch: any;

  constructor(private spinner: NgxSpinnerService,private mainserviceService: MainserviceService,private modalService: NgbModal,private fb: FormBuilder,private customValidator: CustomvalidationService,public  clientmasterService: ClientmasterService) {
    this.getClientMasterDetails(this.page)
  }

  ngOnInit(): void {

    this.registerForm = this.fb.group({

      usermastername:['',Validators.required],
      address:['',Validators.required],
      country:[''],
      state:[''],
      city:[''],
      pincode:[,Validators.required],
      emailid:['',Validators.required],
      contactpersonname: ['',Validators.required],
      landlineno:['',Validators.required],
      mobilenumber:['',Validators.required],
      username:['',Validators.required],
      password:['',Validators.required]
    }
    );

  }

  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;

    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }

    if (event.keyCode === 32 ) {
      return false;
    }
  }

  get registerFormControl() {
    return this.registerForm.controls;
  }

  openLg(content1) {
		this.modalService.open(content1, { size: 'lg' });
  }

  changestate($event){}
  changecity($event){}
  changecountry($event){}

  openModal(targetModal,fieldengineer) {
    this.modalService.open(targetModal, {
        centered: true,
        backdrop: 'static',
        size: 'lg'
    })
    console.log(fieldengineer);
    this.editfielengineer = fieldengineer;
}
openModal1(targetModal,fieldengineer) {
  this.modalService.open(targetModal, {
      centered: true,
      backdrop: 'static',
      size: 'lg'
  })
  //console.log(machinemaster);
  //this.editmachinemaster = machinemaster;
}

_searchTerm: string;
 get searchTerm(): string {
        return this._searchTerm;
  }

set searchTerm(val: string) {
  this._searchTerm = val;
  this.filterArray = this.filter(val);
}

filter(v: string) {
  return this.clientList.filter(x => x.usermastername.toLowerCase().indexOf(v.toLowerCase()) !== -1 || x.emailid.toLowerCase().indexOf(v.toLowerCase()) !== -1);
}


// onSubmit() {
//   this.submitted = true;

//   this.registerForm.value.usercategoryid = 4;
//   console.log(this.registerForm.value);
//   if (this.registerForm.valid) {
//     //alert('Form Submitted succesfully!!!\n Check the values in browser console.');
//    // this.registerForm.value.usercategoryid = 4;
//     this.registerForm.value.isactive = true;
//     console.table(this.registerForm.value);
//     swal.fire(
//       'Good job!',
//       'Client Added Succsefully!',
//       'success'
//     );
//    /* this.mainserviceService.createUser(this.registerForm.value).subscribe((data) => {
//       console.log(data);
//       this.respose_catch = data;
//       console.log(this.respose_catch.status_code);
//       if(this.respose_catch.status_code == "s_405"){
//         swal.fire({
//           icon: 'error',
//           title: 'Oops...',
//           text: 'Record already exist!',

//         })

//       }else if(this.respose_catch.status_code == "s_402"){
//         swal.fire(
//                 'Good job!',
//                 'Client Added Succsefully!',
//                 'success'
//               );
//           this.getClientMasterDetails();
//       }

//           }, (err) => {
//             console.log(err.error);
//             swal.fire(
//               'Server Request Time Out!',
//               err.error,
//               'error'

//             )
//           });*/

//     //this.clientList.push(this.registerForm.value);
//    // this.registerForm = null;
//     this.closeBtnClick();
//   }
// }

getClientMasterDetails(page){
  let dummy_data ={
    "usercategoryid":4,
    "usersubcategoryid":null,
    "page": page,
    "pagesize": 5
  }

  this.mainserviceService.getUser(dummy_data).subscribe((res) => {
    console.log("=>",res);
    this.filterArray = res.data;
    this.clientList = res.data;

    console.log(this.filterArray);
      }, (err) => {
    console.log(err.error);
  });

}

previous(){
  if(this.page>=2){
  this.page = this.page - 1;
  console.log("decriment => ",this.page);
  this.getClientMasterDetails(this.page);
  }else{

  }
}

next(){
  this.page = this.page + 1;
  console.log("Incriment => ",this.page);
  this.getClientMasterDetails(this.page);
}

closeBtnClick() {
  this.modalService.dismissAll()
  this.ngOnInit();
}




}
