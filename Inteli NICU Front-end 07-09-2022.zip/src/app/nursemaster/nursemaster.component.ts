import { Component, OnInit } from '@angular/core';
import swal from 'sweetalert2';
import { FormGroup, FormControl, Validators, RequiredValidator,FormBuilder  } from '@angular/forms';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CustomvalidationService } from '../services/customvalidation.service';
import { NursemasterService } from './nursemaster.service';
import { MainserviceService } from '.././mainservice.service';
import { Nursemaster } from './nursemaster';
import { NgxSpinnerService } from "ngx-spinner";
/* Imports */
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_spiritedaway from "@amcharts/amcharts4/themes/spiritedaway";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";

/* Chart code */
// Themes begin
am4core.useTheme(am4themes_spiritedaway);
am4core.useTheme(am4themes_animated);
// Themes end



@Component({
  selector: 'app-nursemaster',
  templateUrl: './nursemaster.component.html',
  styleUrls: ['./nursemaster.component.css']
})
export class NursemasterComponent implements OnInit {
  page = 1;
  pageSize = 7;
  machine:any = [10,11,12,13,14,15,16,17,18];
  clients:any =  [1,2,4,4,5,6,7,8,9,10];
  Nurses :any = [1,2,3,4,5,6,7,8];
  machines = ['Machine-12',"Machine-13","Machine14"];
  doctors = ['Ankit','Swapnil','Akshay'];
  nurses = ['Pooja','Nileam','Gita'];
  durations  = ["This Month","This Week","Yesterday","Todays"]
  trendsform : trends_form = new trends_form();
  nurseList: Nursemaster[] = this.nursemasterService.getNursemaster();
  config: any;
  editnursemaster_details:any;
  nurseDetail: Nursemaster = null;
  filterArray: Nursemaster[];
  respose_catch: any;

  constructor(private spinner: NgxSpinnerService,private mainserviceService:MainserviceService,private modalService: NgbModal,private fb: FormBuilder,
    private customValidator: CustomvalidationService,private nursemasterService:NursemasterService,private mainservice:MainserviceService) {
      this.filterArray = this.nurseList;
      this.spinner.show();

      setTimeout(() => {
        /** spinner ends after 5 seconds */
        this.spinner.hide();
        this.nurseres_time();
      }, 1000);

      this.getNurseMasterDetails();

// Create chart instance

     }

     trends_submit(){
      console.log(this.trendsform);
    }

  nurseres_time(){
    let chart = am4core.create('chartdiv', am4charts.XYChart)
    chart.colors.step = 4;

    chart.legend = new am4charts.Legend()
    chart.legend.position = 'top'
    chart.legend.paddingBottom = 20
    chart.legend.labels.template.maxWidth = 95

    let xAxis = chart.xAxes.push(new am4charts.CategoryAxis())
    xAxis.dataFields.category = 'category'
    xAxis.renderer.cellStartLocation = 0.1
    xAxis.renderer.cellEndLocation = 0.9
    xAxis.renderer.grid.template.location = 0;

    let yAxis = chart.yAxes.push(new am4charts.ValueAxis());
    yAxis.min = 0;

    function createSeries(value, name) {
        let series = chart.series.push(new am4charts.ColumnSeries())
        series.dataFields.valueY = value
        series.dataFields.categoryX = 'category'
        series.name = name

        series.events.on("hidden", arrangeColumns);
        series.events.on("shown", arrangeColumns);

        let bullet = series.bullets.push(new am4charts.LabelBullet())
        bullet.interactionsEnabled = false
        bullet.dy = 30;
        bullet.label.text = '{valueY}'
        bullet.label.fill = am4core.color('#ffffff')

        return series;
    }

    chart.data = [
        {
            category: '20/10/2020',
            first: 40,
            second: 55,
            third: 60
        },
        {
          category: '21/10/2020',
          first: 30,
          second: 40,
          third: 40
        },
        {
          category: '22/10/2020',
          first: 38,
          second: 45,
          third: 20
        },
        {
          category: '23/10/2020',
          first: 48,
          second: 55,
          third: 25
        },
        {
          category: '24/10/2020',
          first: 78,
          second: 85,
          third: 26
        },
        {
          category: '25/10/2020',
          first: 30,
          second: 45,
          third: 76
        },
        {
          category: '26/10/2020',
          first: 88,
          second: 85,
          third: 66
        }

    ]


    createSeries('first', 'A');
    createSeries('second', 'B');
    createSeries('third', 'C');

    function arrangeColumns() {

        let series = chart.series.getIndex(0);

        let w = 1 - xAxis.renderer.cellStartLocation - (1 - xAxis.renderer.cellEndLocation);
        if (series.dataItems.length > 1) {
            let x0 = xAxis.getX(series.dataItems.getIndex(0), "categoryX");
            let x1 = xAxis.getX(series.dataItems.getIndex(1), "categoryX");
            let delta = ((x1 - x0) / chart.series.length) * w;
            if (am4core.isNumber(delta)) {
                let middle = chart.series.length / 2;

                let newIndex = 0;
                chart.series.each(function(series) {
                    if (!series.isHidden && !series.isHiding) {
                        series.dummyData = newIndex;
                        newIndex++;
                    }
                    else {
                        series.dummyData = chart.series.indexOf(series);
                    }
                })
                let visibleCount = newIndex;
                let newMiddle = visibleCount / 2;

                chart.series.each(function(series) {
                    let trueIndex = chart.series.indexOf(series);
                    let newIndex = series.dummyData;

                    let dx = (newIndex - trueIndex + middle - newMiddle) * delta

                    series.animate({ property: "dx", to: dx }, series.interpolationDuration, series.interpolationEasing);
                    series.bulletsContainer.animate({ property: "dx", to: dx }, series.interpolationDuration, series.interpolationEasing);
                })
            }
        }
    }
     }
  open1(content1) {
		this.modalService.open(content1, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
			//this.closeResult = `Closed with: ${result}`;
		}, (reason) => {
			//this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
		});
  }

  openLg(content1) {
		this.modalService.open(content1, { size: 'lg' });
	}

  show: boolean = false;
  registerForm: FormGroup;
  submitted = false;
  editnursemaster: FormGroup;

  _searchTerm: string;
    get searchTerm(): string {
        return this._searchTerm;
    }
    set searchTerm(val: string) {
        this._searchTerm = val;
        this.filterArray = this.filter(val);
    }

    filter(v: string) {
        return this.nurseList.filter(x => x.nursename.toLowerCase().indexOf(v.toLowerCase()) !== -1);
    }

  registerform = new FormGroup({
    fname: new FormControl('',Validators.required),
    lname:new FormControl('',Validators.required)
  })

    ngOnInit() {
      this.registerForm = this.fb.group({
        machineid:[,Validators.required],
        clientid:[,Validators.required],
        nurseid: [,Validators.required]
      }
      );

      /*
         nursename: ['', Validators.required],
        nurseaddress:[''],
        nursecontactone: ['', [Validators.required]],
        nursecontacttwo:[''],
        nurseemail: ['', [Validators.email]],
      */



      this.editnursemaster = this.fb.group({
        name: ['', Validators.required],
    });

    }

    changemachine($event){}

    changeclient($event){}
    changewp($event){}


    openModal1(targetModal,nursemaster) {
      this.modalService.open(targetModal, {
          centered: true,
          backdrop: 'static',
          size: 'lg'
      })
      //console.log(machinemaster);
      //this.editmachinemaster = machinemaster;
    }

 openModal(targetModal, nursemaster) {
      this.modalService.open(targetModal, {
          centered: true,
          backdrop: 'static',
          size: 'lg'
      })
      console.log(nursemaster);
      this.editnursemaster_details = nursemaster;

  }

    get registerFormControl() {
      return this.registerForm.controls;
    }

    changemachineid(){
      console.log(this.editnursemaster_details.machineId);
    }

getNurseMasterDetails(){
      let dummy_data ={
        "nurseid": null,
        "nursename": null,
        "machineid": null,
        "clientid": null,
        "isactive": true,
        "page": 1,
        "pagesize": 7
      }

      this.mainserviceService.getNurseMaster(dummy_data).subscribe((res) => {
        console.log(res);
        this.filterArray = res.data;
        this.nurseList = res.data;
        console.log(this.filterArray);
      }, (err) => {
        console.log(err.error);
      });

    }

onSubmit() {
      this.submitted = true;

      if (this.registerForm.valid) {

        console.table(this.registerForm.value);
        this.registerForm.value.isactive = true;
        console.table(this.registerForm.value);
        swal.fire(
          'Good job!',
          'Nurse Added Succsefully!',
          'success'
        );

       /* this.mainserviceService.createNurseMaster(this.registerForm.value).subscribe((data) => {
          console.log(data);
          this.respose_catch = data;

          console.log(this.respose_catch.status_code);
          if(this.respose_catch.status_code == "s_405"){
            swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: 'Record already exist!',

            })

          }else if(this.respose_catch.status_code == "s_402"){
            swal.fire(
                    'Good job!',
                    'Nurse Added Succsefully!',
                    'success'
                  );
              this.getNurseMasterDetails();
          }

              }, (err) => {
                console.log(err.error);
                swal.fire(
                  // 'Good job!',
                  err.error,
                  'error'
                )
              });*/
      }
      this.closeBtnClick();
}

onDelete(nurseid){
  let data  ={
    "nurseid":nurseid
 }
/* this.mainserviceService.deleteNurseMaster(data).subscribe((data) => {
       console.log(data);
       swal.fire(
         'Good job!',
         'Nurse Delete Succsefully!',
         'success'
       );
       this.editnursemaster_details();
     }, (err) => {
       console.log(err.error);
       swal.fire(
         // 'Good job!',
         err.error,
         'error'
       )
     });*/

     const swalWithBootstrapButtons = swal.mixin({
      customClass: {
        confirmButton: 'btn btn-success',
        cancelButton: 'btn btn-danger'
      },
      buttonsStyling: false
    })

    swalWithBootstrapButtons.fire({
      title: 'Are you sure,you want to delete it?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, cancel!',
      reverseButtons: true
    }).then((result) => {
      if (result.isConfirmed) {
        this.mainserviceService.deleteClient(data).subscribe((data) => {
          console.log(data);
          this.getNurseMasterDetails();
          swalWithBootstrapButtons.fire(
            'Deleted!',
            'Nurse has been deleted.',
            'success'
          )


        }, (err) => {
          console.log(err.error);
          swal.fire(
            // 'Good job!',
            err.error,
            'error'
          )
        })



      } else if (
        /* Read more about handling dismissals below */
        result.dismiss === swal.DismissReason.cancel
      ) {
        swalWithBootstrapButtons.fire(
          'Cancelled',
          'Nurse is safe.',
          'error'
        )
      }
    })

}


onUpdate(){
  console.table("update data => ",this.editnursemaster_details);

  delete this.editnursemaster_details['createdby'];
  delete this.editnursemaster_details['createddate'];
  delete this.editnursemaster_details['lastmodifiedby'];
  delete this.editnursemaster_details['lastmodifieddate'];

  this.mainserviceService.updateNurseMaster(this.editnursemaster_details).subscribe((data) => {
          console.log(data);
          swal.fire(
            'Good job!',
            'Nurse Update Succsefully!',
            'success'
          );

          this.getNurseMasterDetails();

        }, (err) => {
          console.log(err.error);
        });
      this.closeBtnClick();
    }
    onedit(){
      console.log("Edit data")
    }

    keyPress(event: any) {
      const pattern = /[0-9\+\-\ ]/;

      let inputChar = String.fromCharCode(event.charCode);
      if (event.keyCode != 8 && !pattern.test(inputChar)) {
        event.preventDefault();
      }

      if (event.keyCode === 32 ) {
        return false;
      }
    }

  closeBtnClick() {
      this.modalService.dismissAll()
      this.ngOnInit();
  }

}

class trends_form {
  machinename:String;
  perametername:String;
  duration:String
}
