import { TestBed } from '@angular/core/testing';

import { NursemasterService } from './nursemaster.service';

describe('NursemasterService', () => {
  let service: NursemasterService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NursemasterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
