export class Nursemaster {
    public nurseid:Number;
    public machinename:String;
    public clientname:String;
    public nursename:String;
  }
