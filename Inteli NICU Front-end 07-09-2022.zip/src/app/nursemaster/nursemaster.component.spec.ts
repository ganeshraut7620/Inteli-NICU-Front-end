import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NursemasterComponent } from './nursemaster.component';

describe('NursemasterComponent', () => {
  let component: NursemasterComponent;
  let fixture: ComponentFixture<NursemasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NursemasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NursemasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
