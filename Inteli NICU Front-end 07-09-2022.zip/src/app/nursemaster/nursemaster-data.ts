import { Nursemaster } from './nursemaster';

export const nursemaster: Nursemaster[] = [
  {
    "nurseid": 1,
    "machinename": "TestMachine-123",
    "clientname": "TestClient-123",
    "nursename": "TestNurse-123"
  }
]


/*
  public nurseid:Number;
    public machineid:Number;
    public clientid:Number;
    public nursename:String;

*/
