import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {NgbPaginationModule, NgbAlertModule} from '@ng-bootstrap/ng-bootstrap';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { NursemasterRoutingModule } from './nursemaster-routing.module';
import { NursemasterComponent } from './nursemaster.component';
import { NgxSpinnerModule } from "ngx-spinner";

@NgModule({
  declarations: [NursemasterComponent],
  imports: [
    CommonModule,
    NursemasterRoutingModule,
    NgbPaginationModule,
    NgbAlertModule,
    FormsModule,
    NgxSpinnerModule,
    ReactiveFormsModule
  ]
})
export class NursemasterModule { }
