import { Injectable } from '@angular/core';

import { Nursemaster } from './nursemaster';
import { nursemaster } from './nursemaster-data';


@Injectable({
  providedIn: 'root'
})

export class NursemasterService {

  public nursemaster: Nursemaster[] = nursemaster;

    public getNursemaster() {
        return this.nursemaster;
    }

}
