import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MainserviceService } from '../mainservice.service';
import swal from 'sweetalert2';



@Component({
  selector: 'app-growthchart',
  templateUrl: './growthchart.component.html',
  styleUrls: ['./growthchart.component.css']
})
export class GrowthchartComponent implements OnInit {

  BabyList = [];
  pagedischarge: number = 1;
  pageadmit: number = 1;
  babyid: any;
  growthChartForm: FormGroup;
  growthChartList = [{
    date: "7/8/2022 12:20 PM ",
    babyweigth : "2",
    babygestationage : "2",
    babylength :"2",
    babyheadcircumference :"3" 
  }]
  chartData: any[];
  weightData: any[];

  constructor(private mainserviceService: MainserviceService,private modalService: NgbModal) { 
    this.createGrowthChart();
  
  }

  ngOnInit(): void {
    this.getbabydetails(1, "admitted")
  }

  getbabydetails(pageinc, status) {
    try {
      this.mainserviceService.getbabyid({
        "babyno": null,
        "babyname": null,
        "machineid": null,
        "clientid": JSON.parse(sessionStorage.getItem('userInfo1')).clientid,
        "babystatus": status,
        "isactive": true,
        "page": pageinc,
        "pagesize": 5
      }).subscribe((res) => {
        console.log("Baby Details => ", res.data);
        this.BabyList = res.data;
      }, (err) => {
        console.log(err.error);

      });

    } catch (err) {
      console.log(err);
    }
  }

  onChange(event: MatTabChangeEvent) {
    try {
      const tab = event.tab.textLabel;
      console.log(tab);

      if (tab === "Admited") {
        this.getbabydetails(1, "admitted");
      } else if (tab == "Discharged") {
        this.getbabydetails(1, "discharge");
      }
    } catch (err) {
      console.log(err)
    }
  }

  selectedBabys = (baby) => {
    console.log("BABY DETAILS =================", baby);
    this.babyid = baby.babyid;
  }

  admitprevious() {
    if (this.pageadmit >= 2) {
      this.pageadmit = this.pageadmit - 1;
      console.log("decriment => ", this.pageadmit)
      this.getbabydetails(this.pageadmit, "admitted");
    }
  }

  admitnext() {
    this.pageadmit = this.pageadmit + 1;
    console.log("Incriment => ", this.pageadmit);
    this.getbabydetails(this.pageadmit, "admitted");

  }

  dischargeprevious() {
    if (this.pagedischarge >= 2) {
      this.pagedischarge = this.pagedischarge - 1;
      console.log("decriment => ", this.pagedischarge);
      this.getbabydetails(this.pagedischarge, "discharge");
    }
  }

  dischargenext() {
    this.pagedischarge = this.pagedischarge + 1;
    console.log("Incriment => ", this.pagedischarge);
    this.getbabydetails(this.pagedischarge, "discharge");

  }

  openLg(content1) {
		this.modalService.open(content1, { size: 'lg' });
  }

  createGrowthChart(){
    this.growthChartForm = new FormGroup({
      // babydate:new FormControl(null,[Validators.required]),
      babyweigth:new FormControl(null,[Validators.required]),
      babygestationage:new FormControl(null,[Validators.required]),
      babylength:new FormControl(null,[Validators.required]),
      babyheadcircumference:new FormControl(null,[Validators.required])
    });
  }


  get registerFormControl() {
    return this.growthChartForm.controls;
  }


  addGrowthChart(){
    try{
      console.log("Growth chart form ==========",this.growthChartForm.value);
      
      if(this.growthChartForm.valid){
        //after valid 

        console.log("After Validation form ==========",this.growthChartForm.value);
        this.growthChartList.push({
          date: "7/8/2022 12:20 PM ",
          babyweigth : this.growthChartForm.value.babyweigth,
          babygestationage : this.growthChartForm.value.babygestationage,
          babylength : this.growthChartForm.value.babylength,
          babyheadcircumference : this.growthChartForm.value.babyheadcircumference 
        })

        swal.fire(
          'Good job!',
          'Growth Chart Add Succsefully!',
          'success'
        );


        this.closeBtnClick();

      }else{
        //invalid handling
        swal.fire(
          'Bad Response!',
          'An Error Occured, Please Contact System Administrator!',
          'error'
        );
      }
    }catch(err){
      console.log(err);
    }
  }




  
  closeBtnClick() {
    this.modalService.dismissAll()
    this.ngOnInit();
  }


}
