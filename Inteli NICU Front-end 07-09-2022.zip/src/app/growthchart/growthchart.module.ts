import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';import { GrowthchartRoutingModule } from './growthchart-routing.module';
import { GrowthchartComponent } from './growthchart.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatTabsModule} from '@angular/material/tabs';
import {MatSelectModule} from '@angular/material/select';
import {MatInputModule} from '@angular/material/input';

@NgModule({
  declarations: [GrowthchartComponent],
  imports: [
    CommonModule,
    FormsModule,ReactiveFormsModule,
    MatTabsModule,
    MatExpansionModule,
    MatSelectModule,
    MatInputModule,
    GrowthchartRoutingModule
  ]
})
export class GrowthchartModule { }
