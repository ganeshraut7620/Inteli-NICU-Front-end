import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VitalclientdashboardComponent } from './vitalclientdashboard.component';

describe('VitalclientdashboardComponent', () => {
  let component: VitalclientdashboardComponent;
  let fixture: ComponentFixture<VitalclientdashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VitalclientdashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VitalclientdashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
