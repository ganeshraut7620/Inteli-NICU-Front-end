import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { VitalclientdashboardComponent } from './vitalclientdashboard.component';

const routes: Routes = [
  {
    path:'',component:VitalclientdashboardComponent 
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class VitalclientdashboardRoutingModule { }
