import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { VitalclientdashboardRoutingModule } from './vitalclientdashboard-routing.module';
import { VitalclientdashboardComponent } from './vitalclientdashboard.component';


@NgModule({
  declarations: [VitalclientdashboardComponent],
  imports: [
    CommonModule,
    VitalclientdashboardRoutingModule
  ]
})
export class VitalclientdashboardModule { }
